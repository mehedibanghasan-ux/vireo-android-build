# Third-Party / Distribution Notice

This Android port depends on:

- Chaquopy 17.0.0 for CPython on Android.
- FFmpegKit Maintained `ffmpeg-kit-full-gpl:8.1.7` for FFmpeg/FFprobe and `libx264`.
- Requests, Pillow and python-dotenv in the embedded Python runtime.

The FFmpegKit `full-gpl` artifact includes GPL components such as x264. If you distribute the resulting APK, your distribution must satisfy the applicable GPL-3.0 obligations. This notice is not legal advice.
