# Vireo Android Update 8 Test Report

## Before Update 8
- Update 7 local Android contract suite: 28/28 passed.
- Real GitHub CI: FAILED at `:app:checkDebugAarMetadata`.
- Root cause: AndroidX Activity dependency present while `android.useAndroidX=false`.

## After Update 8
- Android contract tests: 29/29 passed.
- `tools/verify_android_port.py`: PASS.
- Python compileall: PASS.
- JavaScript syntax check: PASS.
- AndroidX build configuration regression: PASS.
- Explicit Chaquopy Python 3.13 build interpreter contract: PASS.

## Protected-core status
The Update 8 change is confined to Android build configuration, version metadata,
test/verifier guards and documentation. Protected Vireo Python provider/pipeline
modules are unchanged from Update 7.
