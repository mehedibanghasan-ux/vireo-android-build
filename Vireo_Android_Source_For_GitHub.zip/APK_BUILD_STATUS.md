# APK Build Status

The Android source is prepared and host-tested, but **an APK was not produced inside the current execution container** because this container has no Android SDK, no Gradle installation/cache and no outbound package-download connectivity. Creating a file with an `.apk` extension without running the Android toolchain would be invalid, so no fake APK is included.

The included Android Studio/Gradle project and GitHub Actions workflow are configured to create `app-debug.apk` with the pinned toolchain.
