# Vireo Android Update 10 Release Notes

## User-visible fixes
- Final generation no longer creates a separate workspace `Exports` copy.
- The manual `Save Final MP4 to Movies/Vireo` step is removed.
- The complete project is automatically mirrored to the dedicated visible `Projects/lv_###` folder, including the final MP4.
- Future visible level folders are created through one serialized SAF path, preventing race-created names such as `lv_001 (1)`.
- Generation is owned by a foreground service and continues when Vireo is backgrounded or the screen is off.
- The foreground service persists the active request/project path and uses existing Resume behavior after Android process/service recreation.

## Android boundary changes
- Added `WorkspaceMirror.java` for serialized project-folder SAF mirroring.
- `GenerationService.java` now owns generation, holds the wake lock, persists runtime state and returns `START_STICKY`.
- Android 15+ uses the media-processing foreground-service type; Android 13–14 keeps data-sync type compatibility.
- `MainActivity.java` delegates generation startup to the service and rehydrates UI state after recreation.
- `app.js` no longer asks for a manual final-video save.

## Explicitly untouched protected Python core
- `app/pipeline.py`
- `app/ai33_client.py`
- `app/runware_client.py`
- `app/project.py`
- `app/subtitles.py`
- `app/renderer.py`
- provider/paid-task safeguards, scene mapping, checkpoints/manifests, Resume, narration and render contracts

## Important platform limit
Android can keep a foreground service running through normal Home/background/screen-off flows and can restart a sticky service after ordinary process reclamation. No app can guarantee continuation after a user Force Stop, device reboot without a restart receiver, or OEM/system policies that explicitly block the app.
