# Changed Files — Android Update 4

Compared with the FIX3 Android baseline, intentional source changes are:

1. `app/build.gradle`
   - versionCode 4 / Update4 version name only.
2. `app/src/main/java/com/vireo/studio/MainActivity.java`
   - WindowInsets, `.env` picker, SAF workspace, project restore, style/reference imports, workspace mirroring/export adapters.
3. `app/src/main/python/android_bridge.py`
   - safe API import/update adapter, subtitle-only autosave adapter, Resume detach/restore adapter, desktop default-model preservation, project-known notification.
4. `app/src/main/assets/index.html`
   - mobile parity controls for `.env`, workspace, restore, style/reference imports; Android 13–16 label.
5. `app/src/main/assets/app.js`
   - workspace/project UI state, project detach semantics, subtitle-only autosave call, zero-padded scene labels, restore/env events, one-time AI33 voice fetch.
6. `port_tests/test_android_port_contracts.py`
   - expanded from 12 to 23 contract tests.
7. Update4 documentation/reports/manifests.

No protected provider/pipeline module was changed by Update4.
