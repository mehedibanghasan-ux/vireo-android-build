# Vireo Android Update 9 Release Notes

## Purpose
Fix the physical-device FFmpegKit startup failure caused by a missing Smart Exception runtime class while preserving all already-working Vireo behavior.

## Changed
- `app/build.gradle`
  - versionCode 9
  - versionName `1.0-update9-ffmpeg-runtime-dependency-fix`
  - explicitly pins `com.arthenica:smart-exception-java:0.2.1`
  - explicitly pins `com.arthenica:smart-exception-common:0.2.1`
- `.github/workflows/android-build.yml`
  - verifies Update 9 source/version
  - installs CI pytest explicitly
  - verifies full Gradle debug runtime dependency graph
  - verifies both Smart Exception modules resolve
  - builds APK and runs lint
  - verifies native FFmpeg/Python libraries in APK
  - uses Android `apkanalyzer --defined-only` to prove the missing runtime class is defined in the APK
- `tools/verify_android_port.py`
  - blocks builds where FFmpegKit is present without explicit Smart Exception pins
- `port_tests/test_android_port_contracts.py`
  - adds Update 9 dependency and CI guards
  - updates historical Update 8 version test so future patch versions do not create a false test failure

## Explicitly untouched
- `app/src/main/python/app/pipeline.py`
- `app/src/main/python/app/ai33_client.py`
- `app/src/main/python/app/runware_client.py`
- `app/src/main/python/app/project.py`
- `app/src/main/python/app/subtitles.py`
- `app/src/main/python/app/renderer.py`
- `app/src/main/python/app/config.py`
- `app/src/main/python/android_bridge.py`
- `app/src/main/java/com/vireo/studio/MainActivity.java`
- `app/src/main/java/com/vireo/studio/FFmpegBridge.java`

## Protected behavior retained
- Scene → Prompt → Image → Audio → Subtitle → Timeline mapping
- Runware concurrency and safety
- AI33 task persistence and duplicate prevention
- Resume
- Project save/load
- Image review/regeneration behavior
- Exact-script subtitles
- Narration continuity
- FFmpeg command/render architecture
- H.264/AAC output contract
- Update 4 workspace/.env/parity behavior
- Update 6 real on-device FFmpeg/FFprobe self-test
- Update 7 predictive-back and SAF fixes
- Update 8 AndroidX build-system fix
