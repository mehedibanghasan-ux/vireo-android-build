# Changed Files — Android Update 8

1. `gradle.properties`
   - Enable AndroidX for the AndroidX Activity dependency.
   - Explicit Jetifier=false because no legacy support-library migration is needed.

2. `app/build.gradle`
   - Version bump only: versionCode 8 / Update 8 versionName.

3. `port_tests/test_android_port_contracts.py`
   - Version expectation update.
   - New AndroidX build-configuration regression test.

4. `tools/verify_android_port.py`
   - New pre-CI AndroidX configuration contract.

5. Update 8 release/test documentation.

Protected Python core/provider modules were not modified.
