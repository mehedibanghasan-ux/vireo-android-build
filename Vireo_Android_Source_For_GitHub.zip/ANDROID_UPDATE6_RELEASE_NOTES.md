# Vireo Android Update 6 Release Notes

## Problem reproduced from Update 5 real-device test
AI33 tasks completed successfully, but `scene_000.mp3` was rejected by Vireo as `Generated audio 1 failed FFmpeg validation` on Android.

The supplied real Update5 APK was inspected. It contains the FFmpegKit native libraries and the required MP3/AAC decoders, libx264, libass/subtitles and Vireo render filters. Therefore the failure was not caused by a missing codec package.

## Root cause
Update5 switched to `FFprobeKit.getMediaInformation()`, but then serialized `MediaInformation.getAllProperties()` and treated that raw FFmpegKit object-model structure as if it were the exact desktop CLI schema produced by:

`ffprobe -show_streams -show_format -of json`

Vireo's protected Python renderer expects normalized keys such as `streams[].codec_type` and `format.duration`. FFmpegKit object properties are not a guaranteed byte-for-byte/schema-for-schema equivalent of the CLI JSON, so valid Android audio can be rejected when those expected keys are absent or named differently.

## Update 6 fix
Only the Android FFmpeg/FFprobe boundary was changed.

1. `FFmpegBridge.probeFile()` now normalizes FFmpegKit media information into the desktop Vireo schema.
2. Stream type aliases (`codec_type`, `type`, `codecType`) are normalized to `codec_type`.
3. `timeBase`/`durationTs` aliases are normalized to `time_base`/`duration_ts`.
4. Format duration is reconstructed from FFmpegKit's media object when it is not already nested under `format.duration`.
5. If the raw property map doesn't expose streams in a usable shape, stream objects are rebuilt through the FFmpegKit Java object model using reflection. This keeps the bridge tolerant of FFmpegKit object-model variations while the Python renderer contract remains unchanged.

## Real preflight added
The old Android `find_ffmpeg()` preflight only confirmed that the Java bridge class existed. That could print `FFmpeg and FFprobe preflight passed` without proving that Android FFprobe could parse Vireo media.

Update6 runs one cached on-device self-test before any paid provider work:
- probe bundled Vireo WAV;
- decode bundled WAV;
- encode a short MP3 with libmp3lame;
- probe and decode that MP3;
- encode a tiny H.264/AAC MP4;
- probe and require both video and audio streams.

If this fails, generation stops before Runware/AI33 paid generation begins.

## Protected systems unchanged
The following modules remain byte-identical to the protected desktop baseline:
- `pipeline.py`
- `ai33_client.py`
- `runware_client.py`
- `project.py`
- `subtitles.py`
- `openai_tools.py`
- `scene_splitter.py`
- `script_analyzer.py`
- `character_presets.py`
- `styles.py`

No AI33 submission, task persistence, polling, download retry, duplicate-prevention or concurrency logic was changed.

## Version
- versionCode: 6
- versionName: `1.0-update6-normalized-probe-selftest`
- Android: 13 through 16
- ABI: arm64-v8a
