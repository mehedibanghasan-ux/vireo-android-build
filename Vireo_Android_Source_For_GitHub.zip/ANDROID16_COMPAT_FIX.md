# Android 16 / 16 KB compatibility fix

## Symptom
App installed but force-closed immediately on a modern OEM Android build, with a system message about security reinforcement techniques being incompatible and Smart app assistant reporting a shell error.

## Root-cause direction
The previous APK targeted API 35. The app includes native code through Chaquopy and FFmpegKit. Android 16 and OEM builds can enforce newer native/page-size compatibility behavior.

## Minimal compatibility changes
- compileSdk 36 / targetSdk 36, minSdk remains 33 (Android 13).
- android:pageSizeCompat=enabled as Android 16 compatibility safety net.
- FFmpegKit is no longer initialized at app startup. It is configured lazily on first FFmpeg/FFprobe operation.
- Java-level startup initialization errors are rendered on-screen instead of silently closing.
- Protected Vireo Python pipeline/provider/project/subtitle logic is unchanged.

## Expected OS range
Android 13, 14, 15 and 16 on arm64-v8a.
