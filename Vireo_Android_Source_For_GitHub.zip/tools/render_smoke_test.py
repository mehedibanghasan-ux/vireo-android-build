from __future__ import annotations
import json, math, os, shutil, struct, subprocess, sys, tempfile, wave
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PYROOT=ROOT/'app/src/main/python'
work=Path(tempfile.mkdtemp(prefix='vireo_android_render_smoke_'))
try:
    os.environ['VIREO_BASE_DIR']=str(work/'store')
    sys.path.insert(0,str(PYROOT))
    import android_bridge
    # initialize uses an Android-style private root and copies exact SFX assets.
    android_bridge.initialize(str(work))
    from PIL import Image, ImageDraw
    from app.renderer import render_project

    assets=work/'assets'; assets.mkdir()
    images=[]; audios=[]
    for i in range(2):
        img=assets/f'scene_{i}.png'
        im=Image.new('RGB',(320,180),(30+70*i,60,100+50*i))
        ImageDraw.Draw(im).rectangle((40,40,280,140),outline='white',width=3)
        im.save(img); images.append(img)
        wav=assets/f'audio_{i}.wav'; sr=44100; dur=1.25+0.15*i; freq=330+110*i
        with wave.open(str(wav),'w') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
            w.writeframes(b''.join(struct.pack('<h',int(4500*math.sin(2*math.pi*freq*n/sr))) for n in range(int(sr*dur))))
        audios.append(wav)
    srt=assets/'subs.srt'
    srt.write_text('1\n00:00:00,000 --> 00:00:01,200\nEXACT SCRIPT ONE\n\n2\n00:00:01,250 --> 00:00:02,600\nEXACT SCRIPT TWO\n',encoding='utf-8')
    out=work/'project'; out.mkdir()
    final=render_project(images,audios,out,width=320,height=180,workers=2,ken_burns=True,heartbeat=True,transitions=True,music_path=None,srt_path=srt,font_name='DejaVu Sans',font_size=22,subtitle_position='bottom',subtitle_outline_size=1.0,subtitle_color='#FFFFFF',force_h264=True,random_animations=True,random_seed=23,output_basename='Vireo Android Smoke')
    probe=json.loads(subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name,codec_type','-show_entries','format=duration','-of','json',str(final)],capture_output=True,text=True,check=True).stdout)
    streams={(s.get('codec_type'),s.get('codec_name')) for s in probe['streams']}
    debug=json.loads((out/'render_debug.json').read_text())
    assert ('video','h264') in streams, streams
    assert ('audio','aac') in streams, streams
    assert debug['scene_count']==2 and debug['one_image_one_audio_per_scene'] is True
    assert abs(float(debug['final_duration'])-float(debug['expected_total_duration']))<0.25
    print(json.dumps({'status':'PASS','video':'h264','audio':'aac','scene_count':2,'expected_duration':debug['expected_total_duration'],'final_duration':debug['final_duration'],'output_size':final.stat().st_size}))
finally:
    shutil.rmtree(work,ignore_errors=True)
