from __future__ import annotations
import re, sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text()
js=(root/'app/src/main/assets/app.js').read_text()
java=(root/'app/src/main/java/com/vireo/studio/MainActivity.java').read_text()
bridge=(root/'app/src/main/python/android_bridge.py').read_text()
errors=[]

ids=set(re.findall(r'id="([A-Za-z0-9_-]+)"',html))
for qid in sorted(set(re.findall(r"q\('([^']+)'\)",js))):
    if re.search(r'^(?:ri|rb)\$|\+',qid):
        continue
    if qid not in ids:
        errors.append(f"JS references missing HTML id: {qid}")

py_methods=set(re.findall(r'^def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(',bridge,re.M))
for method in sorted(set(re.findall(r"invoke\('([^']+)'",js))):
    if method not in py_methods:
        errors.append(f"JS invokes missing Python bridge method: {method}")

java_methods=set(re.findall(r'@JavascriptInterface\s+public\s+[\w<>\[\]]+\s+(\w+)\s*\(',java))
for method in sorted(set(re.findall(r'Android\.(\w+)\s*\(',js+html))):
    if method not in java_methods:
        errors.append(f"Web UI calls missing @JavascriptInterface method: Android.{method}")

# Native events emitted by Java/Python must be understood by the JS bridge or intentionally handled as toast/error.
emitted=set(re.findall(r'_notify\("([^"]+)"',bridge)) | set(re.findall(r'emit\("([A-Za-z][A-Za-z0-9_]*)"',java))
for event in sorted(emitted):
    if event not in js and event not in {'generationState'}:
        errors.append(f"Native event has no JS handler token: {event}")

# Basic source-balance checks catch accidental truncation in generated Java/JS assets.
for name,text,pairs in [
    ('MainActivity.java',java,[('{','}'),('(',')')]),
    ('app.js',js,[('{','}'),('(',')'),('[',']')]),
]:
    for a,b in pairs:
        if text.count(a)!=text.count(b):
            errors.append(f"{name} unbalanced {a}{b}: {text.count(a)} != {text.count(b)}")

if errors:
    print("ANDROID PORT STATIC CONTRACT FAILED")
    print("\n".join(f"- {e}" for e in errors))
    sys.exit(1)
print(f"ANDROID PORT STATIC CONTRACT OK: {len(ids)} HTML controls/containers, {len(py_methods)} Python bridge methods, {len(java_methods)} JavaScriptInterface methods")
