# Update 7 Root-Cause Evidence

The user's real GitHub CI diagnostics from the Update 6 run showed:

- `:app:assembleDebug` -> BUILD SUCCESSFUL
- `:app:lintDebug` -> FAILED
- Lint summary -> 2 errors, 13 warnings

Exact errors:
1. `MainActivity.java`: `GestureBackNavigation`
   - `onBackPressed()` is not invoked for Android 16 predictive back gestures when targeting API 36.
2. `MainActivity.java`: `WrongConstant`
   - `takePersistableUriPermission` mode flags needed explicit narrowing.

Update 7 fixes these errors with supported Android APIs rather than disabling lint:
- AndroidX `ComponentActivity` + `OnBackPressedCallback` / `OnBackPressedDispatcher`
- explicit READ / WRITE / READ|WRITE mode selection for persistable URI grants

The warnings were not build blockers.
