# Changed Files — Android Update 9

Compared with Update 8 source, intended functional changes are limited to:

1. `app/build.gradle`
   - Update 9 version bump.
   - Explicit Smart Exception runtime dependencies.
2. `.github/workflows/android-build.yml`
   - Runtime dependency resolution gate.
   - APK DEX class-definition verification gate.
   - Explicit CI pytest setup and richer diagnostics.
3. `tools/verify_android_port.py`
   - Smart Exception dependency guard.
4. `port_tests/test_android_port_contracts.py`
   - Update 9 regression tests and future-safe historical version assertion.
5. Update 9 release/test/root-cause documentation.

No Vireo pipeline/provider/project/render behavior file was modified.
