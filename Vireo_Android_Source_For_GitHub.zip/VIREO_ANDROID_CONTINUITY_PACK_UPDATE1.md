# Vireo Android Continuity Pack — Update 1

## Desktop source of truth

Supplied desktop archive SHA-256:
`6ff6b8d7f15729f9e59fdf6be219ab4c984d5796f7dc48cba01599e7b4714c4d`

Supplied memory archive SHA-256:
`4f226b24bcb250097f70461a485592850e624527d4cec27cf26c99aa5cc999e1`

The desktop archive remains untouched. Android development is parallel.

## Android baseline

Project: `Vireo_Android_Update1`

Platform contract:
- minSdk 33
- targetSdk 35
- compileSdk 35
- arm64-v8a
- Chaquopy 17.0.0 / Python 3.13
- FFmpegKit Maintained full-gpl 8.1.7

## Never regress these systems

1. Scene → Prompt → Image → Audio → Subtitle → Timeline one-to-one mapping.
2. Runware bounded concurrency and no unsafe paid-request replay.
3. AI33 task IDs persisted immediately and reused on resume.
4. AI33 completed CDN download retry must never resubmit paid TTS.
5. Resume must validate strict manifests/signatures and reuse only valid assets.
6. Project save/load state and original script behavior.
7. Image review must not expose prompt text; regeneration changes only the selected image/prompt and invalidates downstream render appropriately.
8. Exact-script subtitles remain scene bounded and aligned back to source script.
9. Narration remains continuous; no scene-edge fade/crossfade regression.
10. Update 17 ffconcat protection stays intact.
11. Scene-change SFX timing stays exact.
12. Final output remains validated H.264 video + AAC audio MP4.

## Android boundary policy

Do not rewrite protected processing logic into Java/Kotlin merely for convenience. Keep Python core behavior unless Android OS constraints make a boundary adapter necessary.

Allowed current adapters:

- Config base directory → Android app-private directory.
- FFmpeg/FFprobe execution → `FFmpegBridge` only.
- UI/lifecycle/storage/notifications → Android layer.
- OpenAI package compatibility → small Android HTTP shim which must preserve status codes needed by existing retry logic.

## Current mobile reliability decisions

- Generation uses a foreground service.
- A partial wake lock is acquired during generation and released at end.
- Java `AtomicBoolean` and Python lock both block duplicate generation.
- Project switching is blocked while generation is active.
- Review state is re-emitted if the Activity is recreated while the process survives.
- Completed project outputs can be exported later from the saved-project list.
- Source review images are never resized/rewritten; only display copies are downsampled.
- No broad external-storage permission is used.
- Final export goes through MediaStore.

## Voice behavior

Adding `Voice ID + Voice Name` creates/persists a custom preset only. It must not overwrite current selected voice or default voice. Setting the selected voice as default is an explicit separate action.

## Subtitle behavior

Latest subtitle preferences persist globally across restarts/new projects. Fresh Android projects preserve the current subtitle preference fields while other project-specific controls follow the protected fresh-project defaults.

Desktop font choice labels are kept: Arial, LuckiestGuy, Impact, Verdana. Android must warn rather than silently change an unavailable font. Exact appearance requires the user's licensed font file.

## Known baseline inconsistency

The supplied Update 22 test still expects subtitle font size 19 while current source default is 21. Do not change either casually. Treat current source behavior/memory hierarchy as authority until a specific requirement resolves it.

## Current test baseline

- Android port contracts: 12/12 PASS
- Protected desktop suite using Android core: 121 PASS / 1 known stale failure
- Host render smoke: PASS, H.264/AAC
- JavaScript/static bridge checks: PASS

## Build limitation in this session

No Android SDK or Gradle is installed in the execution container and the container has no outbound package-download connectivity. No genuine APK could be compiled locally. The project includes a pinned GitHub Actions workflow and build scripts for a toolchain-enabled machine.

## Rule for next Android change

Before modifying:
1. state exact problem,
2. identify root cause,
3. list exact files to change,
4. name protected systems that remain untouched,
5. make the smallest patch,
6. run port contracts + protected regression + relevant smoke test,
7. update release notes, checksums and continuity pack.
