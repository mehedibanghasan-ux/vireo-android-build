# Vireo Video Studio — Desktop ↔ Android Parity Audit (Update 4)

## Scope
This audit compares the supplied desktop Vireo baseline with Android Update 4. The goal is behavioral parity, not pixel-for-pixel desktop layout. Android-specific storage and lifecycle constraints are handled in adapter/UI layers while protected Vireo generation logic remains unchanged.

Status meanings:
- **EXACT CORE** — protected Python behavior is byte-identical to the supplied desktop baseline.
- **MATCHED** — Android behavior intentionally matches the desktop behavior.
- **ANDROID EQUIVALENT** — same user capability, implemented with Android-native storage/UI conventions.
- **DEVICE VERIFY** — implemented and statically/regression tested, but still requires the rebuilt APK to be installed on a real device for runtime confirmation.

## Core pipeline and protected systems

| Desktop behavior | Android Update 4 | Status |
|---|---|---|
| Scene → Prompt → Image → Audio → Subtitle → Timeline mapping | Same protected pipeline modules | **EXACT CORE** |
| Runware concurrency/safety | Same `runware_client.py` and pipeline scheduling | **EXACT CORE** |
| AI33 task-ID persistence / duplicate prevention | Same `ai33_client.py` + duplicate-generation guards | **EXACT CORE** |
| Resume manifests/state | Same `project.py` and pipeline resume behavior | **EXACT CORE** |
| Exact-script subtitles | Same `subtitles.py` | **EXACT CORE** |
| Narration continuity | Same pipeline; Android renderer only replaces process execution boundary | **EXACT CORE / audited boundary** |
| FFmpeg renderer decisions | Desktop renderer content retained; Android FFmpegKit bridge only at execution boundary | **MATCHED** |
| Final H.264/AAC output contract | Preserved | **MATCHED** |
| Image-review regeneration invalidation | Only affected image/prompt and downstream render invalidated; audio/subtitle preserved | **MATCHED** |

## Project and script workflow

| Desktop | Android Update 4 | Status |
|---|---|---|
| Video Title | Video Title | **MATCHED** |
| Script editor | Script editor | **MATCHED** |
| Load Script | Android document picker | **ANDROID EQUIVALENT** |
| Save Script | Android create-document picker | **ANDROID EQUIVALENT** |
| Paste | Android clipboard | **MATCHED** |
| Clear | Clears standalone script and detaches loaded resume project | **MATCHED** |
| Editing loaded script disables Resume | `detach_project_json` clears loaded project binding | **MATCHED** |
| Content Stats | Same analyzer exposed in mobile UI | **MATCHED** |
| Recommended/max scene count | Same analyzer | **MATCHED** |
| Preview Scene Chunks | Mobile modal | **MATCHED** |
| Scene labels `Scene 001`, `Scene 002` | Zero-padded to match desktop | **MATCHED** |
| Copy Scene Chunks | Android clipboard | **MATCHED** |
| Export Scene Chunks | Android document save | **ANDROID EQUIVALENT** |
| New Project | Fresh-project settings + cleared script/log/progress | **MATCHED** |
| Load arbitrary saved `lv_` folder | Internal project list plus **Import / Restore Project Folder** from Android Files | **ANDROID EQUIVALENT** |
| Preserve global default OpenAI model while loading old project | Explicitly preserved like desktop `load_project()` | **MATCHED** |
| Pause After Current Step | Existing protected stop-event/pipeline pause | **MATCHED** |

## Visible folders and workspace

Desktop has unrestricted filesystem access; Android 13–16 does not. Update 4 therefore uses a two-layer model:

1. **Authoritative protected working copy** under app-private storage for atomic writes, manifests and Resume safety.
2. **User-selected visible workspace mirror** through Android Storage Access Framework (SAF).

Visible workspace structure:

```text
<Vireo Workspace>/
├── Projects/
│   └── lv_###/
├── Music/
├── Fonts/
├── Style_Previews/
├── Reference_Styles/
└── Exports/
```

Behavior:
- Workspace selection is persisted with Android's persistable URI permission.
- `Projects/lv_###` is prepared when a generation project becomes known.
- Full safe project sync happens after pause/completion, never by redirecting protected atomic project writes into SAF.
- Manual Sync Current Project is available when generation is not active.
- Import / Restore Project Folder copies a visible project into protected private storage, validates that it contains a recoverable script, then uses normal Vireo Resume logic.
- Existing protected project folders are never destructively overwritten by restore.
- Music/fonts/style libraries can be mirrored to the visible workspace.
- The `.env` file is deliberately **not** mirrored to visible storage.

Status: **ANDROID EQUIVALENT, Resume-safe design**. Real-device SAF provider behavior still requires rebuilt APK verification.

## API configuration

| Desktop | Android Update 4 | Status |
|---|---|---|
| `.env` / API keys | Manual password fields + **Import PC .env** | **ANDROID EQUIVALENT** |
| OpenAI key | Recognized `OPENAI_API_KEY` only | **MATCHED** |
| Runware key | Recognized `RUNWARE_API_KEY` only | **MATCHED** |
| AI33 key | Recognized `AI33_API_KEY` only | **MATCHED** |
| Other `.env` secrets | Not imported | **SAFETY IMPROVEMENT** |
| Secret values in logs/UI | Never returned by import response | **SAFETY IMPROVEMENT** |
| Blank manual key field | Does not erase an already stored hidden key | **MATCHED / guarded** |
| Imported blank/missing key | Existing stored key is preserved | **MATCHED / guarded** |

The supplied PC source ZIP did not contain a real `.env`; only `.env.example` was available, so real secret values could not be pre-populated into the APK.

## Image generation

| Desktop | Android Update 4 | Status |
|---|---|---|
| Runware search/fetch | Search + Fetch button | **MATCHED** |
| Runware model selection | Native mobile `<select>` instead of desktop table dialog | **ANDROID EQUIVALENT** |
| Runware cost label | Shown for selected model | **MATCHED** |
| Recommended image steps | Same protected recommendation logic | **MATCHED** |
| GPT Image 2 LOW-quality lock / no image steps | Same protected model logic | **MATCHED** |
| OpenAI model fetch | Present | **MATCHED** |
| Set current OpenAI model as default | Present | **MATCHED** |
| Default-model hint | Present | **MATCHED** |
| Image Style | Present | **MATCHED** |
| Style Preview | Mobile full modal + prompt | **MATCHED** |
| `style_previews/` assets | Import Style Preview Image | **ANDROID EQUIVALENT** |
| `reference_styles/` folders | Import Reference Style Folder | **ANDROID EQUIVALENT** |
| Standard stick-figure character bundle | Present | **MATCHED** |
| Standard bundle look | Present | **MATCHED** |
| Older Storybook bundle | Present | **MATCHED** |
| Character bundle disables conflicting Image Style | Enforced in mobile UI | **MATCHED** |
| Image review before audio/render | Present | **MATCHED** |
| Prompt text hidden from image-review cards | Explicit regression guard | **MATCHED** |
| Full-screen image review | Mobile modal | **MATCHED** |
| Regenerate one image | Same prompt/regeneration and invalidation contract | **MATCHED** |

## Manual prompts

| Desktop | Android Update 4 | Status |
|---|---|---|
| Enable manual prompts | Present | **MATCHED** |
| Apply style/character bundle | Present | **MATCHED** |
| Live parsed prompt count | Present | **MATCHED** |
| Missing prompts generated automatically | Same protected pipeline | **EXACT CORE** |
| Extra prompts require confirmation | Present | **MATCHED** |
| Scene mapping stays exact | Same protected pipeline | **EXACT CORE** |

## Voice and audio

| Desktop | Android Update 4 | Status |
|---|---|---|
| AI33 provider list | Same providers | **MATCHED** |
| Voice language search | Present | **MATCHED** |
| Fetch AI33 voices | Present | **MATCHED** |
| Automatic voice fetch when AI33 key is available | Added | **MATCHED** |
| Voice preset dropdown | Present | **MATCHED** |
| Voice ID status | `✓ Voice ID active` | **MATCHED** |
| Add Voice ID + Voice Name | Present | **MATCHED** |
| Adding custom voice must not replace selected/default | Explicit protected Android test | **MATCHED TO MEMORY CONTRACT** |
| Set selected voice as default | Present | **MATCHED** |
| Background Music | Present | **MATCHED** |
| Music volume | Present | **MATCHED** |
| Add music files | Android file import | **ANDROID EQUIVALENT** |

## Subtitles

| Desktop | Android Update 4 | Status |
|---|---|---|
| Enable subtitles | Present | **MATCHED** |
| Font | Present | **MATCHED** |
| Font size | Present | **MATCHED** |
| Position | Present | **MATCHED** |
| Words/caption | Present | **MATCHED** |
| All caps | Present | **MATCHED** |
| Stroke/outline | Present | **MATCHED** |
| Color | Native Android/Web color picker | **ANDROID EQUIVALENT** |
| Update-31 subtitle preference autosave | Only subtitle fields are persisted | **MATCHED** |
| Imported `.ttf/.otf` | Supported | **ANDROID EQUIVALENT** |
| Exact desktop Impact font | Not bundled; user must import licensed font for exact appearance | **EXPLICIT, no silent substitution** |
| Exact-script subtitle engine | Same protected module | **EXACT CORE** |

## Rendering

| Desktop | Android Update 4 | Status |
|---|---|---|
| Random scene transitions | Present | **MATCHED** |
| Ken Burns | Present | **MATCHED** |
| Heartbeat on long scenes | Present | **MATCHED** |
| Random image animations | Present | **MATCHED** |
| Render workers | Present | **MATCHED** |
| Scene-cut SFX | Protected assets + renderer | **MATCHED** |
| Continuous narration cleanup | Protected renderer logic | **MATCHED** |
| FFconcat / long-command protection | Renderer content retained | **MATCHED** |
| Save final MP4 | MediaStore → `Movies/Vireo` | **ANDROID EQUIVALENT** |

## Android lifecycle / compatibility

- Android 13–16 target configuration retained.
- System status-bar/display-cutout overlap is handled with **real `WindowInsets`**, not a device-specific hardcoded top margin.
- Sticky header is now inside the correctly inset WebView content.
- Foreground generation service remains active for long-running work.
- Duplicate generation button/task protection remains in Java and Python.
- Image review can be re-emitted after Activity recreation.
- FFmpeg remains lazy-loaded for Android 16 native compatibility.

Status: **implemented; rebuilt APK device verification required**.

## Known non-regression baseline issue
The supplied desktop suite contains one historical stale assertion: Update-22 expects subtitle font size `19`, while the supplied current source defaults to `21`. Current result remains **121 passed, 1 known stale failure**. Update 4 did not modify this behavior.

## Current release gate
Update 4 is source/test complete only after all listed tests pass. It must still be:
1. built by the existing GitHub Android workflow,
2. installed over a clean/uninstalled prior debug APK if signing conflicts,
3. verified on the user's phone for status-bar layout, `.env` picker, SAF workspace and project restore,
4. run through a small real provider generation before calling it fully release-verified.
