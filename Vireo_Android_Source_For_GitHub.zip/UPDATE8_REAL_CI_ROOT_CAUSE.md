# Update 8 — Real GitHub CI Root Cause

Evidence source: user-provided `Vireo-build-diagnostics(2).zip`.

The real Gradle failure was:

`Execution failed for task ':app:checkDebugAarMetadata'.`

Gradle then reported:

`Configuration :app:debugRuntimeClasspath contains AndroidX dependencies, but the android.useAndroidX property is not enabled.`

Update 7 introduced `androidx.activity:activity:1.13.0` and migrated MainActivity to
`androidx.activity.ComponentActivity` for Android 16 predictive-back support, but the
project's `gradle.properties` still explicitly contained:

`android.useAndroidX=false`

This is the complete cause of the Update 7 build failure captured in the diagnostics.
The build stopped before Java compilation and before Android lint.

Update 8 fixes the project property and adds local/CI guards so the same configuration
mismatch is rejected before dependency resolution.
