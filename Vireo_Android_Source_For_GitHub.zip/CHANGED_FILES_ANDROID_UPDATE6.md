# Changed Files — Android Update 6

1. `app/src/main/java/com/vireo/studio/FFmpegBridge.java`
   - Normalize FFmpegKit MediaInformation to desktop FFprobe JSON contract.
   - Add cached real media self-test (WAV, MP3, H.264/AAC).
2. `app/src/main/python/app/renderer.py`
   - Run the real Android FFmpeg/FFprobe self-test once from the existing preflight boundary.
   - No render graph/timing/filter/cache/output-codec logic changed.
3. `app/build.gradle`
   - versionCode 6, Update6 versionName.
4. `port_tests/test_android_port_contracts.py`
   - Update6 probe normalization/preflight regression coverage.
5. `ANDROID_UPDATE6_RELEASE_NOTES.md`
6. `ANDROID_UPDATE6_TEST_REPORT.md`
7. `CHANGED_FILES_ANDROID_UPDATE6.md`
