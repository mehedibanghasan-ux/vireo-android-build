# Vireo Video Studio Android — Update 5 Release Notes

## Problem observed on the real phone
AI33 TTS tasks reached `done 100`, but each downloaded MP3 failed Android FFmpeg validation immediately afterwards. The paid-task provider path itself completed successfully.

## Root cause
Android `renderer._probe_media()` used the low-level FFprobe bridge `executeWithArguments(...).getOutput()` and treated the session log output as raw JSON. FFmpegKit provides a dedicated media-information API which parses probe results and is explicitly intended for inspecting media files.

## Minimal fix
- Added `FFmpegBridge.probeFile(path)` using `FFprobeKit.getMediaInformation(path)`.
- Serialize `MediaInformation.getAllProperties()` to JSON for the existing Python duration/stream logic.
- Android `renderer._probe_media()` now calls only this dedicated bridge method.
- Desktop subprocess probing remains unchanged.
- No AI33 submission, polling, task persistence, download, concurrency, scene mapping, subtitle, narration, project or resume logic was changed.

## Resume safety
When validation fails, the scene task remains checkpointed as an existing AI33 task rather than complete. Resuming the same project therefore re-polls/re-downloads that completed task and does not submit a new paid TTS task.

## Version
- versionCode: 5
- versionName: 1.0-update5-ffprobe-fix
- Android 13–16
