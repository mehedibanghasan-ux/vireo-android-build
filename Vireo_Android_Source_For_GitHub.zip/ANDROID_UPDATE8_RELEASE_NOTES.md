# Vireo Android Update 8 Release Notes

## Root cause fixed
Real GitHub diagnostics from Update 7 failed at `:app:checkDebugAarMetadata` before Java compilation.
Update 7 correctly introduced `androidx.activity:activity:1.13.0` and `ComponentActivity`
for Android 16 predictive-back support, but `gradle.properties` still explicitly contained
`android.useAndroidX=false`.

Android Gradle Plugin 8.13 therefore rejected the AndroidX runtime classpath.

## Update 8 changes
- `gradle.properties`: changed `android.useAndroidX=false` to `android.useAndroidX=true`.
- Explicitly keeps `android.enableJetifier=false` because the declared libraries are already AndroidX-native.
- Added a local regression test which fails whenever AndroidX source/dependencies are present without the required flag.
- Hardened `tools/verify_android_port.py` with the same build-system contract so this configuration error is caught before GitHub CI.
- Bumped Android app version to versionCode 8 / `1.0-update8-androidx-build-config-fix`.
- Preserves Update 7 predictive-back and SAF fixes.
- No protected Vireo provider/pipeline/resume/subtitle/narration logic changed.

## Protected systems untouched
Scene → Prompt → Image → Audio → Subtitle → Timeline mapping, Runware concurrency,
AI33 task persistence/duplicate prevention, Resume, project save/load, image review,
exact-script subtitles, narration continuity, FFmpeg rendering semantics and H.264/AAC
output logic are unchanged.
