# Vireo Android Update 7 Release Notes

## Purpose
Update 7 fixes the two Android Lint errors found from the user's real GitHub CI diagnostics after Update 6 successfully assembled an APK.

## Root causes proven by CI
1. `GestureBackNavigation`: `MainActivity.onBackPressed()` is no longer invoked for predictive back gestures on Android 16 / targetSdk 36.
2. `WrongConstant`: the persistable Storage Access Framework URI permission mode was not statically narrowed enough for Android Lint.

## Changes
- MainActivity now extends AndroidX `ComponentActivity`.
- Generation-time back behavior is implemented with lifecycle-aware `OnBackPressedCallback` / `OnBackPressedDispatcher`.
- The callback is enabled only while Vireo generation is running. During generation Back sends Vireo to the background, preserving the prior behavior. Outside generation the normal system back behavior remains in control.
- SAF persistable URI permissions are explicitly narrowed to READ, WRITE, or READ|WRITE before `takePersistableUriPermission`.
- Added AndroidX Activity 1.13.0.
- Bumped app versionCode to 7 / versionName `1.0-update7-android16-back-saf-lint-fix`.

## Protected systems unchanged
No modifications were made to Vireo's Python provider or pipeline core:
- Scene -> Prompt -> Image -> Audio -> Subtitle -> Timeline mapping
- Runware safety/concurrency
- AI33 task persistence / duplicate prevention
- Resume
- Project save/load logic
- Image review
- Exact-script subtitles
- Narration continuity
- FFmpeg rendering logic
- Final H.264/AAC contract

## CI expectation
Update 6 diagnostics proved `:app:assembleDebug` was already successful. Update 7 addresses both lint errors which were the remaining CI gate failures.
