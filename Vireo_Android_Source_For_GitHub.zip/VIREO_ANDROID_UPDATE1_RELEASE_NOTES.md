# Vireo Android Update 1 — Release Notes

## Goal

Create a parallel Android implementation of the supplied Vireo Video Studio baseline while preserving Vireo's existing pipeline contracts and leaving the desktop source archive unchanged.

## Supported Android baseline

- Android 13 / API 33: supported by project configuration
- Android 14 / API 34: supported by project configuration
- target/compile SDK: 35
- ABI in this build: arm64-v8a

## Architecture

The desktop UI was not ported by emulating Tk. Android has a native Activity/foreground-service shell with a mobile WebView UI. The established Python processing modules remain the source of truth. Chaquopy embeds Python 3.13. FFmpeg command construction remains in the protected renderer; only command execution/probing crosses a Java FFmpegKit bridge.

## Protected logic preserved

The following Android copies are byte-identical to the supplied desktop source:

- `ai33_client.py`
- `character_presets.py`
- `openai_tools.py`
- `pipeline.py`
- `project.py`
- `runware_client.py`
- `scene_splitter.py`
- `script_analyzer.py`
- `styles.py`
- `subtitles.py`

`config.py` differs only in choosing an Android-writable base directory when `VIREO_BASE_DIR` is set.

`renderer.py` keeps the existing renderer and changes only the FFmpeg/FFprobe process-execution boundary for Android.

## Android-specific additions

- Native Android Activity and WebView shell
- Foreground generation service
- Partial wake lock only while generation is active
- Storage Access Framework for script/music/font import/export
- MediaStore final MP4 export to `Movies/Vireo`
- Android FFmpegKit bridge
- Mobile image-review UI with explicit full-screen view and regeneration
- Mobile style preview
- Custom voice preset management which preserves selected/default voice
- Global subtitle preference autosave behavior
- Duplicate generation guard in both Java and Python adapter layers
- New/Load Project guard while generation is running
- Resume/project listing and export of already-completed final videos
- Memory-safe downsampled review thumbnails; source images are not changed
- Exact desktop subtitle font menu names, with explicit warning/import path where Android lacks the font

## Rendering

The protected renderer still constructs H.264/AAC output commands using `libx264` and AAC. The Android bridge pins `dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7` to retain `libx264`, libass/fontconfig and the existing FFmpeg filter graph.

## Verification result

- Python compile: PASS
- JavaScript syntax: PASS
- Static UI/bridge contract: PASS
- Android port contract tests: **12 passed**
- Protected desktop regression suite against Android core: **121 passed, 1 pre-existing known failure**
- Known failure is unchanged from supplied baseline: Update 22 test expects subtitle font size 19 while current baseline source uses 21
- Host FFmpeg render smoke: PASS
- Render smoke codecs: H.264 video + AAC audio
- Render smoke one-image/one-audio scene mapping: PASS
- Original source archive SHA-256 unchanged: `6ff6b8d7f15729f9e59fdf6be219ab4c984d5796f7dc48cba01599e7b4714c4d`
- Original memory archive SHA-256 unchanged: `4f226b24bcb250097f70461a485592850e624527d4cec27cf26c99aa5cc999e1`

## APK packaging status

The current execution container does not contain Android SDK tools or Gradle and has no outbound package-download connectivity. Therefore it was not technically possible to run AGP/Gradle and create a genuine APK inside this container. No fake APK is included. A pinned Android Studio/Gradle project and GitHub Actions build workflow are included to produce the installable debug APK.

## Distribution note

The `full-gpl` FFmpegKit artifact includes x264. GPL-3.0 obligations apply to APK distribution. A GPL-3.0 license copy and third-party notice are included in the Android assets/source package.
