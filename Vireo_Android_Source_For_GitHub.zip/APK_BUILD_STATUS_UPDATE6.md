# APK Build Status — Android Update 6

Source-level fix and regression suite are complete.
The installable APK must be built via the provided GitHub Actions workflow, because this ChatGPT execution environment does not provide a complete Android SDK/Gradle device build environment.

The GitHub workflow additionally performs source tests, Gradle build, lint and APK-content checks before publishing the APK artifact.
