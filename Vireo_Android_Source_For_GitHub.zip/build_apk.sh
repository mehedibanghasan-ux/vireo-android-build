#!/usr/bin/env bash
set -euo pipefail
if ! command -v java >/dev/null 2>&1; then echo "Java 17+ is required." >&2; exit 2; fi
if ! command -v python3.13 >/dev/null 2>&1 && ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info[:2]==(3,13) else 1)' 2>/dev/null; then echo "Python 3.13 is required by the pinned Chaquopy build." >&2; exit 2; fi
if [[ -z "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" ]]; then echo "Set ANDROID_SDK_ROOT (or ANDROID_HOME) to an Android SDK containing platform 35 and build-tools 35.0.0." >&2; exit 2; fi
python3 tools/verify_android_port.py
if command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon --stacktrace :app:assembleDebug
else
  echo "Gradle 8.13 is required. Open this project in Android Studio or install Gradle 8.13." >&2
  exit 2
fi
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
