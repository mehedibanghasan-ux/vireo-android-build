@echo off
where gradle >nul 2>nul || (echo Gradle 8.13 is required. Open this project in Android Studio or install Gradle 8.13. & exit /b 2)
if "%ANDROID_SDK_ROOT%"=="" if "%ANDROID_HOME%"=="" (echo Set ANDROID_SDK_ROOT or ANDROID_HOME to Android SDK 36. & exit /b 2)
py -3.13 tools\verify_android_port.py || exit /b 1
gradle --no-daemon --stacktrace :app:assembleDebug || exit /b 1
echo APK: app\build\outputs\apk\debug\app-debug.apk
