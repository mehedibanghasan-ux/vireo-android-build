# Vireo Android Update 6 Test Report

## Source/static verification
- Python compileall: PASS
- Android protected-port verifier: PASS
- Android contract tests: 26/26 PASS
- FFmpegBridge Java syntax/type-boundary compile against API stubs: PASS
- Protected paid/provider/core module hash parity: PASS

## Renderer smoke test on host FFmpeg
- 2 rendered scenes: PASS
- final video codec: H.264
- final audio codec: AAC
- stitched/final duration consistency: PASS

## Actual Update5 APK audit used to guide Update6
The user-supplied APK was inspected and contains:
- arm64-v8a FFmpegKit native libraries
- MP3 decoder (`mp3float`)
- AAC decoders
- libx264 support
- libass / `subtitles` filter
- `silencedetect`, `afftdn`, `alimiter`, `zoompan`, `xfade`, `amix`, `aresample`

This rules out the most likely missing-codec/filter packaging causes for the reported audio validation failure.

## Device verification status
Update6 must still be compiled through the existing GitHub Android build and installed on the user's real device. The new on-device preflight is specifically designed to fail before paid API work if the Android native media layer is not actually usable.
