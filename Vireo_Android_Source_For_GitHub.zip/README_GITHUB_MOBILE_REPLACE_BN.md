# মোবাইল থেকে GitHub-এ Update4 Replace করার সহজ নিয়ম

Repository root-এ দুইটি build input থাকবে:
- `Vireo_Android_Source_For_GitHub.zip`
- `.github/workflows/build-vireo.yml`

Update4-এর জন্য পুরোনো source ZIP এবং workflow দুটোই নতুন file দিয়ে replace করতে হবে। বিস্তারিত নির্দেশনা final ChatGPT reply-তেও দেওয়া হবে।

Build successful হলে GitHub Actions artifact-এর নাম হবে `Vireo-Video-Studio-APK` এবং তার ভিতরে থাকবে `Vireo-Video-Studio-Android13-16-Update4.apk`।
