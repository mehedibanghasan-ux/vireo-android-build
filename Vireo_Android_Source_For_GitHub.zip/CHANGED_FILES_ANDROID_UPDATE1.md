# Changed / Added Files — Vireo Android Update 1

## Desktop baseline

No file in the supplied desktop source archive was modified.

## Protected Python copies

Byte-identical copies: `ai33_client.py`, `character_presets.py`, `openai_tools.py`, `pipeline.py`, `project.py`, `runware_client.py`, `scene_splitter.py`, `script_analyzer.py`, `styles.py`, `subtitles.py`.

## Minimal Android adaptations

- `app/src/main/python/app/config.py` — Android writable base-directory indirection only.
- `app/src/main/python/app/renderer.py` — FFmpeg/FFprobe execution bridge only.
- `app/src/main/python/android_bridge.py` — Android orchestration, project lifecycle guard, global preferences and review adapter.
- `app/src/main/python/openai/__init__.py` — small OpenAI-compatible HTTP shim for the Android embedded Python environment while preserving existing retry-visible HTTP status semantics and transcription timestamp fields.

## Native Android files

- `app/src/main/java/com/vireo/studio/MainActivity.java`
- `app/src/main/java/com/vireo/studio/GenerationService.java`
- `app/src/main/java/com/vireo/studio/FFmpegBridge.java`
- `app/src/main/java/com/vireo/studio/ReviewHost.java`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/values/styles.xml`
- `app/src/main/res/values/strings.xml`
- `app/src/main/res/xml/file_paths.xml`

## Mobile UI

- `app/src/main/assets/index.html`
- `app/src/main/assets/app.js`
- `app/src/main/assets/style.css`
- `app/src/main/assets/THIRD_PARTY_NOTICES.txt`
- `app/src/main/assets/licenses/GPL-3.0.txt`

## Build / CI

- `build.gradle`
- `settings.gradle`
- `gradle.properties`
- `app/build.gradle`
- `app/proguard-rules.pro`
- `.github/workflows/android-build.yml`
- `build_apk.sh`
- `build_apk.bat`

## Verification / continuity

- `tools/verify_android_port.py`
- `tools/render_smoke_test.py`
- `port_tests/test_android_port_contracts.py`
- `port_tests/baseline_reference/config.py`
- `port_tests/baseline_reference/renderer.py`
- `port_tests/baseline_reference/protected_sha256.json`
- `README_BUILD.md`
- `ANDROID_PORT_NOTES.md`
- `APK_BUILD_STATUS.md`
- `THIRD_PARTY_NOTICES.md`
- `VIREO_ANDROID_UPDATE1_RELEASE_NOTES.md`
- `VIREO_ANDROID_CONTINUITY_PACK_UPDATE1.md`
- `TEST_REPORT_ANDROID_UPDATE1.md`
- `SOURCE_MANIFEST_SHA256.txt`
