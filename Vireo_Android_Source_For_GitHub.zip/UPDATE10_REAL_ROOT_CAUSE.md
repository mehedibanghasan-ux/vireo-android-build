# Vireo Android Update 10 — Proven Root Causes

## 1. Duplicate visible folders such as `lv_001 (1)`
The visible-workspace mirror had two independent folder-creation paths for the same project:
- `projectKnown` eagerly prepared `Projects/lv_###`, and
- pause/complete synced the full project.

Those SAF operations were launched on a cached thread pool. Both could run `findChild()` before either `createDocument()` became visible to the other. Android's document provider then resolved the second create collision by auto-renaming it to a suffix such as `(1)`. This exactly matches the user's screenshot: one populated level folder and one empty provider-renamed duplicate.

### Fix
- Do not create the visible project folder eagerly on `projectKnown`.
- Mirror the project only on pause/complete or explicit Sync.
- Route all project-folder SAF mirroring through `WorkspaceMirror`, which owns a single-thread executor.
- Keep the app-private `lv_###` project as the authoritative Resume-safe working copy.

## 2. Final video saved/copied in multiple places and manual save requested
Update9 had three output paths/actions:
- protected project final MP4,
- automatic workspace `Exports/` copy on completion,
- manual `Save Final MP4 to Movies/Vireo` MediaStore action.

### Fix
- Remove automatic `Exports/` duplication.
- Remove the manual final-MP4 save UI/action.
- On completion, automatically mirror the complete project, including its final MP4, only under the dedicated visible `Projects/lv_###` folder.

## 3. Generation stopped/reappeared as a fresh app after leaving the app or screen-off/process recreation
Update9 started the real Python generation call from a `MainActivity` executor. `GenerationService` provided only a notification + wake lock and used `START_NOT_STICKY`. Therefore the long-running job was not truly owned by the Android foreground service. If the Activity/process was reclaimed, the service had no persisted generation request/project state from which to restart.

### Fix
- `GenerationService` now owns the `generate_json` call on a single background worker.
- Persist the active request and current protected project path.
- Use `START_STICKY` so Android can recreate the service after process reclamation.
- On recreation, reload the known protected project and invoke the existing Resume path rather than starting paid work blindly.
- Keep the partial wake lock while generation is active so screen-off does not suspend CPU work.
- Re-emit running/project/terminal state when the Activity/WebView is recreated.

No provider, AI33 paid-task, Runware, scene mapping, subtitle, narration, renderer, manifest/checkpoint, or project-core semantics were rewritten.
