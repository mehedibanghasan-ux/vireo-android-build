# Changed Files — Android Update 10

- `app/src/main/java/com/vireo/studio/GenerationService.java`
  - moved generation ownership from Activity executor to foreground service
  - persisted request/current project/terminal state
  - sticky restart + protected Resume re-entry
  - wake-lock retained
- `app/src/main/java/com/vireo/studio/WorkspaceMirror.java` (new)
  - one serialized SAF project mirror path
  - completion/pause auto-sync to `Projects/lv_###`
- `app/src/main/java/com/vireo/studio/MainActivity.java`
  - delegates generation start to service
  - routes project completion events to `WorkspaceMirror`
  - removes automatic Exports/MediaStore final-video duplication
  - re-emits generation state after Activity/WebView recreation
- `app/src/main/assets/app.js`
  - generation now accepts async `started` state
  - removed manual final-save behavior
  - removed eager `Android.prepareProject` call
- `app/src/main/assets/index.html`
  - removed manual final-MP4 save button
  - updated workspace wording
- `app/src/main/AndroidManifest.xml`
  - added media-processing foreground-service permission/type alongside Android 13–14 data-sync compatibility
- `app/build.gradle`
  - versionCode 10 / Update10 versionName
- `port_tests/test_android_port_contracts.py`
  - added Update10 storage/background contracts and updated inherited assertions
- `.github/workflows/android-build.yml`
  - Update10 source/version checks while preserving FINAL CI dependency synchronization

Protected Python production modules were not modified.
