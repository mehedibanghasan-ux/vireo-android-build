# Vireo Android Update 4 — Test Report

## Baseline
- Android source baseline: FIX3, SHA-256 `88f308f99c37a4b9e4c5e5b76423119411d45ea4f567ec97a3cee6952ac1f1a1`.
- Desktop source authority: supplied `vireo_video_studio_update30(2).zip`, SHA-256 `6ff6b8d7f15729f9e59fdf6be219ab4c984d5796f7dc48cba01599e7b4714c4d`.

## Update 4 verification
- `python -m compileall -q app/src/main/python`: PASS.
- `node --check app/src/main/assets/app.js`: PASS.
- `python tools/verify_android_port.py`: PASS.
  - 69 HTML controls/containers discovered.
  - 35 Python bridge methods discovered.
  - 21 Android `@JavascriptInterface` methods discovered.
- `pytest -q port_tests/test_android_port_contracts.py`: **23 passed**.

New Update4 regression coverage includes:
1. PC `.env` whitelist import.
2. API secret non-disclosure.
3. Blank manual key fields preserve stored keys.
4. Subtitle autosave changes subtitle fields only.
5. Script edits detach the loaded Resume target.
6. Old project load preserves the global OpenAI default for new projects.
7. Restored project gets a new protected `lv_###` folder without destructive overwrite.
8. Non-Vireo folders are rejected during restore.
9. Real Android `WindowInsets` status-bar/cutout handling.
10. SAF visible workspace and persisted tree permissions.
11. Update4 mobile parity controls and zero-padded scene labels.
12. Android 13–16 / API 36 / 16-KB compatibility contract.

## Desktop baseline regression
The untouched supplied desktop baseline was independently extracted and tested:
- Python compile: PASS.
- pytest: **121 passed, 1 failed**.
- The one failure is the pre-existing stale Update22 assertion expecting subtitle font size `19`; current supplied `AppSettings` default is `21`.
- Update4 introduces no new desktop-source changes and no new desktop regression.

## Device status
Update4 source is regression-tested and GitHub-build-ready. The rebuilt Update4 APK still requires the final GitHub Actions compile plus installation on the user's real phone for runtime verification of SAF document-provider behavior and an end-to-end paid/network generation.
