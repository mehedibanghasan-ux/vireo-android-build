# Vireo Android Update 9 Test Report

## Local Update 9 source verification
- Python compileall: PASS
- Android static contract verifier: PASS
- Android port contract tests: 31/31 PASS
- JavaScript syntax (`node --check`): PASS
- Secret scan: PASS

## Protected-core parity
Update 9 was diffed against Update 8. These critical files are byte-identical:
- pipeline.py
- ai33_client.py
- runware_client.py
- project.py
- subtitles.py
- renderer.py
- config.py
- android_bridge.py
- MainActivity.java
- FFmpegBridge.java

## Desktop baseline regression
Fresh run from the supplied desktop baseline:
- 121 passed
- 1 known pre-existing stale test failure: Update 22 test expects subtitle font size 19 while current source default is 21.
- No Update 9 desktop code was modified.

## CI gates added for the physical-device runtime failure
The GitHub build must now prove:
- smart-exception-java 0.2.1 resolved on debugRuntimeClasspath
- smart-exception-common 0.2.1 resolved on debugRuntimeClasspath
- APK assemble succeeds
- lint succeeds
- required native libraries are packaged
- `com.arthenica.smartexception.java.Exceptions` is DEFINED in APK DEX using Android apkanalyzer

The final remaining verification is the real GitHub Update 9 build plus physical-device install/resume test.
