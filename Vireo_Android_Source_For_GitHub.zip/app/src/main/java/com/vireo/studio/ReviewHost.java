package com.vireo.studio;
import java.util.concurrent.CountDownLatch;
public final class ReviewHost {
 private static volatile CountDownLatch latch;
 private static volatile String pendingPayload;
 public static void beginReview(String payload) throws InterruptedException { CountDownLatch l=new CountDownLatch(1); latch=l; pendingPayload=payload; MainActivity.emit("review",payload); l.await(); if(latch==l) latch=null; pendingPayload=null; }
 public static void reemitPending(){ String p=pendingPayload; if(p!=null) MainActivity.emit("review",p); }
 public static void continueReview(){ CountDownLatch l=latch; pendingPayload=null; if(l!=null) l.countDown(); }
 private ReviewHost(){}
}
