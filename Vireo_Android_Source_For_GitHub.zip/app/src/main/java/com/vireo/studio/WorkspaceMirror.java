package com.vireo.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.database.Cursor;

import org.json.JSONObject;

import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Serial SAF mirror for Vireo project folders. The protected app-private project
 * remains authoritative; this class only exposes a user-visible mirror.
 */
public final class WorkspaceMirror {
 private static final String PREFS="vireo_android";
 private static final String WORKSPACE_URI="workspace_uri";
 private static final ExecutorService projectSync=Executors.newSingleThreadExecutor();
 private WorkspaceMirror(){}

 public static void handleNativeEvent(Context context,String event,String payload){
  if(context==null||!("paused".equals(event)||"complete".equals(event))) return;
  try{
   JSONObject o=new JSONObject(payload==null?"{}":payload);
   String project=o.optString("project","");
   if(project.isEmpty()&&"complete".equals(event)){
    String fin=o.optString("final","");
    File parent=fin.isEmpty()?null:new File(fin).getParentFile();
    if(parent!=null) project=parent.getAbsolutePath();
   }
   if(!project.isEmpty()) syncProjectAsync(context,project,false);
  }catch(Exception ignored){}
 }

 public static void syncProjectAsync(Context context,String path,boolean notify){
  Context app=context.getApplicationContext();
  projectSync.execute(()->syncProject(app,path,notify));
 }

 private static Uri workspaceTreeUri(Context context){
  String s=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(WORKSPACE_URI,"");
  try{return s.isEmpty()?null:Uri.parse(s);}catch(Exception e){return null;}
 }

 private static Uri rootDocument(Uri tree){
  return DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
 }

 private static Uri findChild(Context context,Uri parent,String name)throws Exception{
  String parentId=DocumentsContract.getDocumentId(parent);
  Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,parentId);
  String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME};
  try(Cursor c=context.getContentResolver().query(children,cols,null,null,null)){
   if(c!=null) while(c.moveToNext()) if(name.equals(c.getString(1))) return DocumentsContract.buildDocumentUriUsingTree(parent,c.getString(0));
  }
  return null;
 }

 private static Uri ensureDir(Context context,Uri parent,String name)throws Exception{
  Uri existing=findChild(context,parent,name); if(existing!=null)return existing;
  Uri made=DocumentsContract.createDocument(context.getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,name);
  if(made==null) throw new IOException("Could not create workspace folder: "+name);
  return made;
 }

 private static Uri ensureFile(Context context,Uri parent,String name,String mime)throws Exception{
  Uri existing=findChild(context,parent,name); if(existing!=null)return existing;
  Uri made=DocumentsContract.createDocument(context.getContentResolver(),parent,mime,name);
  if(made==null) throw new IOException("Could not create workspace file: "+name);
  return made;
 }

 private static String mimeFor(File f){
  String n=f.getName().toLowerCase(Locale.ROOT);
  if(n.endsWith(".mp4"))return "video/mp4"; if(n.endsWith(".json"))return "application/json";
  if(n.endsWith(".txt")||n.endsWith(".srt")||n.endsWith(".ass"))return "text/plain";
  if(n.endsWith(".png"))return "image/png"; if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg";
  if(n.endsWith(".wav"))return "audio/wav"; if(n.endsWith(".mp3"))return "audio/mpeg";
  if(n.endsWith(".ttf"))return "font/ttf"; if(n.endsWith(".otf"))return "font/otf";
  return "application/octet-stream";
 }

 private static void copyLocalFileToDocument(Context context,File src,Uri dst)throws Exception{
  try(InputStream in=new FileInputStream(src); OutputStream out=context.getContentResolver().openOutputStream(dst,"wt")){
   if(out==null) throw new IOException("Workspace output stream unavailable for "+src.getName());
   in.transferTo(out);
  }
 }

 private static void copyLocalTree(Context context,File srcDir,Uri dstDir)throws Exception{
  File[] items=srcDir.listFiles(); if(items==null)return;
  Arrays.sort(items,Comparator.comparing(File::getName,String.CASE_INSENSITIVE_ORDER));
  for(File f:items){
   if(f.isDirectory()){ Uri d=ensureDir(context,dstDir,f.getName()); copyLocalTree(context,f,d); }
   else { Uri d=ensureFile(context,dstDir,f.getName(),mimeFor(f)); copyLocalFileToDocument(context,f,d); }
  }
 }

 private static void syncProject(Context context,String path,boolean notify){
  Uri tree=workspaceTreeUri(context); File src=new File(path);
  if(tree==null||!src.isDirectory()) return;
  try{
   Uri root=rootDocument(tree), projects=ensureDir(context,root,"Projects"), dst=ensureDir(context,projects,src.getName());
   copyLocalTree(context,src,dst);
   if(notify) MainActivity.emit("workspaceSync",new JSONObject().put("project",src.getName()).put("ok",true).toString());
  }catch(Exception e){ if(notify) MainActivity.emit("error","Project workspace sync failed: "+e); }
 }
}
