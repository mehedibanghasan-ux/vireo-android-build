package com.vireo.studio;

import android.app.*;
import android.os.*;
import android.content.*;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.content.ContentValues;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import android.view.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Insets;
import android.database.Cursor;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import android.util.Base64;

import com.chaquo.python.*;
import com.chaquo.python.android.AndroidPlatform;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
 private static volatile MainActivity instance;
 private static final ExecutorService executor=Executors.newCachedThreadPool();
 private static final AtomicBoolean generationRunning=new AtomicBoolean(false);
 private WebView web;
 private PyObject py;

 private static final int OPEN_SCRIPT=501, SAVE_SCRIPT=502, PICK_MUSIC=503, PICK_FONT=504,
     IMPORT_ENV=505, PICK_WORKSPACE=506, PICK_STYLE_PREVIEW=507,
     PICK_REFERENCE_STYLE_TREE=508, IMPORT_PROJECT_TREE=509;
 private static final String PREFS="vireo_android";
 private static final String WORKSPACE_URI="workspace_uri";
 private String pendingSaveText="", pendingSaveTitle="vireo_script.txt";

 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  instance=this;
  if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},101);
  try{
   if(!Python.isStarted()) Python.start(new AndroidPlatform(this));
   Python p=Python.getInstance();
   py=p.getModule("android_bridge");
   py.callAttr("initialize",getFilesDir().getAbsolutePath());
   FFmpegBridge.configure(this,new File(new File(getFilesDir(),"vireo"),"fonts").getAbsolutePath());
   setupWeb();
  }catch(Throwable startupError){ showStartupError(startupError); }
 }

 private void showStartupError(Throwable error){
  TextView v=new TextView(this);
  v.setText("Vireo could not initialize.\n\n"+error.toString()+"\n\nPlease send this exact message to the developer.");
  v.setTextSize(16); v.setPadding(32,48,32,48); v.setTextIsSelectable(true);
  ScrollView s=new ScrollView(this); s.addView(v); setContentView(s);
 }

 private void setupWeb(){
  web=new WebView(this);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){
    super.onPageFinished(view,url);
    ReviewHost.reemitPending();
    emit("generationState","{\"running\":"+generationRunning.get()+"}");
    emitWorkspaceState();
   }
  });
  web.addJavascriptInterface(new NativeBridge(),"Android");
  setContentView(web);
  applySystemBarInsets(web);
  web.loadUrl("file:///android_asset/index.html");
 }

 private void applySystemBarInsets(View target){
  target.setOnApplyWindowInsetsListener((v,insets)->{
   int left=0,top=0,right=0,bottom=0;
   if(Build.VERSION.SDK_INT>=30){
    Insets i=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
    left=i.left; top=i.top; right=i.right; bottom=i.bottom;
   }else{
    left=insets.getSystemWindowInsetLeft(); top=insets.getSystemWindowInsetTop();
    right=insets.getSystemWindowInsetRight(); bottom=insets.getSystemWindowInsetBottom();
   }
   v.setPadding(left,top,right,bottom);
   return insets;
  });
  target.requestApplyInsets();
 }

 public static void emit(String event,String payload){
  MainActivity a=instance;
  if(a==null) return;
  // Workspace mirroring is an Android adapter concern. It never replaces the
  // authoritative private project folder used by Vireo's protected Resume logic.
  if(event.equals("projectKnown")||event.equals("paused")||event.equals("complete")){
   try{
    org.json.JSONObject o=new org.json.JSONObject(payload);
    String project=o.optString("project","");
    if(project.isEmpty() && event.equals("complete")){
     String fin=o.optString("final","");
     if(!fin.isEmpty()){ File parent=new File(fin).getParentFile(); if(parent!=null) project=parent.getAbsolutePath(); }
    }
    final String syncProject=project;
    final String finalVideo=o.optString("final","");
    if(!syncProject.isEmpty()){
     if(event.equals("projectKnown")) executor.execute(()->a.prepareProjectInWorkspace(syncProject));
     else executor.execute(()->a.syncProjectToWorkspace(syncProject,false));
    }
    if(event.equals("complete")&&!finalVideo.isEmpty()) executor.execute(()->a.copyFinalToWorkspaceExports(finalVideo));
   }catch(Exception ignored){}
  }
  if(a.web==null) return;
  a.runOnUiThread(()->{
   if(event.equals("progress")){
    try{ org.json.JSONObject o=new org.json.JSONObject(payload); GenerationService.update(o.optString("message","Working…")); }catch(Exception ignored){}
   }
   String js="window.VireoNative&&window.VireoNative.emit("+org.json.JSONObject.quote(event)+","+org.json.JSONObject.quote(payload)+")";
   a.web.evaluateJavascript(js,null);
  });
 }

 private void result(String id, boolean ok, String value){
  if(web==null)return;
  runOnUiThread(()->{ if(web==null)return; web.evaluateJavascript("window.VireoNative&&window.VireoNative.result("+org.json.JSONObject.quote(id)+","+ok+","+org.json.JSONObject.quote(value==null?"":value)+")",null); });
 }

 private String readUri(Uri uri)throws Exception{
  try(InputStream in=getContentResolver().openInputStream(uri)){
   if(in==null) throw new IOException("Unable to open selected file.");
   return new String(in.readAllBytes(),StandardCharsets.UTF_8);
  }
 }

 private String queryDisplayName(Uri uri)throws Exception{
  try(Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
   if(c!=null&&c.moveToFirst()){
    String n=c.getString(0); if(n!=null&&!n.trim().isEmpty()) return n;
   }
  }
  return "imported";
 }

 private String importUri(Uri uri,String folder)throws Exception{
  String name=queryDisplayName(uri);
  File dir=new File(new File(getFilesDir(),"vireo"),folder); dir.mkdirs();
  File dst=uniqueLocalFile(dir,sanitizeName(name));
  try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(dst)){
   if(in==null) throw new IOException("Unable to open selected file."); in.transferTo(out);
  }
  return dst.getAbsolutePath();
 }

 private static String sanitizeName(String name){
  String out=(name==null?"imported":name).replaceAll("[^A-Za-z0-9._ -]","_").trim();
  return out.isEmpty()?"imported":out;
 }

 private static File uniqueLocalFile(File dir,String name){
  File f=new File(dir,name); if(!f.exists()) return f;
  String base=name,ext=""; int dot=name.lastIndexOf('.');
  if(dot>0){ base=name.substring(0,dot); ext=name.substring(dot); }
  for(int i=2;;i++){ f=new File(dir,base+"_"+i+ext); if(!f.exists()) return f; }
 }

 @Override protected void onActivityResult(int req,int res,Intent data){
  super.onActivityResult(req,res,data);
  if(res!=RESULT_OK||data==null)return;
  try{
   if(req==OPEN_SCRIPT){ emit("scriptLoaded",new org.json.JSONObject().put("text",readUri(data.getData())).toString()); }
   else if(req==SAVE_SCRIPT){
    try(OutputStream out=getContentResolver().openOutputStream(data.getData())){ if(out==null) throw new IOException("Unable to save selected document."); out.write(pendingSaveText.getBytes(StandardCharsets.UTF_8)); }
    emit("toast","Script saved");
   }
   else if(req==PICK_MUSIC){ String p=importUri(data.getData(),"music"); emit("mediaImported",new org.json.JSONObject().put("type","music").put("path",p).toString()); mirrorLibraryFile(new File(p),"Music"); }
   else if(req==PICK_FONT){
    String p=importUri(data.getData(),"fonts"); String low=p.toLowerCase(java.util.Locale.ROOT);
    if(!low.endsWith(".ttf")&&!low.endsWith(".otf")){ new File(p).delete(); throw new IOException("Choose a .ttf or .otf font file."); }
    FFmpegBridge.configure(MainActivity.this,new File(new File(getFilesDir(),"vireo"),"fonts").getAbsolutePath());
    emit("mediaImported",new org.json.JSONObject().put("type","font").put("path",p).toString()); mirrorLibraryFile(new File(p),"Fonts");
   }
   else if(req==IMPORT_ENV){
    final String envText=readUri(data.getData());
    executor.execute(()->{ try{ String out=py.callAttr("import_env_json",envText).toString(); emit("envImported",out); }catch(Throwable e){ emit("error",e.toString()); } });
   }
   else if(req==PICK_STYLE_PREVIEW){
    String p=importUri(data.getData(),"style_previews"); emit("mediaImported",new org.json.JSONObject().put("type","style preview").put("path",p).toString()); mirrorLibraryFile(new File(p),"Style_Previews");
   }
   else if(req==PICK_WORKSPACE){
    persistTreePermission(data); getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(WORKSPACE_URI,data.getData().toString()).apply();
    ensureWorkspaceStructure(); emitWorkspaceState(); executor.execute(this::syncLibrariesToWorkspace);
   }
   else if(req==PICK_REFERENCE_STYLE_TREE){
    persistTreePermission(data); final Uri tree=data.getData(); executor.execute(()->importTreeIntoPrivate(tree,"reference_styles","reference style"));
   }
   else if(req==IMPORT_PROJECT_TREE){
    persistTreePermission(data); final Uri tree=data.getData(); executor.execute(()->importProjectTree(tree));
   }
  }catch(Exception e){ emit("error",e.toString()); }
 }

 private void persistTreePermission(Intent data){
  Uri uri=data.getData(); if(uri==null)return;
  int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
  try{ getContentResolver().takePersistableUriPermission(uri,flags); }catch(Exception ignored){}
 }

 private void pick(String mime,int req){
  Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType(mime); i.addCategory(Intent.CATEGORY_OPENABLE);
  i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,req);
 }

 private void pickTree(int req){
  Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
  i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
  startActivityForResult(i,req);
 }

 private Uri workspaceTreeUri(){
  String s=getSharedPreferences(PREFS,MODE_PRIVATE).getString(WORKSPACE_URI,"");
  try{return s.isEmpty()?null:Uri.parse(s);}catch(Exception e){return null;}
 }

 private Uri rootDocument(Uri tree){
  return DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
 }

 private Uri findChild(Uri parent,String name)throws Exception{
  String parentId=DocumentsContract.getDocumentId(parent);
  Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,parentId);
  String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME};
  try(Cursor c=getContentResolver().query(children,cols,null,null,null)){
   if(c!=null) while(c.moveToNext()) if(name.equals(c.getString(1))) return DocumentsContract.buildDocumentUriUsingTree(parent,c.getString(0));
  }
  return null;
 }

 private Uri ensureDir(Uri parent,String name)throws Exception{
  Uri existing=findChild(parent,name); if(existing!=null)return existing;
  Uri made=DocumentsContract.createDocument(getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,name);
  if(made==null) throw new IOException("Could not create workspace folder: "+name); return made;
 }

 private Uri ensureFile(Uri parent,String name,String mime)throws Exception{
  Uri existing=findChild(parent,name); if(existing!=null)return existing;
  Uri made=DocumentsContract.createDocument(getContentResolver(),parent,mime,name);
  if(made==null) throw new IOException("Could not create workspace file: "+name); return made;
 }

 private void ensureWorkspaceStructure(){
  Uri tree=workspaceTreeUri(); if(tree==null)return;
  try{
   Uri root=rootDocument(tree);
   for(String n:new String[]{"Projects","Music","Fonts","Style_Previews","Reference_Styles","Exports"}) ensureDir(root,n);
  }catch(Exception e){ emit("error","Workspace setup failed: "+e); }
 }

 private String documentDisplayName(Uri doc){
  try(Cursor c=getContentResolver().query(doc,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
   if(c!=null&&c.moveToFirst()){String n=c.getString(0);return n==null?"Selected folder":n;}
  }catch(Exception ignored){}
  return "Selected folder";
 }

 private void emitWorkspaceState(){
  Uri tree=workspaceTreeUri();
  try{
   org.json.JSONObject o=new org.json.JSONObject(); o.put("configured",tree!=null);
   o.put("name",tree==null?"Not selected":documentDisplayName(rootDocument(tree)));
   emit("workspaceState",o.toString());
  }catch(Exception ignored){}
 }

 private void copyLocalFileToDocument(File src,Uri dst)throws Exception{
  try(InputStream in=new FileInputStream(src); OutputStream out=getContentResolver().openOutputStream(dst,"wt")){
   if(out==null) throw new IOException("Workspace output stream unavailable for "+src.getName()); in.transferTo(out);
  }
 }

 private String mimeFor(File f){
  String n=f.getName().toLowerCase(Locale.ROOT);
  if(n.endsWith(".mp4"))return "video/mp4"; if(n.endsWith(".json"))return "application/json";
  if(n.endsWith(".txt")||n.endsWith(".srt")||n.endsWith(".ass"))return "text/plain";
  if(n.endsWith(".png"))return "image/png"; if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg";
  if(n.endsWith(".wav"))return "audio/wav"; if(n.endsWith(".mp3"))return "audio/mpeg";
  if(n.endsWith(".ttf"))return "font/ttf"; if(n.endsWith(".otf"))return "font/otf";
  return "application/octet-stream";
 }

 private void copyLocalTree(File srcDir,Uri dstDir)throws Exception{
  File[] items=srcDir.listFiles(); if(items==null)return;
  Arrays.sort(items,Comparator.comparing(File::getName,String.CASE_INSENSITIVE_ORDER));
  for(File f:items){
   if(f.isDirectory()){ Uri d=ensureDir(dstDir,f.getName()); copyLocalTree(f,d); }
   else { Uri d=ensureFile(dstDir,f.getName(),mimeFor(f)); copyLocalFileToDocument(f,d); }
  }
 }

 private boolean syncProjectToWorkspace(String path,boolean notify){
  Uri tree=workspaceTreeUri(); File src=new File(path);
  if(tree==null||!src.isDirectory()) return false;
  try{
   Uri root=rootDocument(tree), projects=ensureDir(root,"Projects"), dst=ensureDir(projects,src.getName());
   copyLocalTree(src,dst);
   if(notify) emit("workspaceSync",new org.json.JSONObject().put("project",src.getName()).put("ok",true).toString());
   return true;
  }catch(Exception e){ if(notify) emit("error","Project workspace sync failed: "+e); return false; }
 }

 private void prepareProjectInWorkspace(String path){
  Uri tree=workspaceTreeUri(); File src=new File(path); if(tree==null)return;
  try{ Uri root=rootDocument(tree), projects=ensureDir(root,"Projects"); ensureDir(projects,src.getName()); }
  catch(Exception e){ emit("error","Could not prepare visible project folder: "+e); }
 }

 private void copyFinalToWorkspaceExports(String path){
  Uri tree=workspaceTreeUri(); File src=new File(path); if(tree==null||!src.isFile())return;
  try{ Uri root=rootDocument(tree), exp=ensureDir(root,"Exports"), dst=ensureFile(exp,src.getName(),"video/mp4"); copyLocalFileToDocument(src,dst); }
  catch(Exception e){ emit("error","Workspace export copy failed: "+e); }
 }

 private void mirrorLibraryFile(File src,String workspaceFolder){
  if(workspaceTreeUri()==null||!src.isFile())return;
  executor.execute(()->{
   try{Uri root=rootDocument(workspaceTreeUri()), d=ensureDir(root,workspaceFolder), out=ensureFile(d,src.getName(),mimeFor(src));copyLocalFileToDocument(src,out);}catch(Exception ignored){}
  });
 }

 private void syncLibrariesToWorkspace(){
  Uri tree=workspaceTreeUri(); if(tree==null)return;
  try{
   File base=new File(getFilesDir(),"vireo"); Uri root=rootDocument(tree);
   String[][] map={{"music","Music"},{"fonts","Fonts"},{"style_previews","Style_Previews"},{"reference_styles","Reference_Styles"}};
   for(String[] m:map){ File src=new File(base,m[0]); if(src.isDirectory()) copyLocalTree(src,ensureDir(root,m[1])); }
   emit("workspaceSync","{\"libraries\":true,\"ok\":true}");
  }catch(Exception e){ emit("error","Library workspace sync failed: "+e); }
 }

 private void copyDocumentTreeToLocal(Uri parent,File dst)throws Exception{
  dst.mkdirs(); String id=DocumentsContract.getDocumentId(parent); Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,id);
  String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
  try(Cursor c=getContentResolver().query(children,cols,null,null,null)){
   if(c==null)return;
   while(c.moveToNext()){
    Uri child=DocumentsContract.buildDocumentUriUsingTree(parent,c.getString(0)); String name=sanitizeName(c.getString(1)); String mime=c.getString(2);
    File out=uniqueLocalFile(dst,name);
    if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) copyDocumentTreeToLocal(child,out);
    else try(InputStream in=getContentResolver().openInputStream(child); OutputStream os=new FileOutputStream(out)){ if(in!=null)in.transferTo(os); }
   }
  }
 }

 private void importTreeIntoPrivate(Uri tree,String privateFolder,String type){
  try{
   Uri root=rootDocument(tree); String name=sanitizeName(documentDisplayName(root)); File parent=new File(new File(getFilesDir(),"vireo"),privateFolder); parent.mkdirs(); File dst=uniqueLocalFile(parent,name); dst.mkdirs();
   copyDocumentTreeToLocal(root,dst); emit("mediaImported",new org.json.JSONObject().put("type",type).put("path",dst.getAbsolutePath()).toString());
   if(privateFolder.equals("reference_styles")) executor.execute(this::syncLibrariesToWorkspace);
  }catch(Exception e){ emit("error","Folder import failed: "+e); }
 }

 private void importProjectTree(Uri tree){
  File temp=null;
  try{
   Uri root=rootDocument(tree); String name=sanitizeName(documentDisplayName(root));
   temp=new File(getCacheDir(),"vireo_project_import_"+System.currentTimeMillis()); temp.mkdirs(); copyDocumentTreeToLocal(root,temp);
   org.json.JSONObject req=new org.json.JSONObject().put("path",temp.getAbsolutePath()).put("sourceName",name);
   String out=py.callAttr("restore_project_json",req.toString()).toString(); emit("projectRestored",out);
  }catch(Throwable e){ emit("error","Project restore failed: "+e); }
  finally{ if(temp!=null) deleteTree(temp); }
 }

 private static void deleteTree(File f){ if(f==null||!f.exists())return; if(f.isDirectory()){File[] c=f.listFiles();if(c!=null)for(File x:c)deleteTree(x);} try{f.delete();}catch(Exception ignored){} }

 private void saveVideoToMovies(String path) throws Exception {
  File src=new File(path); if(!src.isFile()||src.length()<=0) throw new IOException("Final MP4 is missing or empty: "+path);
  ContentValues v=new ContentValues(); v.put(MediaStore.Video.Media.DISPLAY_NAME,src.getName()); v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); v.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/Vireo"); v.put(MediaStore.Video.Media.IS_PENDING,1);
  Uri u=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v); if(u==null)throw new IOException("MediaStore insert failed");
  try{
   try(InputStream in=new FileInputStream(src);OutputStream out=getContentResolver().openOutputStream(u)){ if(out==null) throw new IOException("MediaStore output stream failed"); in.transferTo(out); }
   ContentValues done=new ContentValues(); done.put(MediaStore.Video.Media.IS_PENDING,0); getContentResolver().update(u,done,null,null);
  }catch(Exception e){ getContentResolver().delete(u,null,null); throw e; }
 }

 @Override public void onBackPressed(){ if(generationRunning.get()){ moveTaskToBack(true); return; } super.onBackPressed(); }
 @Override protected void onDestroy(){ if(instance==this) instance=null; WebView old=web; web=null; if(old!=null) old.destroy(); super.onDestroy(); }

 public class NativeBridge {
  @JavascriptInterface public String bootstrap(){ try{return py.callAttr("bootstrap").toString();}catch(Exception e){return "{\"error\":"+org.json.JSONObject.quote(e.toString())+"}";} }
  @JavascriptInterface public void invoke(String method,String payload,String id){
   executor.execute(()->{
    boolean ownsGeneration=false;
    try{
     if(method.equals("generate_json")){
      if(!generationRunning.compareAndSet(false,true)){ result(id,false,"A Vireo generation is already running. Duplicate generation was blocked."); return; }
      ownsGeneration=true; startForegroundService(new Intent(MainActivity.this,GenerationService.class)); emit("generationState","{\"running\":true}");
     }
     String v=py.callAttr(method,payload==null?"":payload).toString(); result(id,true,v);
    }catch(Throwable e){ result(id,false,e.toString()); }
    finally{
     if(ownsGeneration){ generationRunning.set(false); stopService(new Intent(MainActivity.this,GenerationService.class)); emit("generationState","{\"running\":false}"); }
    }
   });
  }
  @JavascriptInterface public String imageDataUrl(String path){
   try{
    BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true; BitmapFactory.decodeFile(path,bounds);
    int sample=1, maxSide=Math.max(bounds.outWidth,bounds.outHeight); while(maxSide/sample>1280) sample*=2;
    BitmapFactory.Options opts=new BitmapFactory.Options(); opts.inSampleSize=Math.max(1,sample); Bitmap bitmap=BitmapFactory.decodeFile(path,opts);
    if(bitmap==null) return ""; ByteArrayOutputStream out=new ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG,86,out); bitmap.recycle();
    return "data:image/jpeg;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
   }catch(Exception e){return "";}
  }
  @JavascriptInterface public void continueReview(){ ReviewHost.continueReview(); }
  @JavascriptInterface public void pause(){ executor.execute(()->{try{py.callAttr("pause_json","");}catch(Exception ignored){}}); }
  @JavascriptInterface public void openScript(){ runOnUiThread(()->pick("text/*",OPEN_SCRIPT)); }
  @JavascriptInterface public void pasteScript(){ runOnUiThread(()->{ android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); android.content.ClipData clip=cm.getPrimaryClip(); if(clip!=null&&clip.getItemCount()>0){ CharSequence text=clip.getItemAt(0).coerceToText(MainActivity.this); String value=text==null?"":text.toString(); emit("scriptPasted","{\"text\":"+org.json.JSONObject.quote(value)+"}"); } }); }
  @JavascriptInterface public void saveScript(String text){ pendingSaveText=text; pendingSaveTitle="vireo_script.txt"; runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,pendingSaveTitle);startActivityForResult(i,SAVE_SCRIPT);}); }
  @JavascriptInterface public void saveText(String text,String title){ pendingSaveText=text; pendingSaveTitle=(title==null||title.trim().isEmpty())?"vireo_export.txt":title; runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,pendingSaveTitle);startActivityForResult(i,SAVE_SCRIPT);}); }
  @JavascriptInterface public void copyText(String text){ android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("Vireo",text)); }
  @JavascriptInterface public void importMusic(){ runOnUiThread(()->pick("audio/*",PICK_MUSIC)); }
  @JavascriptInterface public void importFont(){ runOnUiThread(()->pick("*/*",PICK_FONT)); }
  @JavascriptInterface public void importEnv(){ runOnUiThread(()->pick("*/*",IMPORT_ENV)); }
  @JavascriptInterface public void chooseWorkspace(){ runOnUiThread(()->pickTree(PICK_WORKSPACE)); }
  @JavascriptInterface public void importStylePreview(){ runOnUiThread(()->pick("image/*",PICK_STYLE_PREVIEW)); }
  @JavascriptInterface public void importReferenceStyleFolder(){ runOnUiThread(()->pickTree(PICK_REFERENCE_STYLE_TREE)); }
  @JavascriptInterface public void importProjectFolder(){ runOnUiThread(()->pickTree(IMPORT_PROJECT_TREE)); }
  @JavascriptInterface public void syncProject(String path){ executor.execute(()->syncProjectToWorkspace(path,true)); }
  @JavascriptInterface public void prepareProject(String path){ executor.execute(()->prepareProjectInWorkspace(path)); }
  @JavascriptInterface public void syncLibraries(){ executor.execute(MainActivity.this::syncLibrariesToWorkspace); }
  @JavascriptInterface public void saveVideo(String path,String id){ executor.execute(()->{try{saveVideoToMovies(path);copyFinalToWorkspaceExports(path);result(id,true,"Saved to Movies/Vireo"+(workspaceTreeUri()!=null?" and workspace Exports":""));}catch(Exception e){result(id,false,e.toString());}}); }
 }
}
