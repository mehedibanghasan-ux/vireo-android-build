package com.vireo.studio;
import android.app.*; import android.content.*; import android.os.*;
public class GenerationService extends Service {
 public static final String CHANNEL="vireo_generation"; private static volatile GenerationService current; private PowerManager.WakeLock wakeLock;
 @Override public void onCreate(){ super.onCreate(); current=this; NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Vireo generation",NotificationManager.IMPORTANCE_LOW)); PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE); wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Vireo:Generation"); wakeLock.setReferenceCounted(false); wakeLock.acquire(); }
 private Notification n(String text){ Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP); PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT); return new Notification.Builder(this,CHANNEL).setContentTitle("Vireo Video Studio").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download).setContentIntent(pi).setOngoing(true).build(); }
 @Override public int onStartCommand(Intent i,int f,int id){ startForeground(33,n("Generating video…")); return START_NOT_STICKY; }
 public static void update(String text){ GenerationService s=current; if(s!=null) s.getSystemService(NotificationManager.class).notify(33,s.n(text.length()>90?text.substring(0,90):text)); }
 @Override public void onDestroy(){ current=null; if(wakeLock!=null&&wakeLock.isHeld()) wakeLock.release(); wakeLock=null; super.onDestroy(); }
 @Override public android.os.IBinder onBind(Intent i){ return null; }
}
