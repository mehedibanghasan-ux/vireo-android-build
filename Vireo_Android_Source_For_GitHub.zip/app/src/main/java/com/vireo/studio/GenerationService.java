package com.vireo.studio;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Owns long-running generation independently of MainActivity/WebView lifetime.
 * The generation request and current project path are persisted so Android can
 * restart this foreground service after process reclamation and resume from
 * Vireo's existing protected project checkpoints instead of starting over.
 */
public class GenerationService extends Service {
 public static final String CHANNEL="vireo_generation";
 private static final int NOTIFICATION_ID=33;
 private static final String ACTION_GENERATE="com.vireo.studio.GENERATE";
 private static final String EXTRA_PAYLOAD="payload";
 private static final String PREFS="vireo_generation_runtime";
 private static final String KEY_ACTIVE="active";
 private static final String KEY_PAYLOAD="payload";
 private static final String KEY_PROJECT="project";
 private static final String KEY_TERMINAL_EVENT="terminal_event";
 private static final String KEY_TERMINAL_PAYLOAD="terminal_payload";

 private static final ExecutorService worker=Executors.newSingleThreadExecutor();
 private static final AtomicBoolean workerRunning=new AtomicBoolean(false);
 private static volatile GenerationService current;
 private static volatile Context applicationContext;
 private PowerManager.WakeLock wakeLock;

 @Override public void onCreate(){
  super.onCreate(); current=this; applicationContext=getApplicationContext();
  NotificationManager nm=getSystemService(NotificationManager.class);
  nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Vireo generation",NotificationManager.IMPORTANCE_LOW));
  PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
  wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Vireo:Generation");
  wakeLock.setReferenceCounted(false);
  wakeLock.acquire();
 }

 private Notification n(String text){
  Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  return new Notification.Builder(this,CHANNEL)
      .setContentTitle("Vireo Video Studio")
      .setContentText(text)
      .setSmallIcon(android.R.drawable.stat_sys_download)
      .setContentIntent(pi).setOnlyAlertOnce(true).setOngoing(true).build();
 }

 @Override public int onStartCommand(Intent i,int flags,int startId){
  if(Build.VERSION.SDK_INT>=35) startForeground(NOTIFICATION_ID,n("Generating video…"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING);
  else if(Build.VERSION.SDK_INT>=29) startForeground(NOTIFICATION_ID,n("Generating video…"),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
  else startForeground(NOTIFICATION_ID,n("Generating video…"));
  String incoming=i==null?null:i.getStringExtra(EXTRA_PAYLOAD);
  if(incoming!=null&&!incoming.trim().isEmpty()) prefs().edit().putString(KEY_PAYLOAD,incoming).putBoolean(KEY_ACTIVE,true).apply();
  if(isGenerationActive(this)) launchPersistedGeneration();
  else stopSelf();
  return START_STICKY;
 }

 private SharedPreferences prefs(){ return getSharedPreferences(PREFS,MODE_PRIVATE); }

 public static synchronized boolean requestGeneration(Context context,String payload){
  SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
  if(p.getBoolean(KEY_ACTIVE,false)) return false;
  p.edit().putBoolean(KEY_ACTIVE,true).putString(KEY_PAYLOAD,payload==null?"":payload)
      .remove(KEY_PROJECT).remove(KEY_TERMINAL_EVENT).remove(KEY_TERMINAL_PAYLOAD).commit();
  Intent i=new Intent(context,GenerationService.class).setAction(ACTION_GENERATE).putExtra(EXTRA_PAYLOAD,payload==null?"":payload);
  context.startForegroundService(i);
  return true;
 }

 public static Context appContext(){ return applicationContext; }

 public static boolean isGenerationActive(Context context){
  return context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getBoolean(KEY_ACTIVE,false);
 }

 public static String currentProject(Context context){
  return context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY_PROJECT,"");
 }

 /** Called by MainActivity.emit even when no Activity instance exists. */
 public static void recordNativeEvent(Context context,String event,String payload){
  SharedPreferences.Editor e=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit();
  try{
   if("projectKnown".equals(event)||"paused".equals(event)||"complete".equals(event)){
    JSONObject o=new JSONObject(payload==null?"{}":payload);
    String project=o.optString("project","");
    if(project.isEmpty()&&"complete".equals(event)){
     String fin=o.optString("final","");
     File parent=fin.isEmpty()?null:new File(fin).getParentFile();
     if(parent!=null) project=parent.getAbsolutePath();
    }
    if(!project.isEmpty()) e.putString(KEY_PROJECT,project);
   }
   if("paused".equals(event)||"complete".equals(event)){
    e.putString(KEY_TERMINAL_EVENT,event).putString(KEY_TERMINAL_PAYLOAD,payload==null?"{}":payload);
   }
  }catch(Exception ignored){}
  e.apply();
 }

 public static void reemitRuntimeState(Context context){
  boolean running=isGenerationActive(context);
  MainActivity.emit("generationState","{\"running\":"+running+"}");
  String project=currentProject(context);
  if(running&&!project.isEmpty()){
   try{ MainActivity.emit("projectKnown",new JSONObject().put("project",project).toString()); }catch(Exception ignored){}
  }
  SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
  String event=p.getString(KEY_TERMINAL_EVENT,"");
  String payload=p.getString(KEY_TERMINAL_PAYLOAD,"");
  if(!event.isEmpty()&&!payload.isEmpty()){
   p.edit().remove(KEY_TERMINAL_EVENT).remove(KEY_TERMINAL_PAYLOAD).apply();
   MainActivity.emit(event,payload);
  }
 }

 private void launchPersistedGeneration(){
  if(!workerRunning.compareAndSet(false,true)) return;
  worker.execute(()->{
   try{
    String payload=prefs().getString(KEY_PAYLOAD,"");
    if(payload.trim().isEmpty()) throw new IllegalStateException("Persisted generation request is missing.");
    if(!Python.isStarted()) Python.start(new AndroidPlatform(getApplicationContext()));
    Python p=Python.getInstance();
    PyObject bridge=p.getModule("android_bridge");
    bridge.callAttr("initialize",getFilesDir().getAbsolutePath());
    FFmpegBridge.configure(getApplicationContext(),new File(new File(getFilesDir(),"vireo"),"fonts").getAbsolutePath());

    String project=prefs().getString(KEY_PROJECT,"");
    if(!project.isEmpty()&&new File(project).isDirectory()){
     bridge.callAttr("load_project_json",new JSONObject().put("path",project).toString());
    }

    MainActivity.emit("generationState","{\"running\":true}");
    String out=bridge.callAttr("generate_json",payload).toString();
    try{
     JSONObject result=new JSONObject(out);
     String status=result.optString("status","");
     if(("complete".equals(status)||"paused".equals(status))&&prefs().getString(KEY_TERMINAL_EVENT,"").isEmpty()){
      recordNativeEvent(getApplicationContext(),status,result.toString());
      MainActivity.emit(status,result.toString());
     }
    }catch(Exception ignored){}
   }catch(Throwable e){
    String msg="Generation stopped unexpectedly: "+e;
    prefs().edit().putString(KEY_TERMINAL_EVENT,"error").putString(KEY_TERMINAL_PAYLOAD,msg).apply();
    MainActivity.emit("error",msg);
   }finally{
    prefs().edit().putBoolean(KEY_ACTIVE,false).remove(KEY_PAYLOAD).apply();
    workerRunning.set(false);
    MainActivity.emit("generationState","{\"running\":false}");
    stopForeground(STOP_FOREGROUND_REMOVE);
    stopSelf();
   }
  });
 }

 public static void update(String text){
  GenerationService s=current;
  if(s!=null){ String shown=text==null?"Working…":text; s.getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,s.n(shown.length()>90?shown.substring(0,90):shown)); }
 }

 @Override public void onDestroy(){
  current=null;
  if(wakeLock!=null&&wakeLock.isHeld()) wakeLock.release();
  wakeLock=null;
  super.onDestroy();
 }

 @Override public android.os.IBinder onBind(Intent i){ return null; }
}
