package com.vireo.studio;

import android.content.Context;
import com.arthenica.ffmpegkit.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;

public final class FFmpegBridge {
 private static Context appContext;
 private static String customFontDir;
 private static volatile boolean configured=false;
 private static volatile boolean selfTestPassed=false;

 public static synchronized void configure(Context context, String fontDir) {
  appContext=context.getApplicationContext();
  customFontDir=fontDir;
  configured=false;
  selfTestPassed=false;
 }

 private static synchronized void ensureConfigured() {
  if(configured) return;
  if(appContext==null) throw new IllegalStateException("FFmpegBridge is not initialized.");
  FFmpegKitConfig.setFontDirectoryList(appContext, Arrays.asList("/system/fonts", customFontDir), Collections.emptyMap());
  configured=true;
 }

 private static String[] args(String json) throws Exception {
  JSONArray a=new JSONArray(json);
  String[] out=new String[a.length()];
  for(int i=0;i<a.length();i++) out[i]=a.getString(i);
  return out;
 }

 public static String executeJson(String json) throws Exception {
  ensureConfigured();
  FFmpegSession s=FFmpegKit.executeWithArguments(args(json));
  String logs=s.getAllLogsAsString();
  if(!ReturnCode.isSuccess(s.getReturnCode())) throw new RuntimeException(logs+"\n"+s.getFailStackTrace());
  return logs;
 }

 public static String executeForLogsJson(String json) throws Exception { return executeJson(json); }

 public static String probeJson(String json) throws Exception {
  ensureConfigured();
  FFprobeSession s=FFprobeKit.executeWithArguments(args(json));
  String out=s.getOutput();
  if(!ReturnCode.isSuccess(s.getReturnCode())) throw new RuntimeException(out+"\n"+s.getFailStackTrace());
  return out;
 }

 private static Object invokeNoArg(Object target, String method) {
  if(target==null) return null;
  try {
   Method m=target.getClass().getMethod(method);
   return m.invoke(target);
  } catch(Exception ignored) {
   return null;
  }
 }

 private static String stringValue(Object value) {
  if(value==null || value==JSONObject.NULL) return null;
  String text=String.valueOf(value).trim();
  return text.isEmpty() ? null : text;
 }

 private static String firstString(JSONObject object, String... keys) {
  for(String key:keys) {
   String value=stringValue(object.opt(key));
   if(value!=null) return value;
  }
  return null;
 }

 private static JSONObject normalizedStream(Object stream) throws Exception {
  JSONObject out=new JSONObject();
  Object rawProperties=invokeNoArg(stream,"getAllProperties");
  Object wrapped=JSONObject.wrap(rawProperties);
  if(wrapped instanceof JSONObject) out=new JSONObject(wrapped.toString());

  String type=firstString(out,"codec_type","type","codecType");
  if(type==null) type=stringValue(invokeNoArg(stream,"getType"));
  if(type!=null) out.put("codec_type",type);

  String duration=firstString(out,"duration");
  if(duration==null) duration=stringValue(invokeNoArg(stream,"getDuration"));
  if(duration!=null) out.put("duration",duration);

  String timeBase=firstString(out,"time_base","timeBase");
  if(timeBase==null) timeBase=stringValue(invokeNoArg(stream,"getTimeBase"));
  if(timeBase!=null) out.put("time_base",timeBase);

  String durationTs=firstString(out,"duration_ts","durationTs");
  if(durationTs==null) durationTs=stringValue(invokeNoArg(stream,"getDurationTs"));
  if(durationTs!=null) out.put("duration_ts",durationTs);
  return out;
 }

 private static JSONObject normalizeMediaInformation(MediaInformation info) throws Exception {
  JSONObject raw=new JSONObject();
  Object wrapped=JSONObject.wrap(info.getAllProperties());
  if(wrapped instanceof JSONObject) raw=new JSONObject(wrapped.toString());
  JSONObject out=new JSONObject(raw.toString());

  JSONArray normalizedStreams=new JSONArray();
  JSONArray rawStreams=raw.optJSONArray("streams");
  if(rawStreams!=null) {
   for(int i=0;i<rawStreams.length();i++) {
    Object item=rawStreams.opt(i);
    if(item instanceof JSONObject) {
     JSONObject stream=new JSONObject(item.toString());
     String type=firstString(stream,"codec_type","type","codecType");
     if(type!=null) stream.put("codec_type",type);
     String timeBase=firstString(stream,"time_base","timeBase");
     if(timeBase!=null) stream.put("time_base",timeBase);
     String durationTs=firstString(stream,"duration_ts","durationTs");
     if(durationTs!=null) stream.put("duration_ts",durationTs);
     normalizedStreams.put(stream);
    }
   }
  }

  // Some FFmpegKit object-model builds don't expose stream entries under the
  // same JSON keys as CLI ffprobe. Rebuild streams from the Java API if needed.
  if(normalizedStreams.length()==0) {
   Object streams=invokeNoArg(info,"getStreams");
   if(streams instanceof Iterable<?>) {
    for(Object stream:(Iterable<?>)streams) normalizedStreams.put(normalizedStream(stream));
   }
  }
  out.put("streams",normalizedStreams);

  JSONObject format=raw.optJSONObject("format");
  if(format==null) format=new JSONObject();
  String duration=firstString(format,"duration");
  if(duration==null) duration=firstString(raw,"duration");
  if(duration==null) duration=stringValue(invokeNoArg(info,"getDuration"));
  if(duration!=null) format.put("duration",duration);
  out.put("format",format);
  return out;
 }

 public static synchronized String probeFile(String path) throws Exception {
  ensureConfigured();
  MediaInformationSession session=FFprobeKit.getMediaInformation(path);
  MediaInformation info=session.getMediaInformation();
  if(info==null) {
   String logs=session.getAllLogsAsString();
   throw new RuntimeException(
    "FFprobe media-information failed for "+path+"\n"+(logs==null?"":logs)+"\n"+session.getFailStackTrace()
   );
  }
  return normalizeMediaInformation(info).toString();
 }

 private static void requireAudio(JSONObject media, String label) {
  JSONArray streams=media.optJSONArray("streams");
  boolean found=false;
  if(streams!=null) {
   for(int i=0;i<streams.length();i++) {
    JSONObject stream=streams.optJSONObject(i);
    if(stream!=null && "audio".equalsIgnoreCase(stream.optString("codec_type"))) { found=true; break; }
   }
  }
  if(!found) throw new RuntimeException(label+" did not expose an audio stream through normalized FFprobe metadata.");
  JSONObject format=media.optJSONObject("format");
  double duration=0.0;
  if(format!=null) {
   try { duration=Double.parseDouble(format.optString("duration","0")); } catch(Exception ignored) {}
  }
  if(duration<=0.01) throw new RuntimeException(label+" did not expose a positive media duration through normalized FFprobe metadata.");
 }

 private static void runOrThrow(String[] command, String label) {
  FFmpegSession session=FFmpegKit.executeWithArguments(command);
  if(!ReturnCode.isSuccess(session.getReturnCode())) {
   throw new RuntimeException(label+" failed.\n"+session.getAllLogsAsString()+"\n"+session.getFailStackTrace());
  }
 }

 public static synchronized String selfTest(String bundledAudioPath) throws Exception {
  ensureConfigured();
  if(selfTestPassed) return "ok";
  File source=new File(bundledAudioPath);
  if(!source.isFile() || source.length()<256) throw new RuntimeException("Bundled FFmpeg self-test audio is missing or empty: "+bundledAudioPath);

  JSONObject sourceProbe=new JSONObject(probeFile(source.getAbsolutePath()));
  requireAudio(sourceProbe,"Bundled WAV probe");
  runOrThrow(new String[]{"-v","error","-i",source.getAbsolutePath(),"-map","0:a:0","-f","null","-"},"Bundled WAV decode self-test");

  File mp3=new File(appContext.getCacheDir(),"vireo_ffmpeg_selftest.mp3");
  File mp4=new File(appContext.getCacheDir(),"vireo_ffmpeg_selftest.mp4");
  try {
   runOrThrow(new String[]{"-y","-v","error","-i",source.getAbsolutePath(),"-t","0.25","-c:a","libmp3lame","-b:a","64k",mp3.getAbsolutePath()},"MP3 encode self-test");
   requireAudio(new JSONObject(probeFile(mp3.getAbsolutePath())),"MP3 probe self-test");
   runOrThrow(new String[]{"-v","error","-i",mp3.getAbsolutePath(),"-map","0:a:0","-f","null","-"},"MP3 decode self-test");

   runOrThrow(new String[]{
    "-y","-v","error",
    "-f","lavfi","-i","color=c=black:s=64x64:r=30:d=0.20",
    "-f","lavfi","-i","anullsrc=r=48000:cl=stereo",
    "-shortest","-t","0.20","-c:v","libx264","-preset","ultrafast","-pix_fmt","yuv420p","-c:a","aac","-b:a","64k",mp4.getAbsolutePath()
   },"H.264/AAC encode self-test");
   JSONObject mp4Probe=new JSONObject(probeFile(mp4.getAbsolutePath()));
   requireAudio(mp4Probe,"H.264/AAC probe self-test");
   boolean video=false;
   JSONArray streams=mp4Probe.optJSONArray("streams");
   if(streams!=null) {
    for(int i=0;i<streams.length();i++) {
     JSONObject stream=streams.optJSONObject(i);
     if(stream!=null && "video".equalsIgnoreCase(stream.optString("codec_type"))) { video=true; break; }
    }
   }
   if(!video) throw new RuntimeException("H.264/AAC probe self-test did not expose a video stream.");
  } finally {
   try { mp3.delete(); } catch(Exception ignored) {}
   try { mp4.delete(); } catch(Exception ignored) {}
  }
  selfTestPassed=true;
  return "ok";
 }

 private FFmpegBridge() {}
}
