package com.vireo.studio;
import com.arthenica.ffmpegkit.*;
import org.json.JSONArray;
import android.content.Context;
import java.util.Arrays;
import java.util.Collections;
public final class FFmpegBridge {
 public static void configure(Context context, String customFontDir) { FFmpegKitConfig.setFontDirectoryList(context, Arrays.asList("/system/fonts", customFontDir), Collections.emptyMap()); }
 private static String[] args(String json) throws Exception { JSONArray a=new JSONArray(json); String[] out=new String[a.length()]; for(int i=0;i<a.length();i++) out[i]=a.getString(i); return out; }
 public static String executeJson(String json) throws Exception { FFmpegSession s=FFmpegKit.executeWithArguments(args(json)); String logs=s.getAllLogsAsString(); if(!ReturnCode.isSuccess(s.getReturnCode())) throw new RuntimeException(logs+"\n"+s.getFailStackTrace()); return logs; }
 public static String executeForLogsJson(String json) throws Exception { return executeJson(json); }
 public static String probeJson(String json) throws Exception { FFprobeSession s=FFprobeKit.executeWithArguments(args(json)); String out=s.getOutput(); if(!ReturnCode.isSuccess(s.getReturnCode())) throw new RuntimeException(out+"\n"+s.getFailStackTrace()); return out; }
 private FFmpegBridge() {}
}
