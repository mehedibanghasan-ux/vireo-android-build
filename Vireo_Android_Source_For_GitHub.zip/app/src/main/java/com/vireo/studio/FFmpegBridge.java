package com.vireo.studio;
import com.arthenica.ffmpegkit.*;
import org.json.JSONArray;
import android.content.Context;
import java.util.Arrays;
import java.util.Collections;
public final class FFmpegBridge {
 private static Context appContext;
 private static String customFontDir;
 private static volatile boolean configured=false;
 public static synchronized void configure(Context context, String fontDir) {
  appContext=context.getApplicationContext(); customFontDir=fontDir; configured=false;
 }
 private static synchronized void ensureConfigured() {
  if(configured) return;
  if(appContext==null) throw new IllegalStateException("FFmpegBridge is not initialized.");
  FFmpegKitConfig.setFontDirectoryList(appContext, Arrays.asList("/system/fonts", customFontDir), Collections.emptyMap());
  configured=true;
 }
 private static String[] args(String json) throws Exception { JSONArray a=new JSONArray(json); String[] out=new String[a.length()]; for(int i=0;i<a.length();i++) out[i]=a.getString(i); return out; }
 public static String executeJson(String json) throws Exception { ensureConfigured(); FFmpegSession s=FFmpegKit.executeWithArguments(args(json)); String logs=s.getAllLogsAsString(); if(!ReturnCode.isSuccess(s.getReturnCode())) throw new RuntimeException(logs+"\n"+s.getFailStackTrace()); return logs; }
 public static String executeForLogsJson(String json) throws Exception { return executeJson(json); }
 public static String probeJson(String json) throws Exception { ensureConfigured(); FFprobeSession s=FFprobeKit.executeWithArguments(args(json)); String out=s.getOutput(); if(!ReturnCode.isSuccess(s.getReturnCode())) throw new RuntimeException(out+"\n"+s.getFailStackTrace()); return out; }
 private FFmpegBridge() {}
}
