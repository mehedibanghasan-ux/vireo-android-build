from __future__ import annotations
import json, mimetypes, requests
from types import SimpleNamespace

API_BASE = "https://api.openai.com/v1"

class _OpenAIHTTPError(RuntimeError):
    def __init__(self, status_code, message):
        self.status_code=int(status_code)
        super().__init__(message)

def _ns(value):
    if isinstance(value, dict): return SimpleNamespace(**{k:_ns(v) for k,v in value.items()})
    if isinstance(value, list): return [_ns(v) for v in value]
    return value

def _output_text(data):
    if isinstance(data.get("output_text"), str): return data["output_text"]
    parts=[]
    for item in data.get("output") or []:
        for content in item.get("content") or []:
            if content.get("type") in ("output_text","text"):
                text=content.get("text")
                if isinstance(text, dict): text=text.get("value") or text.get("text")
                if text: parts.append(str(text))
    return "\n".join(parts)

class _Models:
    def __init__(self, c): self.c=c
    def list(self):
        r=self.c._request("GET","/models"); return _ns(r)

class _Responses:
    def __init__(self,c): self.c=c
    def create(self, **kwargs):
        r=self.c._request("POST","/responses",json=kwargs)
        obj=_ns(r); obj.output_text=_output_text(r); return obj

class _Transcriptions:
    def __init__(self,c): self.c=c
    def create(self, *, file, **kwargs):
        data={k:str(v).lower() if isinstance(v,bool) else str(v) for k,v in kwargs.items() if v is not None}
        # OpenAI accepts repeated timestamp_granularities[] fields.
        tg=kwargs.get("timestamp_granularities")
        if tg is not None:
            data.pop("timestamp_granularities",None)
            data["timestamp_granularities[]"]=[str(v) for v in tg]
        name=getattr(file,"name","audio.bin")
        mime=mimetypes.guess_type(name)[0] or "application/octet-stream"
        files={"file":(name,file,mime)}
        r=self.c._request("POST","/audio/transcriptions",data=data,files=files)
        return _ns(r)

class OpenAI:
    def __init__(self, api_key=None, timeout=120, **_):
        self.api_key=(api_key or "").strip(); self.timeout=timeout
        if not self.api_key: raise RuntimeError("OPENAI_API_KEY is missing.")
        self.models=_Models(self); self.responses=_Responses(self)
        self.audio=SimpleNamespace(transcriptions=_Transcriptions(self))
    def _request(self, method, path, **kwargs):
        headers=dict(kwargs.pop("headers",{}) or {}); headers["Authorization"]="Bearer "+self.api_key
        r=requests.request(method, API_BASE+path, headers=headers, timeout=self.timeout, **kwargs)
        if not r.ok:
            raise _OpenAIHTTPError(r.status_code, f"OpenAI HTTP {r.status_code}: {r.text[:1200]}")
        try: return r.json()
        except Exception: return {"output_text":r.text}
