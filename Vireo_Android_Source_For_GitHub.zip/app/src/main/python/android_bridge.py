from __future__ import annotations
import json, os, shutil, threading, traceback, base64, time, hashlib
from pathlib import Path

_initialized=False
_loaded_project_dir=None
_stop_event=None
_review_context=None
_review_lock=threading.Lock()
_generation_state_lock=threading.Lock()
_generation_active=False

AI33_PRESET_VOICES = {
"Bill - Wise, Mature, Balanced":"elevenlabs_pqHfZKP75CvOlQylNhV4","Bill - Persuasive Calm & Friendly":"elevenlabs_sR8sxaLJeFSh308Gi6HS","Bill Adult Professional":"elevenlabs_ynUcJpglne1SRSNHFg1k","Bill - Social Media":"elevenlabs_AGhk9wKpcIV2UvBus4CY","Bill Stevens - Conversational and Casual":"elevenlabs_KbakCphLGyrStJ2sp8mp","Professor Bill":"elevenlabs_lnieQLGTodpbhjpZtg1k","Billy Hardscrabble - Wise and Weathered":"elevenlabs_zQzvQBubVkDWYuqJYMFn","Bill - Informative, Clean and Natural":"elevenlabs_lnUnPeUhSI5EcqtFBux7","Bill Oxley - Documentary Commentator":"elevenlabs_iiidtqDt9FBdT1vfBluA","Billy - Authentic, Wise and Clear":"elevenlabs_ySaYS84ykPC7FKlpD4ag","Ron - Older American Story Teller":"elevenlabs_Hd8mWkf5kvyBZB0S7yXU","Knowledge Pill":"minimax_299066646466807","Roger - Laid-Back, Casual, Resonant":"elevenlabs_CwhRBWXzGAHq8TQ4Fs17","Charlie - Deep, Confident, Energetic":"elevenlabs_IKne3meq5aSn9XLyUdCD","George - Warm, Captivating Storyteller":"elevenlabs_JBFqnCBsd6RMkjVDRZzb","Gunner S - Warm, Confident & Authentic":"elevenlabs_JcwFVpR60FiOW4cPEqI2","Callum - Husky Trickster":"elevenlabs_N2lVS1w4EtoT3dr4eOWO","Harry - Fierce Warrior":"elevenlabs_SOYHLrjzK2X1ezoPC6cr","Rob":"elevenlabs_2IbkLYArNLdNWHCCo77t","Phil O - Deep, Gritty Cinematic Narrator":"elevenlabs_a6YaeYIc6oXYWy63PGIu","Leo v2 - Technical and Precise":"elevenlabs_bbGtsRRKUfYO634UxSjz","Eddie - Natural and Helpful":"elevenlabs_l7kNoIfnJKPg7779LI2t"}

def initialize(base_dir:str):
    global _initialized
    if _initialized: return "ok"
    os.environ["VIREO_BASE_DIR"]=str(Path(base_dir)/"vireo")
    from app.config import ensure_directories, RESOURCES_DIR
    ensure_directories()
    static=Path(__file__).resolve().parent/"vireo_static"/"sfx"; target=RESOURCES_DIR/"sfx"; target.mkdir(parents=True,exist_ok=True)
    for src in static.glob("*"):
        dst=target/src.name
        def digest(path):
            h=hashlib.sha256()
            with path.open("rb") as f:
                for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
            return h.digest()
        if not dst.exists() or dst.stat().st_size != src.stat().st_size or digest(dst) != digest(src):
            shutil.copy2(src,dst)
    _initialized=True
    return "ok"

def _settings_from(data, fallback=None):
    from app.config import AppSettings
    base=(fallback or AppSettings()).sanitized(); allowed=set(AppSettings.__dataclass_fields__)
    for k,v in (data or {}).items():
        if k in allowed: base[k]=v
    return AppSettings(**{k:v for k,v in base.items() if k in allowed})

def _music_options():
    from app.config import MUSIC_DIR
    vals=["None"]
    for p in sorted(MUSIC_DIR.glob("*")):
        if p.suffix.lower() in {".mp3",".wav",".m4a",".aac",".flac",".ogg"}: vals.append(p.name)
    return vals

def _font_options():
    from app.config import FONTS_DIR
    vals=["Arial","LuckiestGuy","Impact","Verdana"]
    for p in sorted(FONTS_DIR.glob("*")):
        if p.suffix.lower() in {".ttf",".otf"}: vals.append(p.stem)
    return list(dict.fromkeys(vals))


def _font_warning(font_name: str) -> str:
    """Warn instead of silently substituting a desktop font on Android."""
    from app.config import FONTS_DIR
    wanted=str(font_name or "").strip().lower().replace(" ", "")
    if not wanted:
        return ""
    for p in FONTS_DIR.glob("*"):
        if p.suffix.lower() in {".ttf", ".otf"} and p.stem.lower().replace(" ", "") == wanted:
            return ""
    # Vireo's desktop default is Impact, which Android does not ship. Other desktop
    # family names may also fall back through fontconfig. Keep the requested family
    # unchanged and make the parity requirement visible rather than silently mapping it.
    if wanted in {"arial", "luckiestguy", "impact", "verdana"}:
        return f"Exact desktop font '{font_name}' is not bundled on Android. Import your licensed .ttf/.otf file for exact subtitle appearance; Vireo will not silently change the selected font."
    return ""


def _fresh_mobile_settings():
    """Apply documented global preferences on top of protected fresh-project defaults.

    Update 31 requires the most recently changed subtitle preferences to become
    the active defaults after restart. Custom AI33 voice presets are also global
    user presets, not per-project scene state.
    """
    from app.config import load_settings, fresh_project_settings
    persisted=load_settings(); settings=fresh_project_settings(persisted)
    for name in (
        "subtitles_enabled", "subtitle_font", "subtitle_font_size",
        "subtitle_position", "subtitle_all_caps", "subtitle_outline_size",
        "subtitle_color", "words_per_caption",
    ):
        setattr(settings,name,getattr(persisted,name,getattr(settings,name)))
    settings.ai33_custom_voices=dict(getattr(persisted,"ai33_custom_voices",{}) or {})
    return settings

def _directory_info():
    from app.config import BASE_DIR, LONG_VIDEO_DIR, MUSIC_DIR, FONTS_DIR, STYLE_PREVIEWS_DIR, REFERENCE_STYLES_DIR
    return {"base":str(BASE_DIR),"projects":str(LONG_VIDEO_DIR),"music":str(MUSIC_DIR),"fonts":str(FONTS_DIR),"stylePreviews":str(STYLE_PREVIEWS_DIR),"referenceStyles":str(REFERENCE_STYLES_DIR)}

def bootstrap():
    from app.config import get_api_key
    from app.styles import scan_styles
    from app.character_presets import standard_character_preset_options, older_storybook_character_preset_options, standard_character_style_options
    from app.runware_client import fallback_model_mapping, recommended_steps_for_model
    settings=_fresh_mobile_settings()
    voices=dict(AI33_PRESET_VOICES); voices.update(settings.ai33_custom_voices or {})
    models=fallback_model_mapping()
    return json.dumps({"settings":settings.sanitized(),"styles":[{"id":s.key,"label":s.name,"prompt":s.prompt,"preview":s.preview_path,"source":s.source} for s in scan_styles()],"standardCharacters":standard_character_preset_options(),"olderCharacters":older_storybook_character_preset_options(),"standardLooks":standard_character_style_options(),"voices":[{"label":k,"id":v} for k,v in voices.items()],"runwareModels":[{"label":k,"id":v} for k,v in models.items()],"openaiModels":[settings.openai_model,settings.default_openai_model],"music":_music_options(),"fonts":_font_options(),"fontWarning":_font_warning(settings.subtitle_font),"directories":_directory_info(),"keys":{"openai":bool(get_api_key("OPENAI_API_KEY")),"runware":bool(get_api_key("RUNWARE_API_KEY")),"ai33":bool(get_api_key("AI33_API_KEY"))}})

def save_settings_json(payload:str):
    from app.config import load_settings, save_settings
    settings=_settings_from(json.loads(payload or "{}"), load_settings()); save_settings(settings); return json.dumps(settings.sanitized())

def save_keys_json(payload:str):
    from app.config import save_api_keys
    d=json.loads(payload or "{}"); save_api_keys(d.get("openai"),d.get("runware"),d.get("ai33")); return json.dumps({"ok":True})

def analyze_json(payload:str):
    from app.script_analyzer import analyze_script
    d=json.loads(payload or "{}"); st=analyze_script(d.get("script", ""))
    return json.dumps(st.__dict__)

def preview_scenes_json(payload:str):
    from app.scene_splitter import split_into_scenes
    d=json.loads(payload or "{}"); scenes=split_into_scenes(d.get("script", ""), max(1,int(d.get("scenes",1))))
    return json.dumps({"scenes":scenes})

def list_projects_json(_payload=""):
    from app.project import list_project_dirs, load_state
    rows=[]
    for p in list_project_dirs():
        state=load_state(p); rows.append({"path":str(p),"name":p.name,"stage":state.get("stage",""),"scene_count":state.get("scene_count",0),"final":state.get("final_video","")})
    return json.dumps({"projects":rows})

def _assert_project_switch_safe():
    with _generation_state_lock:
        if _generation_active:
            raise RuntimeError("A Vireo generation is already running. Pause or finish it before switching projects.")

def load_project_json(payload:str):
    global _loaded_project_dir
    _assert_project_switch_safe()
    from app.project import project_script, load_project_settings
    from app.config import load_settings
    d=json.loads(payload); p=Path(d["path"]); _loaded_project_dir=p
    settings=load_project_settings(p,load_settings())
    return json.dumps({"path":str(p),"script":project_script(p),"settings":settings.sanitized()})

def new_project_json(_payload=""):
    global _loaded_project_dir
    _assert_project_switch_safe()
    _loaded_project_dir=None
    return json.dumps({"settings":_fresh_mobile_settings().sanitized()})

def refresh_runware_models_json(payload:str):
    from app.runware_client import list_image_models, fallback_model_mapping, fetch_image_model_pricing, model_options
    d=json.loads(payload or "{}"); rows=list_image_models(d.get("search", ""), limit_per_query=int(d.get("limit",80)))
    try: pricing=fetch_image_model_pricing()
    except Exception: pricing={}
    records=model_options(rows,pricing)
    if not records:
        records=[{"label":label,"air":air,"cost_label":"Varies by size/steps"} for label,air in fallback_model_mapping().items()]
    return json.dumps({"models":[{"label":r["label"],"id":r["air"],"cost_label":r.get("cost_label","")} for r in records]})

def runware_model_info_json(payload:str):
    from app.runware_client import recommended_steps_for_model, is_gpt_image_2_model
    d=json.loads(payload or "{}"); model=str(d.get("id") or ""); label=str(d.get("label") or "")
    steps,reason=recommended_steps_for_model(model,label)
    return json.dumps({"steps":steps,"reason":reason,"locked":is_gpt_image_2_model(model)})

def refresh_openai_models_json(_payload=""):
    from app.openai_tools import list_prompt_models
    return json.dumps({"models":list_prompt_models()})

def set_default_openai_json(payload:str):
    from app.config import load_settings, save_settings
    d=json.loads(payload or "{}"); model=str(d.get("model") or "").strip()
    if not model: raise ValueError("Choose an OpenAI prompt model first.")
    s=load_settings(); s.openai_model=model; s.default_openai_model=model; save_settings(s)
    return json.dumps({"ok":True,"model":model})

def manual_prompt_count_json(payload:str):
    from app.pipeline import _parse_manual_prompts
    d=json.loads(payload or "{}"); return json.dumps({"count":len(_parse_manual_prompts(str(d.get("text") or "")))})

def refresh_voices_json(payload:str):
    from app.ai33_client import list_voices
    from app.config import load_settings
    d=json.loads(payload or "{}"); rows=list_voices(d.get("provider","elevenlabs"),d.get("language","English"))
    settings=load_settings(); mapping=dict(AI33_PRESET_VOICES); mapping.update(settings.ai33_custom_voices or {})
    for v in rows:
        vid=str(v.get("voice_id") or v.get("id") or ""); name=str(v.get("name") or v.get("voice_name") or vid)
        if vid: mapping[name]=vid
    return json.dumps({"voices":[{"label":k,"id":v} for k,v in mapping.items()]})

def add_custom_voice_json(payload:str):
    # Memory-pack contract: add a preset only. Selected/default voice are preserved.
    from app.config import load_settings, save_settings
    d=json.loads(payload); name=str(d.get("name") or "").strip(); vid=str(d.get("id") or "").strip()
    if not name or not vid: raise ValueError("Voice ID and Voice Name are required.")
    settings=load_settings(); selected=str(d.get("selected") or settings.ai33_voice_id); default=settings.default_ai33_voice_id
    custom=dict(settings.ai33_custom_voices or {}); custom[name]=vid; settings.ai33_custom_voices=custom
    settings.ai33_voice_id=selected; settings.default_ai33_voice_id=default; save_settings(settings)
    return json.dumps({"name":name,"id":vid,"selected":selected,"default":default})

def set_default_voice_json(payload:str):
    from app.config import load_settings, save_settings
    d=json.loads(payload); vid=str(d.get("id") or "").strip();
    if not vid: raise ValueError("Voice ID required")
    s=load_settings(); s.default_ai33_voice_id=vid; s.ai33_voice_id=vid; save_settings(s); return json.dumps({"ok":True})

def _notify(method:str, payload:dict):
    try:
        from java import jclass
        jclass("com.vireo.studio.MainActivity").emit(method, json.dumps(payload, ensure_ascii=False))
    except Exception: pass

def _progress(text:str):
    _notify("progress",{"message":str(text)})

def pause_json(_payload=""):
    global _stop_event
    if _stop_event: _stop_event.set()
    return json.dumps({"ok":True})

def generate_json(payload:str):
    global _stop_event, _loaded_project_dir, _generation_active
    with _generation_state_lock:
        if _generation_active:
            raise RuntimeError("A Vireo generation is already running. Duplicate generation was blocked to protect paid tasks.")
        _generation_active=True
    try:
        from app.config import load_settings, save_settings
        from app.pipeline import run_generation, PipelinePaused
        from app.project import project_script
        d=json.loads(payload); script=str(d.get("script") or "").strip()
        if not script: raise ValueError("Paste or load a script first.")
        settings=_settings_from(d.get("settings") or {},load_settings()); save_settings(settings)
        project=_loaded_project_dir; resume=False
        if project is not None:
            original=project_script(project).strip(); resume=bool(original and original==script)
            if not resume: project=None; _loaded_project_dir=None
        _stop_event=threading.Event(); started=time.monotonic()
        try:
            final=run_generation(script,settings,progress=_progress,project_dir=project,resume=resume,stop_event=_stop_event,review_callback=_review_images)
            _loaded_project_dir=None
            result={"status":"complete","final":str(final),"elapsed":round(time.monotonic()-started,1)}
            _notify("complete",result); return json.dumps(result)
        except PipelinePaused as exc:
            _loaded_project_dir=Path(exc.project_dir); result={"status":"paused","project":str(exc.project_dir)}; _notify("paused",result); return json.dumps(result)
    finally:
        _stop_event=None
        with _generation_state_lock:
            _generation_active=False

def _review_images(project_dir,prompts,images,settings,scenes):
    global _review_context
    from java import jclass
    with _review_lock:
        _review_context={"project_dir":Path(project_dir),"prompts":prompts,"images":images,"settings":settings,"scenes":scenes}
    payload={"project":str(project_dir),"items":[{"index":i,"scene":scenes[i],"image":str(images[i])} for i in range(len(images))]}
    jclass("com.vireo.studio.ReviewHost").beginReview(json.dumps(payload,ensure_ascii=False))
    with _review_lock: _review_context=None

def regenerate_review_json(payload:str):
    import os
    from app.styles import get_style_prompt
    from app.character_presets import get_character_preset,resolve_character_preset_style,apply_global_stick_figure_rules
    from app.openai_tools import generate_single_scene_prompt
    from app.runware_client import generate_image
    from app.project import load_json,save_json,save_text
    d=json.loads(payload); idx=int(d["index"])
    with _review_lock: ctx=_review_context
    if not ctx: raise RuntimeError("No image review is active.")
    project_dir=ctx["project_dir"]; prompts=ctx["prompts"]; images=ctx["images"]; settings=ctx["settings"]; scenes=ctx["scenes"]
    selected_style_prompt=get_style_prompt(settings.last_style)
    character_preset=resolve_character_preset_style(get_character_preset(getattr(settings,"main_character_preset","none")),getattr(settings,"standard_character_style","classic"))
    style_prompt=character_preset.bundle_style_prompt if character_preset else selected_style_prompt
    bundle=character_preset.as_prompt_payload() if character_preset else None
    new_prompt=generate_single_scene_prompt(scenes[idx],style_prompt,settings.openai_model,previous_prompt=prompts[idx],character_bundle=bundle)
    if character_preset: new_prompt=apply_global_stick_figure_rules(new_prompt,character_preset)
    replacement=images[idx].with_name(f"{images[idx].stem}_replacement{images[idx].suffix}"); backup=images[idx].with_name(f"{images[idx].stem}_previous{images[idx].suffix}")
    pj=project_dir/"image_prompts.json"; pt=project_dir/"image_prompts.txt"; original_prompt=prompts[idx]; original_json=load_json(pj,default={}) or {}; original_text=pt.read_text(encoding="utf-8",errors="ignore") if pt.exists() else ""; replaced=False
    try:
        if replacement.exists(): replacement.unlink()
        generate_image(new_prompt,replacement,settings.runware_model,settings.image_width,settings.image_height,settings.image_steps,progress=_progress)
        if images[idx].exists(): shutil.copy2(images[idx],backup)
        os.replace(replacement,images[idx]); replaced=True
        updated=list(prompts); updated[idx]=new_prompt; meta=dict(original_json) if isinstance(original_json,dict) else {}; meta.update({"prompts":updated,"style_prompt":style_prompt,"selected_style_prompt":selected_style_prompt,"character_preset_id":getattr(settings,"main_character_preset","none"),"standard_character_style":getattr(settings,"standard_character_style","classic")})
        save_json(pj,meta); save_text(pt,"\n\n".join(f"Scene {i:03}: {p}" for i,p in enumerate(updated,start=1))); prompts[idx]=new_prompt
    except Exception:
        prompts[idx]=original_prompt
        if replaced and backup.exists(): shutil.copy2(backup,images[idx])
        if isinstance(original_json,dict) and original_json: save_json(pj,original_json)
        if original_text: save_text(pt,original_text)
        raise
    finally:
        try:
            if replacement.exists(): replacement.unlink()
        except Exception: pass
    rendered=project_dir/"rendered_scenes"/f"scene_{idx:03}.mp4"
    for stale in (rendered,project_dir/"stitched.mp4",project_dir/f"{project_dir.name}.mp4"):
        try:
            if stale.exists(): stale.unlink()
        except Exception: pass
    return json.dumps({"index":idx,"image":str(images[idx])})
