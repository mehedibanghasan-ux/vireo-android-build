from __future__ import annotations

from pathlib import Path
import json
import os
import re
import tempfile
from typing import Any

from .config import AppSettings, LONG_VIDEO_DIR

STATE_FILE = "vireo_state.json"


_WINDOWS_RESERVED_BASENAMES = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def safe_video_filename(title: str | None, fallback_stem: str) -> str:
    """Return one Windows-safe MP4 filename while preserving Unicode titles."""
    raw = str(title or "").strip()
    if raw.lower().endswith(".mp4"):
        raw = raw[:-4]
    # Windows forbids these path characters/control bytes inside a filename.
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", raw)
    cleaned = re.sub(r"\s+", " ", cleaned).strip().rstrip(" .")
    if not cleaned:
        cleaned = str(fallback_stem or "video").strip() or "video"
    reserved_root = cleaned.split(".", 1)[0].upper()
    if reserved_root in _WINDOWS_RESERVED_BASENAMES:
        cleaned = "_" + cleaned
    # Keep ample room for the project path and extension on normal Windows setups.
    cleaned = cleaned[:140].rstrip(" .") or "video"
    return f"{cleaned}.mp4"


def ensure_project_subdirs(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    (path / "images").mkdir(exist_ok=True)
    (path / "audio").mkdir(exist_ok=True)
    (path / "rendered_scenes").mkdir(exist_ok=True)


def next_project_dir() -> Path:
    LONG_VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    nums = []
    for p in LONG_VIDEO_DIR.iterdir():
        if p.is_dir():
            m = re.fullmatch(r"lv_(\d+)", p.name)
            if m:
                nums.append(int(m.group(1)))
    n = max(nums, default=0) + 1
    path = LONG_VIDEO_DIR / f"lv_{n:03}"
    ensure_project_subdirs(path)
    return path


def list_project_dirs() -> list[Path]:
    LONG_VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    return sorted((p for p in LONG_VIDEO_DIR.iterdir() if p.is_dir() and p.name.startswith("lv_")), reverse=True)


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    """Write a file without leaving a half-written final path after interruption."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass


def save_json(path: Path, data: Any) -> None:
    payload = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    _atomic_write_bytes(path, payload)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_text(path: Path, text: str) -> None:
    _atomic_write_bytes(path, str(text).encode("utf-8"))


def load_state(project_dir: Path) -> dict[str, Any]:
    return load_json(project_dir / STATE_FILE, default={}) or {}


def load_project_settings(project_dir: Path, fallback: AppSettings | None = None) -> AppSettings:
    """Restore the settings snapshot belonging to one saved project.

    `project_metadata.json` is the compatibility baseline; the `settings` snapshot
    in `vireo_state.json` wins when present because it represents the latest
    generation checkpoint. Missing fields inherit from the supplied fallback so
    older projects remain loadable after new settings are added.
    """
    allowed = set(AppSettings.__dataclass_fields__)
    merged = (fallback or AppSettings()).sanitized()
    metadata = load_json(Path(project_dir) / "project_metadata.json", default={}) or {}
    state = load_state(Path(project_dir))
    state_settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    for source in (metadata, state_settings):
        if isinstance(source, dict):
            for key, value in source.items():
                if key in allowed:
                    merged[key] = value
    return AppSettings(**{key: value for key, value in merged.items() if key in allowed})


def save_state(project_dir: Path, **updates: Any) -> dict[str, Any]:
    state = load_state(project_dir)
    state.update(updates)
    save_json(project_dir / STATE_FILE, state)
    return state


def project_script(project_dir: Path) -> str:
    path = project_dir / "original_script.txt"
    if path.exists():
        return path.read_text(encoding="utf-8", errors="ignore")
    state = load_state(project_dir)
    return str(state.get("script") or "")
