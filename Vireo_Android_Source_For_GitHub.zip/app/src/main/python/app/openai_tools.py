from __future__ import annotations

from pathlib import Path
import base64
import json
import re
import random
import time
from typing import Any, Callable

from .config import get_api_key


class OpenAIError(RuntimeError):
    pass


OPENAI_PROMPT_MODEL_FALLBACKS = [
    "gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna",
    "gpt-5.5", "gpt-5.5-pro", "gpt-5.4", "gpt-5.4-pro", "gpt-5.4-mini", "gpt-5.4-nano",
    "gpt-5.3-codex", "gpt-5.2", "gpt-5.1", "gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-4.1", "gpt-4.1-mini", "gpt-4o-mini"
]


def _client():
    api_key = get_api_key("OPENAI_API_KEY")
    if not api_key:
        raise OpenAIError("OPENAI_API_KEY is missing. Add it in Settings or .env.")
    try:
        from openai import OpenAI
    except Exception as exc:  # pragma: no cover
        raise OpenAIError("The openai package is not installed. Run pip install -r requirements.txt.") from exc
    return OpenAI(api_key=api_key)




def _is_transient_openai_error(exc: Exception) -> bool:
    status = getattr(exc, "status_code", None)
    if status in {408, 409, 425, 429, 500, 502, 503, 504}:
        return True
    name = type(exc).__name__.lower()
    text = str(exc).lower()
    return any(token in name or token in text for token in (
        "timeout", "connection", "ratelimit", "rate limit", "temporarily", "service unavailable",
    ))


def _retry_openai_call(call, attempts: int = 3):
    last_error: Exception | None = None
    for attempt in range(max(1, attempts)):
        try:
            return call()
        except Exception as exc:
            last_error = exc
            if attempt >= attempts - 1 or not _is_transient_openai_error(exc):
                raise
            time.sleep(min(8.0, 1.5 * (2 ** attempt)) + random.uniform(0.0, 0.35))
    raise OpenAIError(f"OpenAI request failed: {last_error}")

def _extract_json(text: str) -> Any:
    try:
        return json.loads(text)
    except Exception:
        match = re.search(r"\{.*\}|\[.*\]", text, re.S)
        if not match:
            raise
        return json.loads(match.group(0))


def _looks_like_prompt_model(model_id: str) -> bool:
    mid = model_id.lower()
    blocked = [
        "embedding", "image", "dall", "tts", "whisper", "transcribe", "realtime", "audio", "moderation", "sora", "search"
    ]
    if any(b in mid for b in blocked):
        return False
    return mid.startswith("gpt-") or re.match(r"^o\d", mid) is not None


def list_prompt_models() -> list[str]:
    try:
        client = _client()
        result = client.models.list()
        ids = []
        for item in getattr(result, "data", []) or []:
            mid = str(getattr(item, "id", "") or "")
            if mid and _looks_like_prompt_model(mid):
                ids.append(mid)
        merged = list(dict.fromkeys([*OPENAI_PROMPT_MODEL_FALLBACKS, *sorted(ids)]))
        return merged or OPENAI_PROMPT_MODEL_FALLBACKS
    except Exception:
        return OPENAI_PROMPT_MODEL_FALLBACKS




def _ordered_batch_prompts(raw_prompts: Any, *, batch_start: int, batch_count: int) -> list[str]:
    """Return exactly one prompt per supplied scene without index drift.

    Models sometimes return global 0-based indices, global 1-based indices,
    batch-local 0/1-based indices, or a plain ordered string list.  Accept only
    layouts that map unambiguously to every scene in the current batch.
    """
    if not isinstance(raw_prompts, list):
        raise OpenAIError("OpenAI prompt response did not contain a prompts list.")

    if raw_prompts and all(isinstance(item, str) for item in raw_prompts):
        prompts = [str(item).strip() for item in raw_prompts]
        if len(prompts) == batch_count and all(prompts):
            return prompts
        raise OpenAIError(
            f"OpenAI returned {len(prompts)} ordered prompts for a {batch_count}-scene batch."
        )

    items: list[tuple[int | None, str]] = []
    for item in raw_prompts:
        if not isinstance(item, dict):
            raise OpenAIError("OpenAI returned a non-object prompt entry.")
        prompt = str(item.get("prompt") or "").strip()
        if not prompt:
            raise OpenAIError("OpenAI returned an empty image prompt.")
        raw_index = item.get("index")
        try:
            index = int(raw_index) if raw_index is not None else None
        except (TypeError, ValueError):
            index = None
        items.append((index, prompt))

    if len(items) != batch_count:
        raise OpenAIError(
            f"OpenAI returned {len(items)} prompts for a {batch_count}-scene batch."
        )

    indexes = [index for index, _prompt in items]
    if all(index is None for index in indexes):
        return [prompt for _index, prompt in items]
    if any(index is None for index in indexes):
        raise OpenAIError("OpenAI mixed indexed and unindexed prompt entries.")

    schemes = (
        lambda value: value - batch_start,       # global 0-based
        lambda value: value - batch_start - 1,   # global 1-based
        lambda value: value,                     # batch-local 0-based
        lambda value: value - 1,                 # batch-local 1-based
    )
    expected_positions = set(range(batch_count))
    for convert in schemes:
        positioned: dict[int, str] = {}
        valid = True
        for raw_index, prompt in items:
            assert raw_index is not None
            position = convert(raw_index)
            if position not in expected_positions or position in positioned:
                valid = False
                break
            positioned[position] = prompt
        if valid and set(positioned) == expected_positions:
            return [positioned[position] for position in range(batch_count)]

    raise OpenAIError(
        "OpenAI prompt indices could not be mapped unambiguously to the supplied scenes."
    )


def generate_scene_prompts(
    scenes: list[str],
    style_prompt: str,
    model: str,
    progress: Callable[[str], None] | None = None,
    batch_size: int = 20,
    style_reference_summary: str = "",
    character_bundle: dict[str, Any] | None = None,
) -> list[str]:
    client = _client()
    all_prompts: list[str] = []
    instructions = (
        "You are a senior cinematic prompt writer for long-form AI video. "
        "Create exactly one image prompt for every supplied scene. Each prompt must visualize only that scene's current narration moment; "
        "do not borrow actions, people, objects, or events from earlier or later scenes. "
        "Keep the prompt faithful to the scene text and consistent with the global style. "
        "If a main character bundle is provided, keep that recurring protagonist visually consistent whenever the scene implies the protagonist is present. "
        "Treat every provided main-character anatomy/style rule as mandatory. If the bundle says all visible people must remain stick figures, then every person in the frame must remain a stick figure and you must never mix stick figures with normal human-shaped bodies. "
        "If a style-reference summary is provided, follow it closely as the overall illustration style. "
        "Avoid text, subtitles, logos, watermarks, UI elements, extra fingers, deformed anatomy, and irrelevant objects. "
        "Return only valid JSON in this exact shape: "
        "{\"prompts\":[{\"index\":<the exact integer index supplied for that scene>,\"prompt\":\"...\",\"uses_main_character\":true}]}. "
        "Do not omit, duplicate, renumber, or reorder scene indices."
    )
    for start in range(0, len(scenes), batch_size):
        batch = scenes[start:start + batch_size]
        if progress:
            progress(f"Generating prompts {start + 1}-{start + len(batch)}...")
        payload = {
            "global_style": style_prompt,
            "style_reference_summary": style_reference_summary,
            "main_character": character_bundle or {},
            "scene_count": len(scenes),
            "batch_offset": start,
            "scenes": [{"index": start + i, "text": scene} for i, scene in enumerate(batch)],
        }

        last_validation_error: Exception | None = None
        ordered: list[str] | None = None
        for validation_attempt in range(2):
            response = _retry_openai_call(lambda: client.responses.create(
                model=model,
                instructions=instructions,
                input=json.dumps(payload, ensure_ascii=False),
            ))
            text = getattr(response, "output_text", "") or str(response)
            try:
                data = _extract_json(text)
                raw_prompts = data.get("prompts") if isinstance(data, dict) else data
                ordered = _ordered_batch_prompts(
                    raw_prompts, batch_start=start, batch_count=len(batch)
                )
                break
            except Exception as exc:
                last_validation_error = exc
                if progress and validation_attempt == 0:
                    progress(
                        f"OpenAI returned an ambiguous prompt mapping for scenes "
                        f"{start + 1}-{start + len(batch)}; requesting one corrected response..."
                    )
        if ordered is None:
            raise OpenAIError(
                f"Could not obtain a safe one-to-one prompt mapping for scenes "
                f"{start + 1}-{start + len(batch)}: {last_validation_error}"
            )
        all_prompts.extend(ordered)

    if len(all_prompts) != len(scenes) or any(not prompt.strip() for prompt in all_prompts):
        raise OpenAIError(
            f"Final scene/prompt mapping failed validation: scenes={len(scenes)}, prompts={len(all_prompts)}."
        )
    return all_prompts


def generate_single_scene_prompt(
    scene: str,
    style_prompt: str,
    model: str,
    previous_prompt: str = "",
    style_reference_summary: str = "",
    character_bundle: dict[str, Any] | None = None,
) -> str:
    """Generate one replacement image prompt for review/regeneration."""
    prompts = generate_scene_prompts(
        [scene + (f"\nPrevious prompt to improve, do not copy verbatim: {previous_prompt}" if previous_prompt else "")],
        style_prompt,
        model,
        batch_size=1,
        style_reference_summary=style_reference_summary,
        character_bundle=character_bundle,
    )
    return prompts[0] if prompts else f"{style_prompt}. Scene: {scene}. Clean composition, no text, no watermark."


def describe_reference_style(image_paths: list[Path], model: str = "gpt-5.5") -> str:
    client = _client()
    content: list[dict[str, Any]] = [{"type": "input_text", "text": "Analyze these reference images as a reusable AI image style. Produce a concise style bible: palette, lighting, camera, texture, mood, composition, exclusions. Do not identify creators or copyrighted sources."}]
    for path in image_paths[:8]:
        data = base64.b64encode(path.read_bytes()).decode("ascii")
        mime = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"
        content.append({"type": "input_image", "image_url": f"data:{mime};base64,{data}"})
    response = _retry_openai_call(lambda: client.responses.create(model=model, input=[{"role": "user", "content": content}]))
    return (getattr(response, "output_text", "") or "").strip()


def transcribe_words(
    audio_path: Path,
    model: str = "whisper-1",
    expected_text: str = "",
) -> list[dict[str, float | str]]:
    """Transcribe narration with word timestamps.

    Vireo keeps whisper-1 as the default transcription model. Supplying the
    known scene text as a prompt and using temperature=0 reduces short-clip
    hallucinations before the transcript is aligned back to the script.
    """
    client = _client()
    kwargs: dict[str, Any] = {
        "model": model,
        "response_format": "verbose_json",
        "timestamp_granularities": ["word"],
        "temperature": 0,
    }
    prompt = (expected_text or "").strip()
    if prompt:
        kwargs["prompt"] = prompt[:2000]
    def create_transcription():
        # Reopen the file for every retry; a failed upload may leave the previous
        # file handle at EOF.
        with audio_path.open("rb") as f:
            return client.audio.transcriptions.create(file=f, **kwargs)

    tr = _retry_openai_call(create_transcription)
    words = getattr(tr, "words", None)
    if words is None and isinstance(tr, dict):
        words = tr.get("words")
    out: list[dict[str, float | str]] = []
    for w in words or []:
        if isinstance(w, dict):
            out.append({"word": str(w.get("word", "")), "start": float(w.get("start", 0)), "end": float(w.get("end", 0))})
        else:
            out.append({"word": str(getattr(w, "word", "")), "start": float(getattr(w, "start", 0)), "end": float(getattr(w, "end", 0))})
    return out
