from __future__ import annotations

from pathlib import Path
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import hashlib
import os
import re
import secrets
from threading import Event, Lock
from typing import Callable, Any

from PIL import Image, ImageStat

from .ai33_client import generate_tts_audio
from .config import AppSettings, MUSIC_DIR
from .openai_tools import generate_scene_prompts, transcribe_words
from .project import next_project_dir, ensure_project_subdirs, load_json, save_json, save_state, save_text
from .renderer import audio_duration, audio_silence_report, find_ffmpeg, render_project
from .scene_splitter import split_into_scenes
from .styles import get_style_prompt
from .character_presets import (
    apply_global_stick_figure_rules,
    build_prompt_bundle,
    get_character_preset,
    resolve_character_preset_style,
    render_prompt_bundle,
    strip_main_character_opt_out,
)
from .runware_client import generate_image
from .subtitles import (
    align_transcription_to_script,
    scene_words_to_srt,
    timed_script_to_srt,
    transcription_needs_audio_retry,
    transcription_quality_score,
)


SUBTITLE_PIPELINE_VERSION = 3
SCENE_MANIFEST_VERSION = 2
WHISPER_TRANSCRIPTION_MODEL = "whisper-1"

# Conservative automatic limits for network-bound paid provider work. These are
# intentionally small: enough to overlap API wait time without turning a large
# project into an uncontrolled burst of paid requests.
IMAGE_API_MAX_WORKERS = 3
AUDIO_API_MAX_WORKERS = 4


def _automatic_api_workers(stage: str, pending_count: int) -> int:
    caps = {"images": IMAGE_API_MAX_WORKERS, "audio": AUDIO_API_MAX_WORKERS}
    if stage not in caps:
        raise ValueError(f"Unknown API stage: {stage}")
    count = max(0, int(pending_count))
    return max(1, min(caps[stage], count or 1))


def _run_bounded_stage_jobs(
    indices: list[int],
    *,
    max_workers: int,
    worker: Callable[[int], Any],
    on_complete: Callable[[int, Any, int, int], None] | None = None,
    stop_requested: Callable[[], bool] | None = None,
) -> dict[int, Any]:
    """Run indexed I/O jobs with only a small rolling set in flight.

    The runner submits at most ``max_workers`` jobs at once and does not enqueue
    the whole project. A pause request therefore stops new paid work from being
    submitted while already-running provider calls are allowed to finish safely.
    Completion callbacks execute on the orchestration thread, not worker threads.
    """
    ordered = [int(index) for index in indices]
    if not ordered:
        return {}
    worker_count = max(1, min(int(max_workers), len(ordered)))
    results: dict[int, Any] = {}
    iterator = iter(ordered)
    active: dict[Any, int] = {}
    completed = 0

    def should_stop() -> bool:
        return bool(stop_requested and stop_requested())

    def fill(executor: ThreadPoolExecutor) -> None:
        while len(active) < worker_count and not should_stop():
            try:
                index = next(iterator)
            except StopIteration:
                break
            active[executor.submit(worker, index)] = index

    first_error: Exception | None = None
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        fill(executor)
        while active:
            done, _ = wait(tuple(active), return_when=FIRST_COMPLETED)
            for future in done:
                index = active.pop(future)
                try:
                    result = future.result()
                except Exception as exc:
                    if first_error is None:
                        first_error = exc
                    continue
                results[index] = result
                completed += 1
                if on_complete:
                    on_complete(index, result, completed, len(ordered))
            # Once one job fails, do not submit any new paid work. Still allow
            # already-running jobs to finish and checkpoint successful results.
            if first_error is None:
                fill(executor)

    if first_error is not None:
        raise first_error

    # Preserve input/index order even though provider jobs finish out of order.
    return {index: results[index] for index in ordered if index in results}


def _asset_signature(path: Path) -> dict[str, int]:
    stat = path.stat()
    return {"size": int(stat.st_size), "mtime_ns": int(stat.st_mtime_ns)}


def _script_signature(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def _valid_image(path: Path) -> bool:
    try:
        if not path.exists() or path.stat().st_size < 512:
            return False
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            rgb = image.convert("RGB")
            if rgb.width < 64 or rgb.height < 64:
                return False
            sample = rgb.copy()
            sample.thumbnail((256, 256))
            stat = ImageStat.Stat(sample)
            mean = sum(stat.mean) / 3.0
            variation = sum(stat.var) / 3.0
            # Do not reuse a service-error image that is effectively pure black.
            if mean < 2.0 and variation < 2.0:
                return False
        return True
    except Exception:
        return False


def _valid_audio(path: Path) -> bool:
    try:
        return path.exists() and path.stat().st_size >= 256 and audio_duration(path) > 0.10
    except Exception:
        return False


def _transcribe_align_and_report(audio_path: Path, scene: str, model: str) -> tuple[list[dict], dict, float]:
    duration = audio_duration(audio_path)
    raw_words = transcribe_words(audio_path, WHISPER_TRANSCRIPTION_MODEL, expected_text=scene)
    aligned_words, report = align_transcription_to_script(scene, raw_words, duration)
    report = dict(report)
    try:
        silence = audio_silence_report(audio_path)
    except Exception as exc:
        silence = {"max_internal_silence": 0.0, "silence_detection_error": str(exc)}
    report.update(silence)
    report["audio_duration"] = round(duration, 4)
    report["audio_signature"] = _asset_signature(audio_path)
    return aligned_words, report, duration


def _validated_scene_transcription(
    audio_path: Path,
    scene: str,
    settings: AppSettings,
    scene_index: int,
    progress: Callable[[str], None] | None = None,
) -> tuple[list[dict], dict, float]:
    """Transcribe, script-align, and retry one genuinely suspicious TTS clip once."""
    aligned, first_report, duration = _transcribe_align_and_report(audio_path, scene, settings.transcription_model)
    first_report["attempt"] = "original"
    debug: dict[str, Any] = {
        "scene_index": scene_index,
        "scene_number": scene_index + 1,
        "selected_attempt": "original",
        "attempts": [first_report],
    }

    if not transcription_needs_audio_retry(first_report):
        debug["final_report"] = first_report
        return aligned, debug, duration

    if progress:
        progress(
            f"Scene {scene_index + 1}: narration timing/text validation found a likely dropout or wrong word; "
            "retrying TTS once..."
        )

    retry_path = audio_path.with_name(f"{audio_path.stem}_validation_retry{audio_path.suffix}")
    try:
        if retry_path.exists():
            retry_path.unlink()
        generate_tts_audio(scene, retry_path, settings.ai33_voice_id, settings.ai33_speed, progress=progress)
        retry_aligned, retry_report, retry_duration = _transcribe_align_and_report(
            retry_path, scene, settings.transcription_model
        )
        retry_report["attempt"] = "retry"
        debug["attempts"].append(retry_report)

        original_score = transcription_quality_score(first_report)
        retry_score = transcription_quality_score(retry_report)
        debug["original_score"] = round(original_score, 4)
        debug["retry_score"] = round(retry_score, 4)

        original_bad = transcription_needs_audio_retry(first_report)
        retry_bad = transcription_needs_audio_retry(retry_report)
        keep_retry = (not retry_bad and original_bad) or retry_score > original_score + 0.01
        if keep_retry:
            os.replace(retry_path, audio_path)
            retry_report["audio_signature"] = _asset_signature(audio_path)
            debug["selected_attempt"] = "retry"
            debug["final_report"] = retry_report
            if progress:
                progress(f"Scene {scene_index + 1}: cleaner replacement narration was kept.")
            return retry_aligned, debug, retry_duration

        debug["final_report"] = first_report
        if progress:
            progress(
                f"Scene {scene_index + 1}: original narration scored better; keeping it and using exact script-only subtitle text."
            )
        return aligned, debug, duration
    finally:
        try:
            if retry_path.exists():
                retry_path.unlink()
        except Exception:
            pass


class PipelinePaused(RuntimeError):
    def __init__(self, project_dir: Path):
        super().__init__(f"Project paused and saved: {project_dir}")
        self.project_dir = project_dir


def _check_pause(stop_event: Event | None, project_dir: Path) -> None:
    if stop_event and stop_event.is_set():
        save_state(project_dir, stage="paused")
        raise PipelinePaused(project_dir)


def _load_prompts(project_dir: Path) -> tuple[list[str] | None, str]:
    data = load_json(project_dir / "image_prompts.json", default=None)
    if isinstance(data, dict) and isinstance(data.get("prompts"), list):
        prompts = [str(item).strip() for item in data.get("prompts", [])]
        if prompts and all(prompts):
            return prompts, str(data.get("style_prompt") or "")
    return None, ""


def _parse_manual_prompts(text: str, expected: int | None = None) -> list[str]:
    """Parse ordered prompts without truncating, merging, or losing continuations."""
    raw = (text or "").strip()
    if not raw:
        return []
    normalized = raw.replace("\r\n", "\n").replace("\r", "\n")
    header = re.compile(r"(?im)^(?:scene\s*)?\d+\s*[\).:-]\s*")
    matches = list(header.finditer(normalized))
    blocks: list[str]
    if matches:
        blocks = []
        for index, match in enumerate(matches):
            end = matches[index + 1].start() if index + 1 < len(matches) else len(normalized)
            body = normalized[match.end():end].strip()
            if body:
                blocks.append(body)
    else:
        blank_blocks = [block.strip() for block in re.split(r"\n\s*\n", normalized) if block.strip()]
        if len(blank_blocks) > 1:
            blocks = blank_blocks
        else:
            # The established unnumbered format is one non-empty prompt per line.
            blocks = [line.strip() for line in normalized.splitlines() if line.strip()]
    return [block for block in blocks if block]

def _apply_style_to_manual_prompt(prompt: str, style_prompt: str) -> str:
    prompt = (prompt or "").strip()
    style_prompt = (style_prompt or "").strip()
    if not style_prompt:
        return prompt
    return (
        f"{prompt}\n\n"
        "Selected Vireo image style to apply strictly across this frame:\n"
        f"{style_prompt}\n\n"
        "Final image requirements: follow the scene prompt, apply the selected style consistently, "
        "no text, no logo, no watermark, clean finished image."
    )


def _effective_style_prompt(settings: AppSettings, selected_style_prompt: str, character_preset) -> str:
    bundle = build_prompt_bundle(
        scene_prompt="Style bundle preview",
        selected_style_prompt=selected_style_prompt,
        character_preset=character_preset,
        include_selected_style=bool(getattr(settings, "apply_style_to_manual_prompts", True)),
        manual_mode=False,
        force_without_character=True,
    )
    style = bundle.get("style_bundle") or {}
    parts = [
        str(style.get("primary_style") or "").strip(),
        str(style.get("selected_style_secondary") or "").strip(),
    ]
    return "\n\n".join([part for part in parts if part]).strip() or selected_style_prompt


def _apply_character_bundle_to_manual_prompt(
    prompt: str,
    selected_style_prompt: str,
    character_preset,
    include_selected_style: bool,
) -> str:
    cleaned_prompt, force_without_character = strip_main_character_opt_out(prompt)
    if not character_preset:
        return _apply_style_to_manual_prompt(cleaned_prompt, selected_style_prompt) if include_selected_style else cleaned_prompt
    bundle = build_prompt_bundle(
        scene_prompt=cleaned_prompt,
        selected_style_prompt=selected_style_prompt,
        character_preset=character_preset,
        include_selected_style=include_selected_style,
        manual_mode=True,
        force_without_character=force_without_character,
    )
    return render_prompt_bundle(bundle)


def _assert_scene_asset_counts(scenes: list[str], prompts: list[str], images: list[Path], audios: list[Path] | None = None) -> None:
    counts = {"scenes": len(scenes), "prompts": len(prompts), "images": len(images)}
    if audios is not None:
        counts["audio"] = len(audios)
    if len(set(counts.values())) != 1:
        raise RuntimeError(
            "Scene asset mapping is inconsistent: " + ", ".join(f"{name}={count}" for name, count in counts.items())
        )
    if not scenes or any(not scene.strip() for scene in scenes):
        raise RuntimeError("One or more scene chunks are empty; generation stopped before paid asset creation.")
    if any(not prompt.strip() for prompt in prompts):
        raise RuntimeError("One or more image prompts are empty; generation stopped to prevent scene/image misalignment.")


def _save_scene_manifest(
    project_dir: Path,
    scenes: list[str],
    prompts: list[str],
    images: list[Path],
    audios: list[Path] | None = None,
    durations: list[float] | None = None,
    verified_image_indices: set[int] | None = None,
    verified_audio_indices: set[int] | None = None,
) -> None:
    verified_image_indices = set(verified_image_indices or set())
    verified_audio_indices = set(verified_audio_indices or set())
    entries: list[dict[str, Any]] = []
    for index, scene in enumerate(scenes):
        image = images[index] if index < len(images) else None
        audio = (
            audios[index]
            if audios and index < len(audios)
            else project_dir / "audio" / f"scene_{index:03}.mp3"
        )
        prompt = prompts[index] if index < len(prompts) else ""
        entry: dict[str, Any] = {
            "scene_number": index + 1,
            "scene_text": scene,
            "scene_signature": _script_signature(scene),
            "image_prompt": prompt,
            "prompt_signature": _script_signature(prompt),
            "image_file": str(image.relative_to(project_dir)) if image else "",
            "audio_file": str(audio.relative_to(project_dir)) if audio else "",
            # Expensive image/audio validation happens at the stage boundary before
            # an index enters these verified sets. Re-running Pillow/FFprobe for
            # every entry on every manifest write made long projects O(N^2).
            "image_ready": bool(image and image.exists() and index in verified_image_indices),
            "audio_ready": bool(audio and audio.exists() and index in verified_audio_indices),
            "image_mapping_verified": index in verified_image_indices,
            "audio_mapping_verified": index in verified_audio_indices,
        }
        if image and image.exists():
            entry["image_signature"] = _asset_signature(image)
        if audio and audio.exists():
            entry["audio_signature"] = _asset_signature(audio)
        if durations and index < len(durations):
            entry["audio_duration"] = round(float(durations[index]), 4)
        entries.append(entry)
    save_json(project_dir / "scene_manifest.json", {
        "version": SCENE_MANIFEST_VERSION,
        "scene_count": len(scenes),
        "entries": entries,
    })


def run_generation(
    script: str,
    settings: AppSettings,
    progress: Callable[[str], None] | None = None,
    project_dir: Path | None = None,
    resume: bool = False,
    stop_event: Event | None = None,
    review_callback: Callable[[Path, list[str], list[Path], AppSettings, list[str]], None] | None = None,
) -> Path:
    # Keep the documented model invariant even if an old config file contains a
    # different transcription model. Word timestamps are requested from whisper-1.
    settings.transcription_model = WHISPER_TRANSCRIPTION_MODEL

    if project_dir is not None and resume:
        requested_project = Path(project_dir)
        saved_script_path = requested_project / "original_script.txt"
        saved_script = saved_script_path.read_text(encoding="utf-8", errors="ignore").strip() if saved_script_path.exists() else ""
        saved_scene_data = load_json(requested_project / "scene_prompts.json", default={}) or {}
        saved_selected_count = saved_scene_data.get("selected_scene_count") if isinstance(saved_scene_data, dict) else None
        changed_script = bool(saved_script and saved_script != (script or "").strip())
        changed_scene_count = saved_selected_count is not None and int(saved_selected_count) != int(settings.scenes)
        if changed_script or changed_scene_count:
            if progress:
                reason = "script changed" if changed_script else "selected scene count changed"
                progress(f"Loaded project cannot be resumed because the {reason}; creating a fresh project.")
            project_dir = None
            resume = False

    if project_dir is None:
        if progress:
            progress("Creating project folder...")
        project_dir = next_project_dir()
    else:
        project_dir = Path(project_dir)
        ensure_project_subdirs(project_dir)
        if progress:
            progress(f"Loading project folder: {project_dir}")

    # Fail before paid API work if the local renderer is unavailable.
    find_ffmpeg()
    if progress:
        progress("FFmpeg and FFprobe preflight passed.")

    selected_style_prompt = get_style_prompt(settings.last_style)
    character_preset = resolve_character_preset_style(
        get_character_preset(getattr(settings, "main_character_preset", "none")),
        getattr(settings, "standard_character_style", "classic"),
    )

    # Direct style-reference images remain intentionally disabled in Update 14/15.
    settings.style_reference_image = ""
    settings.style_reference_summary = ""
    settings.style_reference_signature = ""
    effective_style_prompt = _effective_style_prompt(settings, selected_style_prompt, character_preset)

    save_text(project_dir / "original_script.txt", script)
    save_json(project_dir / "project_metadata.json", settings.sanitized())
    save_state(
        project_dir,
        stage="started",
        script=script,
        script_signature=_script_signature(script),
        settings=settings.sanitized(),
    )
    _check_pause(stop_event, project_dir)

    scene_data = load_json(project_dir / "scene_prompts.json", default=None) if resume else None
    requested_scene_count = max(1, int(settings.scenes))
    if isinstance(scene_data, dict) and isinstance(scene_data.get("scenes"), list):
        scenes = [str(item).strip() for item in scene_data["scenes"] if str(item).strip()]
        if progress:
            progress(f"Loaded {len(scenes)} existing scenes.")
    else:
        scenes = split_into_scenes(script, requested_scene_count)
        if not scenes:
            raise RuntimeError("The script could not be split into any non-empty scenes.")

    if len(scenes) != requested_scene_count:
        raise RuntimeError(
            f"Exact scene split failed before any paid image/audio generation: requested "
            f"{requested_scene_count} scenes but the script produced {len(scenes)} non-empty chunks. "
            "Reduce the Number of Scenes or add more script text."
        )

    # Normalize legacy scene metadata as soon as the exact mapping is known.
    save_json(project_dir / "scene_prompts.json", {
        "selected_scene_count": requested_scene_count,
        "actual_scene_count": len(scenes),
        "scenes": scenes,
    })
    if progress and not (isinstance(scene_data, dict) and isinstance(scene_data.get("scenes"), list)):
        progress(f"Script split into exactly {len(scenes)} scenes.")
    save_state(project_dir, stage="scenes_ready", scene_count=len(scenes))
    _check_pause(stop_event, project_dir)

    previous_manifest = load_json(project_dir / "scene_manifest.json", default={}) if resume else {}
    previous_manifest_entries = {}
    if isinstance(previous_manifest, dict):
        previous_manifest_entries = {
            int(entry.get("scene_number", 0)) - 1: entry
            for entry in previous_manifest.get("entries") or []
            if isinstance(entry, dict) and int(entry.get("scene_number", 0) or 0) > 0
        }
    strict_manifest = isinstance(previous_manifest, dict) and int(previous_manifest.get("version") or 0) >= SCENE_MANIFEST_VERSION
    verified_image_indices: set[int] = {
        index for index, entry in previous_manifest_entries.items()
        if strict_manifest and bool(entry.get("image_mapping_verified"))
    }
    verified_audio_indices: set[int] = {
        index for index, entry in previous_manifest_entries.items()
        if strict_manifest and bool(entry.get("audio_mapping_verified"))
    }

    prompts, style_prompt = _load_prompts(project_dir) if resume else (None, "")
    prompts_rebuilt = not (prompts and len(prompts) == len(scenes))
    if not prompts_rebuilt:
        prompts = list(prompts or [])
        style_prompt = effective_style_prompt
        if progress:
            progress(f"Loaded {len(prompts)} existing image prompts.")
    else:
        style_prompt = effective_style_prompt
        supplied_manual = _parse_manual_prompts(settings.manual_image_prompts_text) if settings.manual_image_prompts_enabled else []
        character_bundle_payload = character_preset.as_prompt_payload() if character_preset else None
        if supplied_manual:
            raw_manual_count = len(supplied_manual)
            if raw_manual_count > len(scenes):
                if progress:
                    progress(
                        f"Manual prompt warning: {raw_manual_count} prompts were supplied for {len(scenes)} scenes; "
                        f"only the first {len(scenes)} confirmed prompts will be used."
                    )
                supplied_manual = supplied_manual[:len(scenes)]
            manual_prompts = [
                _apply_character_bundle_to_manual_prompt(
                    prompt,
                    selected_style_prompt,
                    character_preset,
                    include_selected_style=bool(getattr(settings, "apply_style_to_manual_prompts", True)),
                )
                for prompt in supplied_manual
            ]
            if progress:
                if character_preset:
                    progress("Applying the selected stick-figure character bundle to manual prompts.")
                elif getattr(settings, "apply_style_to_manual_prompts", True):
                    progress("Applying the selected image-style bundle to manual prompts.")
            prompts = manual_prompts
            if len(prompts) < len(scenes):
                if progress:
                    progress(
                        f"Manual prompts provided for {len(prompts)}/{len(scenes)} scenes; "
                        "generating only the missing prompts with OpenAI."
                    )
                generated_missing = generate_scene_prompts(
                    scenes[len(prompts):],
                    style_prompt,
                    settings.openai_model,
                    progress=progress,
                    character_bundle=character_bundle_payload,
                )
                if character_preset:
                    generated_missing = [apply_global_stick_figure_rules(prompt, character_preset) for prompt in generated_missing]
                prompts.extend(generated_missing)
            if progress:
                progress(f"Using {min(raw_manual_count, len(scenes))} manual image prompts.")
        else:
            prompts = generate_scene_prompts(
                scenes,
                style_prompt,
                settings.openai_model,
                progress=progress,
                character_bundle=character_bundle_payload,
            )
            if character_preset:
                prompts = [apply_global_stick_figure_rules(prompt, character_preset) for prompt in prompts]

        if len(prompts) != len(scenes):
            raise RuntimeError(
                f"OpenAI/manual prompt count mismatch: expected {len(scenes)}, received {len(prompts)}. "
                "No image generation was started."
            )
        save_text(
            project_dir / "image_prompts.txt",
            "\n\n".join(f"Scene {index:03}: {prompt}" for index, prompt in enumerate(prompts, start=1)),
        )
        save_json(project_dir / "image_prompts.json", {
            "prompts": prompts,
            "style_prompt": style_prompt,
            "selected_style_prompt": selected_style_prompt,
            "character_preset_id": getattr(settings, "main_character_preset", "none"),
            "standard_character_style": getattr(settings, "standard_character_style", "classic"),
            "manual_prompt_mode": bool(supplied_manual),
            "manual_prompt_count": len(supplied_manual),
            "apply_style_to_manual_prompts": bool(getattr(settings, "apply_style_to_manual_prompts", True)),
        })

    prompts = list(prompts or [])
    if len(prompts) != len(scenes):
        raise RuntimeError(f"Scene/prompt count mismatch: scenes={len(scenes)}, prompts={len(prompts)}")
    save_state(project_dir, stage="prompts_ready", prompt_count=len(prompts), style_prompt=style_prompt)
    _check_pause(stop_event, project_dir)

    images = [project_dir / "images" / f"scene_{index:03}.png" for index in range(len(scenes))]
    _assert_scene_asset_counts(scenes, prompts, images)
    reusable_images: set[int] = set()
    pending_images: list[int] = []
    for index, (prompt, out) in enumerate(zip(prompts, images)):
        previous_entry = previous_manifest_entries.get(index) if strict_manifest else None
        mapping_matches = (
            not strict_manifest
            or (
                index in verified_image_indices
                and isinstance(previous_entry, dict)
                and previous_entry.get("scene_signature") == _script_signature(scenes[index])
                and previous_entry.get("prompt_signature") == _script_signature(prompt)
                and previous_entry.get("image_signature") == (_asset_signature(out) if out.exists() else None)
            )
        )
        if resume and not prompts_rebuilt and mapping_matches:
            # A strict manifest means this exact file signature was already fully
            # validated before it was marked mapping_verified. Trust that unchanged
            # checkpoint instead of reopening every image on every resume.
            can_reuse = bool(out.exists()) if strict_manifest else _valid_image(out)
        else:
            can_reuse = False
        if can_reuse:
            reusable_images.add(index)
        else:
            pending_images.append(index)

    verified_image_indices = set(reusable_images)
    if reusable_images and progress:
        progress(f"Reusing {len(reusable_images)}/{len(images)} verified existing images from the saved project.")

    # Regenerating even one image invalidates a previously completed review.
    state_before_images = load_json(project_dir / "vireo_state.json", default={}) or {}
    review_complete = bool(state_before_images.get("review_complete")) and not pending_images

    def image_worker(index: int) -> dict[str, int]:
        out = images[index]
        # The current mapping says this path is stale/non-reusable. Remove it so a
        # provider failure can never leave an old frame looking like a new result.
        try:
            if out.exists():
                out.unlink()
        except Exception:
            pass
        generate_image(
            prompts[index],
            out,
            settings.runware_model,
            settings.image_width,
            settings.image_height,
            settings.image_steps,
            progress=progress,
        )
        if not _valid_image(out):
            raise RuntimeError(f"Generated image {index + 1} failed validation: {out}")
        return _asset_signature(out)

    def image_complete(index: int, _result: Any, _completed: int, _total_pending: int) -> None:
        verified_image_indices.add(index)
        save_state(
            project_dir,
            stage="images",
            images_done=len(verified_image_indices),
            review_complete=False,
        )
        _save_scene_manifest(
            project_dir, scenes, prompts, images,
            verified_image_indices=verified_image_indices,
            verified_audio_indices=verified_audio_indices,
        )
        if progress:
            progress(f"Generated image {index + 1}/{len(images)} ({len(verified_image_indices)}/{len(images)} ready)")

    if pending_images:
        workers = _automatic_api_workers("images", len(pending_images))
        if progress:
            progress(f"Generating {len(pending_images)} missing image(s) with up to {workers} safe parallel API job(s).")
        _run_bounded_stage_jobs(
            pending_images,
            max_workers=workers,
            worker=image_worker,
            on_complete=image_complete,
            stop_requested=(lambda: bool(stop_event and stop_event.is_set())),
        )
        _check_pause(stop_event, project_dir)
    else:
        save_state(
            project_dir,
            stage="images",
            images_done=len(images),
            review_complete=review_complete,
        )
        # One cheap checkpoint write replaces N repeated validation/manifest writes.
        _save_scene_manifest(
            project_dir, scenes, prompts, images,
            verified_image_indices=verified_image_indices,
            verified_audio_indices=verified_audio_indices,
        )
        _check_pause(stop_event, project_dir)

    state = load_json(project_dir / "vireo_state.json", default={}) or {}
    if settings.image_review_enabled and not state.get("review_complete"):
        save_state(project_dir, stage="image_review")
        if review_callback:
            if progress:
                progress("Image generation complete. Waiting for your image review...")
            review_callback(project_dir, prompts, images, settings, scenes)
        # Revalidate after possible regeneration before paid audio work starts.
        for index, image in enumerate(images, start=1):
            if not _valid_image(image):
                raise RuntimeError(f"Scene {index} image is invalid after review/regeneration.")
        save_state(project_dir, stage="image_review_complete", review_complete=True)
        verified_image_indices.update(range(len(images)))
        _save_scene_manifest(
            project_dir, scenes, prompts, images,
            verified_image_indices=verified_image_indices,
            verified_audio_indices=verified_audio_indices,
        )
        _check_pause(stop_event, project_dir)

    state = load_json(project_dir / "vireo_state.json", default={}) or {}
    ai33_tasks = dict(state.get("ai33_tasks")) if isinstance(state.get("ai33_tasks"), dict) else {}
    audios = [project_dir / "audio" / f"scene_{index:03}.mp3" for index in range(len(scenes))]
    reusable_audios: set[int] = set()
    pending_audios: list[int] = []
    existing_task_ids: dict[int, str] = {}
    for index, (scene, out) in enumerate(zip(scenes, audios)):
        task_key = str(index)
        task_record = ai33_tasks.get(task_key) if isinstance(ai33_tasks.get(task_key), dict) else {}
        previous_entry = previous_manifest_entries.get(index) if strict_manifest else None
        audio_mapping_matches = (
            not strict_manifest
            or (
                index in verified_audio_indices
                and isinstance(previous_entry, dict)
                and previous_entry.get("scene_signature") == _script_signature(scene)
                and previous_entry.get("audio_signature") == (_asset_signature(out) if out.exists() else None)
            )
        )
        if resume and audio_mapping_matches:
            can_reuse = bool(out.exists()) if strict_manifest else _valid_audio(out)
        else:
            can_reuse = False
        if can_reuse:
            reusable_audios.add(index)
            continue

        task_signature_matches = (
            not task_record.get("scene_signature")
            or task_record.get("scene_signature") == _script_signature(scene)
        )
        existing_task_ids[index] = str(task_record.get("task_id") or "") if resume and task_signature_matches else ""
        pending_audios.append(index)

    verified_audio_indices = set(reusable_audios)
    if reusable_audios and progress:
        progress(f"Reusing {len(reusable_audios)}/{len(audios)} verified existing audio files from the saved project.")

    ai33_state_lock = Lock()

    def remember_task(task_id: str, scene_index: int) -> None:
        scene_text = scenes[scene_index]
        with ai33_state_lock:
            ai33_tasks[str(scene_index)] = {
                "task_id": task_id,
                "status": "submitted",
                "scene_signature": _script_signature(scene_text),
            }
            # Persist immediately so a crash/restart polls this paid task instead
            # of submitting a duplicate request. The lock prevents lost updates
            # when multiple AI33 submissions finish at nearly the same time.
            save_state(project_dir, ai33_tasks=dict(ai33_tasks))

    def audio_worker(index: int) -> dict[str, int]:
        out = audios[index]
        generate_tts_audio(
            scenes[index],
            out,
            settings.ai33_voice_id,
            settings.ai33_speed,
            progress=progress,
            existing_task_id=existing_task_ids.get(index) or None,
            on_task_submitted=lambda task_id, scene_index=index: remember_task(task_id, scene_index),
        )
        if not _valid_audio(out):
            raise RuntimeError(f"Generated audio {index + 1} failed FFmpeg validation: {out}")
        return _asset_signature(out)

    def audio_complete(index: int, _result: Any, _completed: int, _total_pending: int) -> None:
        verified_audio_indices.add(index)
        task_key = str(index)
        with ai33_state_lock:
            current = ai33_tasks.get(task_key) if isinstance(ai33_tasks.get(task_key), dict) else {}
            current = dict(current)
            current.update({
                "status": "complete",
                "scene_signature": _script_signature(scenes[index]),
                "audio_signature": _asset_signature(audios[index]),
            })
            ai33_tasks[task_key] = current
            save_state(
                project_dir,
                ai33_tasks=dict(ai33_tasks),
                stage="audio",
                audios_done=len(verified_audio_indices),
            )
        _save_scene_manifest(
            project_dir, scenes, prompts, images, audios,
            verified_image_indices=verified_image_indices,
            verified_audio_indices=verified_audio_indices,
        )
        if progress:
            progress(f"Generated audio {index + 1}/{len(audios)} ({len(verified_audio_indices)}/{len(audios)} ready)")

    if pending_audios:
        workers = _automatic_api_workers("audio", len(pending_audios))
        if progress:
            progress(f"Generating {len(pending_audios)} missing audio file(s) with up to {workers} safe parallel AI33 job(s).")
        _run_bounded_stage_jobs(
            pending_audios,
            max_workers=workers,
            worker=audio_worker,
            on_complete=audio_complete,
            stop_requested=(lambda: bool(stop_event and stop_event.is_set())),
        )
        _check_pause(stop_event, project_dir)
    else:
        save_state(project_dir, stage="audio", audios_done=len(audios), ai33_tasks=dict(ai33_tasks))
        _save_scene_manifest(
            project_dir, scenes, prompts, images, audios,
            verified_image_indices=verified_image_indices,
            verified_audio_indices=verified_audio_indices,
        )
        _check_pause(stop_event, project_dir)

    _assert_scene_asset_counts(scenes, prompts, images, audios)
    expected_indices = set(range(len(scenes)))
    if verified_image_indices != expected_indices or verified_audio_indices != expected_indices:
        raise RuntimeError(
            "Scene asset verification is incomplete before subtitles/render: "
            f"images={len(verified_image_indices)}/{len(scenes)}, "
            f"audio={len(verified_audio_indices)}/{len(scenes)}"
        )
    # Every verified index was content-validated when generated/reviewed or was
    # restored from an unchanged strict manifest signature. Keep only cheap file
    # presence checks here; renderer/subtitle stages still validate what they use.
    for index, (image, audio) in enumerate(zip(images, audios), start=1):
        if not image.exists() or image.stat().st_size < 512:
            raise RuntimeError(f"Scene {index} image is missing before subtitles/render.")
        if not audio.exists() or audio.stat().st_size < 256:
            raise RuntimeError(f"Scene {index} audio is missing before subtitles/render.")

    srt_path: Path | None = None
    durations: list[float] = []
    subtitle_debug_path = project_dir / "subtitle_debug.json"
    subtitle_debug = load_json(subtitle_debug_path, default={}) if resume else {}
    current_signatures = [_asset_signature(path) for path in audios]
    scene_signatures = [_script_signature(scene) for scene in scenes]
    reusable_subtitles = (
        settings.subtitles_enabled
        and resume
        and (project_dir / "subtitles.srt").exists()
        and (project_dir / "subtitles.srt").stat().st_size > 20
        and isinstance(subtitle_debug, dict)
        and subtitle_debug.get("pipeline_version") == SUBTITLE_PIPELINE_VERSION
        and subtitle_debug.get("audio_signatures") == current_signatures
        and subtitle_debug.get("scene_signatures") == scene_signatures
        and int(subtitle_debug.get("words_per_caption") or 0) == int(settings.words_per_caption)
        and bool(subtitle_debug.get("all_caps")) == bool(settings.subtitle_all_caps)
    )

    if settings.subtitles_enabled:
        srt_path = project_dir / "subtitles.srt"
        if reusable_subtitles:
            # Subtitle reuse already proves the current audio signatures match the
            # previously validated set. Reuse its saved durations to avoid another
            # N-file FFprobe pass during Load Project.
            saved_state = load_json(project_dir / "vireo_state.json", default={}) or {}
            saved_durations = saved_state.get("durations")
            if isinstance(saved_durations, list) and len(saved_durations) == len(audios):
                try:
                    candidate_durations = [float(value) for value in saved_durations]
                    if all(value > 0.10 for value in candidate_durations):
                        durations = candidate_durations
                except Exception:
                    durations = []
            if not durations and isinstance(subtitle_debug, dict):
                candidate_durations = []
                for row in subtitle_debug.get("scenes") or []:
                    if not isinstance(row, dict):
                        candidate_durations = []
                        break
                    report = row.get("final_report") if isinstance(row.get("final_report"), dict) else {}
                    try:
                        candidate_durations.append(float(report.get("audio_duration")))
                    except Exception:
                        candidate_durations = []
                        break
                if len(candidate_durations) == len(audios) and all(value > 0.10 for value in candidate_durations):
                    durations = candidate_durations
            if not durations:
                durations = [audio_duration(path) for path in audios]
            if progress:
                progress("Using validated scene-bounded, script-aligned subtitles.")
        else:
            try:
                if progress:
                    progress(
                        "Transcribing narration with OpenAI whisper-1 and using it only for timing; "
                        "subtitle text will come exactly from each scene script."
                    )
                scene_word_groups: list[list[dict]] = []
                offset = 0.0
                scene_debug: list[dict] = []
                validated_durations: list[float] = []
                for index, (audio, scene) in enumerate(zip(audios, scenes)):
                    _check_pause(stop_event, project_dir)
                    aligned_words, report, duration = _validated_scene_transcription(
                        audio, scene, settings, index, progress=progress
                    )
                    validated_durations.append(duration)
                    scene_debug.append(report)
                    scene_word_groups.append([
                        {
                            "word": word["word"],
                            "start": float(word["start"]) + offset,
                            "end": float(word["end"]) + offset,
                        }
                        for word in aligned_words
                    ])
                    offset += duration

                durations = validated_durations
                # Caption chunks reset at every scene boundary. This prevents the
                # last words of one image from mixing with the next scene's words.
                scene_words_to_srt(
                    scene_word_groups,
                    srt_path,
                    settings.words_per_caption,
                    all_caps=settings.subtitle_all_caps,
                )
                current_signatures = [_asset_signature(path) for path in audios]
                save_json(subtitle_debug_path, {
                    "pipeline_version": SUBTITLE_PIPELINE_VERSION,
                    "transcription_model": WHISPER_TRANSCRIPTION_MODEL,
                    "script_alignment": True,
                    "scene_bounded_captions": True,
                    "audio_signatures": current_signatures,
                    "scene_signatures": scene_signatures,
                    "words_per_caption": int(settings.words_per_caption),
                    "all_caps": bool(settings.subtitle_all_caps),
                    "scenes": scene_debug,
                })
                if progress:
                    progress(
                        "Validated subtitles created. Whisper-only words were removed, missing script words were restored, "
                        "and captions were kept inside their own scenes."
                    )
            except Exception as exc:
                if progress:
                    progress(f"Validated transcription failed, using exact scene-bounded timed-script subtitles: {exc}")
                durations = [audio_duration(path) for path in audios]
                timed_script_to_srt(
                    scenes,
                    durations,
                    srt_path,
                    settings.words_per_caption,
                    all_caps=settings.subtitle_all_caps,
                )
                save_json(subtitle_debug_path, {
                    "pipeline_version": SUBTITLE_PIPELINE_VERSION,
                    "transcription_model": WHISPER_TRANSCRIPTION_MODEL,
                    "script_alignment": False,
                    "scene_bounded_captions": True,
                    "fallback": "timed_script",
                    "error": str(exc),
                    "audio_signatures": [_asset_signature(path) for path in audios],
                    "scene_signatures": scene_signatures,
                    "words_per_caption": int(settings.words_per_caption),
                    "all_caps": bool(settings.subtitle_all_caps),
                })
    else:
        # No transcription step will supply durations when subtitles are disabled.
        durations = [audio_duration(path) for path in audios]
    save_state(project_dir, stage="subtitles_ready", durations=durations)
    _save_scene_manifest(
        project_dir, scenes, prompts, images, audios, durations,
        verified_image_indices=verified_image_indices,
        verified_audio_indices=verified_audio_indices,
    )
    _check_pause(stop_event, project_dir)

    music_path = None
    if settings.bg_music and settings.bg_music != "None":
        candidate = MUSIC_DIR / settings.bg_music
        if candidate.exists():
            music_path = candidate

    current_state = load_json(project_dir / "vireo_state.json", default={}) or {}
    render_seed = current_state.get("render_seed")
    if not isinstance(render_seed, int) or render_seed <= 0:
        render_seed = secrets.randbelow(2_000_000_000) + 1
    if progress:
        progress("Rendering one verified image and one verified narration file for every scene...")
    save_state(project_dir, stage="rendering", render_seed=render_seed)
    final = render_project(
        images=images,
        audios=audios,
        out_dir=project_dir,
        width=settings.image_width,
        height=settings.image_height,
        workers=settings.render_workers,
        ken_burns=settings.ken_burns,
        heartbeat=settings.heartbeat,
        transitions=settings.transitions_enabled,
        music_path=music_path,
        music_volume=settings.music_volume,
        srt_path=srt_path,
        font_name=settings.subtitle_font,
        font_size=settings.subtitle_font_size,
        subtitle_position=settings.subtitle_position,
        subtitle_outline_size=settings.subtitle_outline_size,
        subtitle_color=settings.subtitle_color,
        force_h264=settings.force_h264,
        random_animations=settings.random_animations,
        random_seed=render_seed,
        progress=progress,
        output_basename=settings.video_title,
    )
    save_json(project_dir / "metadata.json", {
        "final_video": str(final),
        "video_title": settings.video_title,
        "scene_count": len(scenes),
        "prompt_count": len(prompts),
        "image_count": len(images),
        "audio_count": len(audios),
        "scenes": scenes,
        "durations": durations,
        "scene_manifest": "scene_manifest.json",
    })
    save_state(project_dir, stage="done", final_video=str(final))
    if progress:
        progress(f"Video generated successfully: {final}")
    return final
