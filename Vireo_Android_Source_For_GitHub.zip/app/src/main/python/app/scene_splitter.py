from __future__ import annotations

import math
from .script_analyzer import split_sentences, count_words


def _split_long_text(text: str, chunks: int) -> list[str]:
    words = text.split()
    if not words:
        return []
    if chunks <= 1:
        return [text.strip()]
    chunks = min(int(chunks), len(words))
    base, extra = divmod(len(words), chunks)
    output: list[str] = []
    cursor = 0
    for index in range(chunks):
        size = base + (1 if index < extra else 0)
        part = " ".join(words[cursor:cursor + size]).strip()
        if part:
            output.append(part)
        cursor += size
    return output


def _balanced_sentence_partition(sentences: list[str], target_scenes: int) -> list[str]:
    """Partition ordered sentences into exactly target_scenes balanced chunks."""
    target_scenes = max(1, min(int(target_scenes), len(sentences)))
    word_counts = [max(1, count_words(sentence)) for sentence in sentences]
    scenes: list[str] = []
    start = 0

    for scene_index in range(target_scenes - 1):
        remaining_scene_count = target_scenes - scene_index
        max_end = len(sentences) - (remaining_scene_count - 1)
        remaining_words = sum(word_counts[start:])
        ideal_words = remaining_words / remaining_scene_count

        running = 0
        best_end = start + 1
        best_error = float("inf")
        for end in range(start + 1, max_end + 1):
            running += word_counts[end - 1]
            error = abs(running - ideal_words)
            if error < best_error:
                best_error = error
                best_end = end
            # Once we have crossed the ideal, later endpoints can only become
            # less balanced for this scene.
            if running >= ideal_words:
                break

        scenes.append(" ".join(sentences[start:best_end]).strip())
        start = best_end

    scenes.append(" ".join(sentences[start:]).strip())
    return [scene for scene in scenes if scene]


def split_into_scenes(script: str, target_scenes: int) -> list[str]:
    script = (script or "").strip()
    if not script:
        return []
    target_scenes = max(1, int(target_scenes))
    sentences = split_sentences(script)
    if not sentences:
        return _split_long_text(script, target_scenes)

    if target_scenes < len(sentences):
        return _balanced_sentence_partition(sentences, target_scenes)

    scenes = sentences[:]
    # If more scenes are requested than sentence count, split the longest
    # multi-word scene until the target is reached. This preserves script order.
    while len(scenes) < target_scenes:
        splittable = [index for index, scene in enumerate(scenes) if count_words(scene) >= 2]
        if not splittable:
            break
        index = max(splittable, key=lambda item: count_words(scenes[item]))
        parts = _split_long_text(scenes[index], 2)
        if len(parts) != 2:
            break
        scenes = scenes[:index] + parts + scenes[index + 1:]

    return [scene.strip() for scene in scenes if scene.strip()]
