from __future__ import annotations

from pathlib import Path
import json
import os
import random
import re
import shutil
import subprocess
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Any

from .config import RESOURCES_DIR
from .project import safe_video_filename
from .subtitles import ass_style


class RenderError(RuntimeError):
    pass


# Keep Update 17-21's proven audio-render pipeline version unchanged. Update 22
# invalidates only scene-motion cache records via SCENE_MOTION_VERSION below.
AUDIO_RENDER_PIPELINE_VERSION = 4
SCENE_MOTION_VERSION = 2

SCENE_CHANGE_SFX_DIR = RESOURCES_DIR / "sfx"
CAMERA_SHUTTER_SFX = SCENE_CHANGE_SFX_DIR / "camera_shutter.wav"
WHOOSH_SFX = SCENE_CHANGE_SFX_DIR / "whoosh.wav"
SCENE_CHANGE_SFX_VOLUME = 0.60
FAST_SCENE_CHANGE_SECONDS = 3.5
RANDOM_SCENE_CHANGE_SFX_PROBABILITY = 0.32

# Update 24: remove the measured low-level broadband/radio-like AI33 room tone.
# Keep cleanup on the reconstructed continuous narration timeline so scene mapping,
# word tails, and Update 22 cut-SFX timing stay untouched. Noise tracking is disabled
# because the real clips begin near digital silence; adaptive tracking learned that
# near-zero opening instead of the later low-level room-tone bed.
VOICE_CLEANUP_FILTER = "highpass=f=70,lowpass=f=15500,afftdn=nr=24:nf=-28:tn=0:rf=-80:gs=12"
FINAL_MIX_LIMITER_FILTER = "alimiter=limit=0.95:attack=5:release=50:level=0:latency=1"


def _android_ffmpeg_bridge():
    """Return the Android FFmpeg bridge when running under Chaquopy."""
    try:
        from java import jclass
        return jclass("com.vireo.studio.FFmpegBridge")
    except Exception:
        return None


def _run(cmd: list[str], progress: Callable[[str], None] | None = None) -> None:
    if progress:
        progress(" ".join(cmd[:3]) + " ...")
    bridge = _android_ffmpeg_bridge()
    if bridge is not None:
        try:
            bridge.executeJson(json.dumps([str(item) for item in cmd[1:]]))
            return
        except Exception as exc:
            raise RenderError(str(exc)) from exc
    proc = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="ignore",
    )
    if proc.returncode != 0:
        raise RenderError(proc.stderr[-6000:] or proc.stdout[-6000:] or f"Command failed: {cmd}")


def find_ffmpeg() -> tuple[str, str]:
    if _android_ffmpeg_bridge() is not None:
        # Sentinels preserve every existing command builder; FFmpegKit supplies the executables.
        return "ffmpeg", "ffprobe"
    local_bin = RESOURCES_DIR / "ffmpeg" / "bin"
    ffmpeg = local_bin / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
    ffprobe = local_bin / ("ffprobe.exe" if os.name == "nt" else "ffprobe")
    if ffmpeg.exists() and ffprobe.exists():
        return str(ffmpeg), str(ffprobe)
    sys_ffmpeg = shutil.which("ffmpeg")
    sys_ffprobe = shutil.which("ffprobe")
    if sys_ffmpeg and sys_ffprobe:
        return sys_ffmpeg, sys_ffprobe
    try:
        import imageio_ffmpeg

        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if sys_ffprobe:
            return exe, sys_ffprobe
    except Exception:
        pass
    raise RenderError(
        "FFmpeg and FFprobe were not found. Put ffmpeg.exe and ffprobe.exe in "
        "resources/ffmpeg/bin or install FFmpeg on PATH."
    )


def _probe_media(path: Path) -> dict[str, Any]:
    if not path.exists() or path.stat().st_size <= 0:
        raise RenderError(f"Media file is missing or empty: {path}")
    _, ffprobe = find_ffmpeg()
    cmd = [
        ffprobe,
        "-v",
        "error",
        "-show_streams",
        "-show_format",
        "-of",
        "json",
        str(path),
    ]
    bridge = _android_ffmpeg_bridge()
    if bridge is not None:
        try:
            output = str(bridge.probeJson(json.dumps([str(item) for item in cmd[1:]])))
            return json.loads(output or "{}")
        except Exception as exc:
            raise RenderError(f"FFprobe could not read {path.name}: {exc}") from exc
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore")
    if proc.returncode != 0:
        raise RenderError(f"FFprobe could not read {path.name}: {proc.stderr[-2000:]}")
    try:
        return json.loads(proc.stdout or "{}")
    except Exception as exc:
        raise RenderError(f"FFprobe returned invalid media information for {path.name}.") from exc


def _duration_from_probe(data: dict[str, Any], stream_type: str | None = None) -> float:
    candidates: list[float] = []
    for stream in data.get("streams") or []:
        if stream_type and stream.get("codec_type") != stream_type:
            continue
        for key in ("duration",):
            try:
                value = float(stream.get(key))
                if value > 0:
                    candidates.append(value)
            except Exception:
                pass
        try:
            time_base = str(stream.get("time_base") or "")
            duration_ts = float(stream.get("duration_ts"))
            if "/" in time_base:
                num, den = time_base.split("/", 1)
                value = duration_ts * float(num) / float(den)
                if value > 0:
                    candidates.append(value)
        except Exception:
            pass
    try:
        value = float((data.get("format") or {}).get("duration"))
        if value > 0:
            candidates.append(value)
    except Exception:
        pass
    return max(candidates, default=0.0)


def audio_duration(path: Path) -> float:
    """Return the real decodable audio duration; never silently guess five seconds."""
    data = _probe_media(Path(path))
    if not any(stream.get("codec_type") == "audio" for stream in data.get("streams") or []):
        raise RenderError(f"No audio stream was found in {path.name}.")
    duration = _duration_from_probe(data, "audio")
    if duration <= 0.05:
        raise RenderError(f"Could not determine a valid audio duration for {path.name}.")
    return duration


def media_duration(path: Path, stream_type: str | None = None) -> float:
    data = _probe_media(Path(path))
    duration = _duration_from_probe(data, stream_type)
    if duration <= 0.05:
        raise RenderError(f"Could not determine a valid media duration for {Path(path).name}.")
    return duration


def media_is_valid(path: Path, *, require_video: bool = False, require_audio: bool = False) -> bool:
    try:
        data = _probe_media(path)
        stream_types = {str(stream.get("codec_type")) for stream in data.get("streams") or []}
        if require_video and "video" not in stream_types:
            return False
        if require_audio and "audio" not in stream_types:
            return False
        return _duration_from_probe(data) > 0.05
    except Exception:
        return False


def rendered_scene_is_valid(path: Path, expected_duration: float, tolerance: float = 0.18) -> bool:
    """Validate streams and ensure a rendered still scene covers its narration."""
    try:
        data = _probe_media(path)
        stream_types = {str(stream.get("codec_type")) for stream in data.get("streams") or []}
        if not {"video", "audio"}.issubset(stream_types):
            return False
        video_duration = _duration_from_probe(data, "video")
        audio_stream_duration = _duration_from_probe(data, "audio")
        expected = float(expected_duration)
        allowed = max(float(tolerance), 2.0 / 30.0)
        return (
            video_duration >= expected - allowed
            and audio_stream_duration >= expected - allowed
            and abs(video_duration - audio_stream_duration) <= allowed * 2.0
        )
    except Exception:
        return False


def audio_silence_report(path: Path, minimum_silence: float = 0.65, noise: str = "-45dB") -> dict[str, Any]:
    """Measure long internal silence without treating normal leading/trailing padding as corruption."""
    ffmpeg, _ = find_ffmpeg()
    duration = audio_duration(path)
    cmd = [
        ffmpeg,
        "-hide_banner",
        "-nostats",
        "-i",
        str(path),
        "-af",
        f"silencedetect=noise={noise}:d={float(minimum_silence):.3f}",
        "-f",
        "null",
        "-",
    ]
    bridge = _android_ffmpeg_bridge()
    if bridge is not None:
        try:
            text = str(bridge.executeForLogsJson(json.dumps([str(item) for item in cmd[1:]])))
        except Exception as exc:
            raise RenderError(str(exc)) from exc
    else:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore")
        text = proc.stderr or ""
    starts = [float(x) for x in re.findall(r"silence_start:\s*([0-9.]+)", text)]
    ends = [(float(a), float(b)) for a, b in re.findall(r"silence_end:\s*([0-9.]+)\s*\|\s*silence_duration:\s*([0-9.]+)", text)]
    intervals: list[dict[str, float]] = []
    for index, start in enumerate(starts):
        if index < len(ends):
            end, silence_duration = ends[index]
        else:
            end, silence_duration = duration, max(0.0, duration - start)
        intervals.append({"start": start, "end": end, "duration": silence_duration})
    internal = [
        item
        for item in intervals
        if item["start"] > 0.18 and item["end"] < duration - 0.18
    ]
    return {
        "audio_duration": round(duration, 4),
        "silence_intervals": intervals,
        "internal_silence_intervals": internal,
        "max_internal_silence": round(max((item["duration"] for item in internal), default=0.0), 4),
    }


def _file_signature(path: Path) -> dict[str, int]:
    stat = path.stat()
    return {"size": int(stat.st_size), "mtime_ns": int(stat.st_mtime_ns)}


def _atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except Exception:
            pass


def _temporary_media_path(out_path: Path) -> Path:
    return out_path.with_name(
        f".{out_path.stem}.{os.getpid()}.{threading.get_ident()}.tmp{out_path.suffix}"
    )


MOTION_EFFECTS = [
    "slow_zoom_in",
    "slow_zoom_out",
    "pan_left",
    "pan_right",
    "pan_up",
    "pan_down",
    "diagonal_down_right",
    "diagonal_up_left",
    "pulse_zoom",
    "breathing_zoom",
    "gentle_sway",
    "micro_drift",
    "push_in_pan",
    # Kept as a legacy plan name so old seeds stay stable. It is now a safe
    # focus pulse instead of a full-black blink.
    "camera_blink",
    "static_hold",
]

TRANSITION_EFFECTS = [
    "fade_black",
    "fade_white",
    "soft_dip_black",
    "soft_dip_white",
    "quick_flash",
    "none",
]


def scene_effect_plan(scene_index: int, random_seed: int = 0) -> dict[str, str | float]:
    seed = int(random_seed or 1) + (int(scene_index) + 1) * 104729
    rng = random.Random(seed)
    motion = rng.choice(MOTION_EFFECTS)
    transition = rng.choice(TRANSITION_EFFECTS)
    blink_position = rng.uniform(0.38, 0.72)
    return {"motion": motion, "transition": transition, "blink_position": blink_position}


def scene_change_sfx_plan(scene_durations: list[float], random_seed: int = 0) -> list[dict[str, Any]]:
    """Return a deterministic SFX plan tied only to exact scene boundaries.

    Boundary index 1 is the cut from scene 1 -> scene 2. The first cut always
    uses the supplied camera shutter. Any cut following a very short scene uses
    the supplied whoosh, so runs of short scenes naturally produce consecutive
    whooshes. Remaining cuts receive a seeded sparse random shutter/whoosh.
    """
    durations: list[float] = []
    for value in scene_durations:
        try:
            duration = float(value)
        except Exception:
            continue
        if duration > 0.0:
            durations.append(duration)
    if len(durations) < 2:
        return []

    rng = random.Random(int(random_seed or 1) + 7_919_431)
    plan: list[dict[str, Any]] = []
    boundary_time = 0.0
    for boundary_index in range(1, len(durations)):
        previous_scene_duration = durations[boundary_index - 1]
        boundary_time += previous_scene_duration
        kind = ""
        reason = ""
        if boundary_index == 1:
            kind = "camera_shutter"
            reason = "first_scene_change"
        elif previous_scene_duration <= FAST_SCENE_CHANGE_SECONDS:
            kind = "whoosh"
            reason = "fast_scene_change"
        elif rng.random() < RANDOM_SCENE_CHANGE_SFX_PROBABILITY:
            kind = rng.choice(("whoosh", "camera_shutter"))
            reason = "seeded_random_scene_change"
        if kind:
            plan.append({
                "boundary_index": boundary_index,
                "boundary_time": round(boundary_time, 6),
                "kind": kind,
                "volume": SCENE_CHANGE_SFX_VOLUME,
                "reason": reason,
            })
    return plan


def _transition_filter(transition: str, duration: float) -> str:
    """Create a subtle brightness transition without ever replacing the image with black/white."""
    if duration <= 1.2 or transition == "none":
        return ""
    end_start = max(0.0, duration - 0.30)
    if transition in {"fade_white", "soft_dip_white", "quick_flash"}:
        amount = 0.07 if transition != "quick_flash" else 0.10
    else:
        amount = -0.045
    expression = (
        f"if(lt(t,0.25),{amount:.4f}*(1-t/0.25),"
        f"if(gt(t,{end_start:.3f}),{amount:.4f}*((t-{end_start:.3f})/0.30),0))"
    )
    return f",eq=brightness='{expression}':eval=frame"


def _scene_filter(
    duration: float,
    width: int,
    height: int,
    ken_burns: bool,
    heartbeat: bool,
    transitions: bool,
    random_animations: bool = False,
    scene_index: int = 0,
    random_seed: int = 0,
) -> str:
    fps = 30
    frames = max(1, int(round(duration * fps)))
    base = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},setsar=1"
    plan = scene_effect_plan(scene_index, random_seed)
    transition = _transition_filter(str(plan["transition"]), duration) if transitions else ""

    if random_animations:
        effect = str(plan["motion"])
        big = f"scale={width*2}:{height*2}:force_original_aspect_ratio=increase,crop={width*2}:{height*2}"
        center_x = "iw/2-(iw/zoom/2)"
        center_y = "ih/2-(ih/zoom/2)"
        if effect == "slow_zoom_in":
            motion = f"{big},zoompan=z='min(1.0+on*0.00010,1.035)':d={frames}:x='{center_x}':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "slow_zoom_out":
            motion = f"{big},zoompan=z='max(1.005,1.035-on*0.00009)':d={frames}:x='{center_x}':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "pan_left":
            motion = f"{big},zoompan=z='1.03':d={frames}:x='(iw-iw/zoom)*(0.65-0.30*on/{frames})':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "pan_right":
            motion = f"{big},zoompan=z='1.03':d={frames}:x='(iw-iw/zoom)*(0.35+0.30*on/{frames})':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "pan_up":
            motion = f"{big},zoompan=z='1.03':d={frames}:x='{center_x}':y='(ih-ih/zoom)*(0.65-0.30*on/{frames})':s={width}x{height}:fps={fps}"
        elif effect == "pan_down":
            motion = f"{big},zoompan=z='1.03':d={frames}:x='{center_x}':y='(ih-ih/zoom)*(0.35+0.30*on/{frames})':s={width}x{height}:fps={fps}"
        elif effect == "diagonal_down_right":
            motion = f"{big},zoompan=z='1.03':d={frames}:x='(iw-iw/zoom)*(0.38+0.24*on/{frames})':y='(ih-ih/zoom)*(0.38+0.24*on/{frames})':s={width}x{height}:fps={fps}"
        elif effect == "diagonal_up_left":
            motion = f"{big},zoompan=z='1.03':d={frames}:x='(iw-iw/zoom)*(0.62-0.24*on/{frames})':y='(ih-ih/zoom)*(0.62-0.24*on/{frames})':s={width}x{height}:fps={fps}"
        elif effect == "pulse_zoom":
            motion = f"{big},zoompan=z='1.018+0.004*sin(on/30)':d={frames}:x='{center_x}':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "breathing_zoom":
            motion = f"{big},zoompan=z='1.016+0.003*sin(on/45)':d={frames}:x='{center_x}':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "gentle_sway":
            motion = f"{big},zoompan=z='1.02':d={frames}:x='{center_x}+(iw-iw/zoom)*0.025*sin(on/40)':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "micro_drift":
            motion = f"{big},zoompan=z='1.018':d={frames}:x='{center_x}+(iw-iw/zoom)*0.015*sin(on/52)':y='{center_y}+(ih-ih/zoom)*0.015*cos(on/49)':s={width}x{height}:fps={fps}"
        elif effect == "push_in_pan":
            motion = f"{big},zoompan=z='min(1.0+on*0.00008,1.03)':d={frames}:x='(iw-iw/zoom)*(0.42+0.16*on/{frames})':y='{center_y}':s={width}x{height}:fps={fps}"
        elif effect == "camera_blink":
            # Update 14 rendered a full-black blink here. Preserve the deterministic
            # effect name but use a small focus pulse so no image ever disappears.
            motion = f"{big},zoompan=z='1.015+0.003*sin(on/35)':d={frames}:x='{center_x}':y='{center_y}':s={width}x{height}:fps={fps}"
        else:
            motion = f"{base},fps={fps}"
        return f"{motion},format=yuv420p{transition}"

    if ken_burns:
        motion = f"scale={width*2}:{height*2}:force_original_aspect_ratio=increase,crop={width*2}:{height*2},zoompan=z='min(zoom+0.00035,1.035)':d={frames}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s={width}x{height}:fps={fps}"
    elif heartbeat and duration > 7:
        motion = f"{base},zoompan=z='1+0.004*sin(on/36)':d={frames}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s={width}x{height}:fps={fps}"
    else:
        motion = f"{base},fps={fps}"
    return f"{motion},format=yuv420p{transition}"


def render_scene(
    image: Path,
    audio: Path,
    out_path: Path,
    width: int,
    height: int,
    ken_burns: bool,
    heartbeat: bool,
    transitions: bool,
    random_animations: bool = False,
    scene_index: int = 0,
    random_seed: int = 0,
    progress=None,
    known_duration: float | None = None,
) -> Path:
    image, audio, out_path = Path(image), Path(audio), Path(out_path)
    if not image.exists() or image.stat().st_size <= 0:
        raise RenderError(f"Scene {scene_index + 1} image is missing or empty: {image}")
    if known_duration is None:
        duration = audio_duration(audio)
    else:
        duration = float(known_duration)
        if duration <= 0.05:
            raise RenderError(f"Scene {scene_index + 1} narration duration is invalid: {duration!r}")
    ffmpeg, _ = find_ffmpeg()
    vf = _scene_filter(duration, width, height, ken_burns, heartbeat, transitions, random_animations, scene_index, random_seed)
    temp_path = _temporary_media_path(out_path)
    try:
        cmd = [
            ffmpeg,
            "-y",
            "-fflags",
            "+genpts",
            "-loop",
            "1",
            "-framerate",
            "30",
            "-i",
            str(image),
            "-i",
            str(audio),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-vf",
            vf,
            # A single TTS file needs timestamp normalization, not async sample
            # insertion/removal. This avoids audible micro-stops.
            "-af",
            f"aresample=48000:first_pts=0,atrim=start=0:end={duration:.6f},asetpts=N/SR/TB",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-pix_fmt",
            "yuv420p",
            "-r",
            "30",
            "-fps_mode",
            "cfr",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-ar",
            "48000",
            "-avoid_negative_ts",
            "make_zero",
            "-max_interleave_delta",
            "0",
            "-movflags",
            "+faststart",
            "-t",
            f"{duration:.6f}",
            str(temp_path),
        ]
        _run(cmd, progress)
        if not rendered_scene_is_valid(temp_path, duration):
            raise RenderError(
                f"Rendered scene {scene_index + 1} did not preserve the narration duration or required streams."
            )
        os.replace(temp_path, out_path)
        return out_path
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass


def _concat_line(path: Path) -> str:
    # FFmpeg concat-demuxer escaping for apostrophes in Windows/user folder names.
    escaped = path.resolve().as_posix().replace("'", "'\\''")
    return f"file '{escaped}'"


def _write_concat_manifest(
    out_path: Path,
    paths: list[Path],
    durations: list[float],
    label: str,
) -> Path:
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{out_path.stem}.{label}.",
        suffix=".ffconcat",
        dir=str(out_path.parent),
    )
    manifest = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write("ffconcat version 1.0\n")
            for path, duration in zip(paths, durations):
                handle.write(_concat_line(path) + "\n")
                handle.write(f"duration {duration:.6f}\n")
                handle.write(f"outpoint {duration:.6f}\n")
        return manifest
    except Exception:
        try:
            manifest.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def concat_scenes(
    scene_videos: list[Path],
    out_path: Path,
    progress=None,
    source_audios: list[Path] | None = None,
    source_durations: list[float] | None = None,
    scene_videos_prevalidated: bool = False,
) -> Path:
    """Stitch scene video and narration on fresh, gap-free timelines.

    Rendered scene video is already H.264, so it is concatenated through a
    temporary ffconcat manifest and stream-copied instead of being encoded a
    second time. Original narration sources are concatenated separately and
    encoded once to AAC on a fresh continuous timeline. Keeping the ordered
    paths in manifest files also prevents Windows process command lines from
    growing with the number of scenes.
    """
    scene_videos = [Path(path) for path in scene_videos]
    if not scene_videos:
        raise RenderError("No rendered scenes were supplied for concatenation.")

    if source_audios is None:
        audio_sources = scene_videos
    else:
        audio_sources = [Path(path) for path in source_audios]
        if len(audio_sources) != len(scene_videos):
            raise RenderError(
                f"Scene/audio concat count mismatch: {len(scene_videos)} scene videos and "
                f"{len(audio_sources)} narration files."
            )

    if source_durations is None:
        durations: list[float] = []
        for index, path in enumerate(audio_sources, start=1):
            try:
                durations.append(audio_duration(path))
            except Exception as exc:
                raise RenderError(f"Narration source {index} is invalid: {exc}") from exc
    else:
        if len(source_durations) != len(scene_videos):
            raise RenderError(
                f"Scene/duration concat count mismatch: {len(scene_videos)} scene videos and "
                f"{len(source_durations)} narration durations."
            )
        durations = []
        for index, value in enumerate(source_durations, start=1):
            try:
                duration = float(value)
            except Exception as exc:
                raise RenderError(f"Narration duration {index} is invalid: {value!r}") from exc
            if duration <= 0.05:
                raise RenderError(f"Narration duration {index} is invalid: {duration!r}")
            durations.append(duration)

    if not scene_videos_prevalidated:
        for index, (path, expected_duration) in enumerate(zip(scene_videos, durations), start=1):
            if not rendered_scene_is_valid(path, expected_duration):
                raise RenderError(
                    f"Rendered scene {index} is invalid or shorter than its narration: {path}"
                )

    ffmpeg, _ = find_ffmpeg()
    out_path = Path(out_path)
    temp_path = _temporary_media_path(out_path)
    video_manifest: Path | None = None
    audio_manifest: Path | None = None
    expected_duration = sum(durations)

    try:
        video_manifest = _write_concat_manifest(out_path, scene_videos, durations, "video")
        audio_manifest = _write_concat_manifest(out_path, audio_sources, durations, "audio")
        cmd = [
            ffmpeg,
            "-y",
            "-fflags",
            "+genpts",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(video_manifest),
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(audio_manifest),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-c:v",
            "copy",
            "-af",
            f"aresample=48000:first_pts=0,{VOICE_CLEANUP_FILTER},"
            f"atrim=start=0:end={expected_duration:.6f},asetpts=N/SR/TB",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-ar",
            "48000",
            "-avoid_negative_ts",
            "make_zero",
            "-max_interleave_delta",
            "0",
            "-movflags",
            "+faststart",
            "-t",
            f"{expected_duration:.6f}",
            str(temp_path),
        ]
        _run(cmd, progress)
        if not media_is_valid(temp_path, require_video=True, require_audio=True):
            raise RenderError("The stitched video failed validation.")
        stitched_duration = media_duration(temp_path)
        if abs(stitched_duration - expected_duration) > max(0.25, 2.0 / 30.0):
            raise RenderError(
                f"The stitched video duration is inconsistent: expected {expected_duration:.3f}s, "
                f"got {stitched_duration:.3f}s."
            )
        os.replace(temp_path, out_path)
        return out_path
    finally:
        for path in (temp_path, video_manifest, audio_manifest):
            try:
                if path is not None and path.exists():
                    path.unlink()
            except Exception:
                pass

def _escape_subtitle_path(path: Path) -> str:
    value = str(path.resolve()).replace("\\", "/")
    value = value.replace(":", "\\:").replace("'", "\\'").replace("[", "\\[").replace("]", "\\]")
    return value


def _write_filter_complex_script(out_path: Path, graph: str) -> Path:
    """Store long FFmpeg audio graphs in a temp file, not the Windows command line."""
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{out_path.stem}.audio_filters.",
        suffix=".ffgraph",
        dir=str(out_path.parent),
    )
    path = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(graph)
            handle.write("\n")
        return path
    except Exception:
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _scene_change_sfx_graph(
    plan: list[dict[str, Any]],
    input_indexes: dict[str, int],
    music_input_index: int | None,
    music_volume: int,
) -> str:
    """Build a sample-aligned audio graph using only the two bundled user SFX."""
    chains: list[str] = ["[0:a]aresample=48000:first_pts=0,asetpts=N/SR/TB[voice]"]
    event_labels: list[str] = []
    event_counter = 0

    for kind in ("camera_shutter", "whoosh"):
        events = [event for event in plan if event.get("kind") == kind]
        if not events:
            continue
        input_index = input_indexes[kind]
        source_prefix = "shutter" if kind == "camera_shutter" else "whoosh"
        if len(events) == 1:
            event = events[0]
            delay_samples = max(0, int(round(float(event["boundary_time"]) * 48000.0)))
            label = f"sfx_event_{event_counter}"
            chains.append(
                f"[{input_index}:a]aresample=48000:first_pts=0,asetpts=PTS-STARTPTS,"
                f"volume={SCENE_CHANGE_SFX_VOLUME:.6f},adelay={delay_samples}S:all=1[{label}]"
            )
            event_labels.append(label)
            event_counter += 1
            continue

        split_labels = [f"{source_prefix}_split_{i}" for i in range(len(events))]
        split_targets = "".join(f"[{label}]" for label in split_labels)
        chains.append(
            f"[{input_index}:a]aresample=48000:first_pts=0,asetpts=PTS-STARTPTS,"
            f"volume={SCENE_CHANGE_SFX_VOLUME:.6f},asplit={len(events)}{split_targets}"
        )
        for split_label, event in zip(split_labels, events):
            delay_samples = max(0, int(round(float(event["boundary_time"]) * 48000.0)))
            label = f"sfx_event_{event_counter}"
            chains.append(f"[{split_label}]adelay={delay_samples}S:all=1[{label}]")
            event_labels.append(label)
            event_counter += 1

    sfx_inputs = "".join(f"[{label}]" for label in event_labels)
    if music_input_index is None:
        chains.append(
            f"[voice]{sfx_inputs}amix=inputs={1 + len(event_labels)}:duration=first:"
            f"dropout_transition=0:normalize=0,{FINAL_MIX_LIMITER_FILTER}[aout]"
        )
    else:
        chains.append(
            f"[voice]{sfx_inputs}amix=inputs={1 + len(event_labels)}:duration=first:"
            "dropout_transition=0:normalize=0[voice_sfx]"
        )
        vol = max(0, min(100, int(music_volume))) / 100.0
        chains.append(
            f"[{music_input_index}:a]volume={vol},aresample=48000:first_pts=0,asetpts=N/SR/TB[bg]"
        )
        chains.append(
            f"[voice_sfx][bg]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,"
            f"{FINAL_MIX_LIMITER_FILTER}[aout]"
        )
    return ";".join(chains)


def add_music_and_subtitles(
    input_video: Path,
    out_path: Path,
    music_path: Path | None = None,
    music_volume: int = 2,
    srt_path: Path | None = None,
    font_name: str = "Arial",
    font_size: int = 54,
    subtitle_position: str = "bottom",
    subtitle_outline_size: float = 2.0,
    subtitle_color: str = "#FFFFFF",
    force_h264: bool = True,
    scene_durations: list[float] | None = None,
    random_seed: int = 0,
    progress=None,
) -> Path:
    ffmpeg, _ = find_ffmpeg()
    input_video, out_path = Path(input_video), Path(out_path)
    input_duration = media_duration(input_video)
    temp_path = _temporary_media_path(out_path)
    cmd = [ffmpeg, "-y", "-i", str(input_video)]
    filter_parts: list[str] = []
    map_parts: list[str] = []
    filter_script: Path | None = None

    sfx_plan = scene_change_sfx_plan(scene_durations or [], random_seed=random_seed)
    sfx_input_indexes: dict[str, int] = {}
    next_input_index = 1
    if sfx_plan:
        required_kinds = {str(event.get("kind") or "") for event in sfx_plan}
        asset_map = {
            "camera_shutter": CAMERA_SHUTTER_SFX,
            "whoosh": WHOOSH_SFX,
        }
        for kind in ("camera_shutter", "whoosh"):
            if kind not in required_kinds:
                continue
            asset = asset_map[kind]
            if not asset.exists() or asset.stat().st_size <= 0:
                raise RenderError(f"Required scene-change SFX asset is missing: {asset}")
            sfx_input_indexes[kind] = next_input_index
            cmd += ["-i", str(asset)]
            next_input_index += 1

    music_input_index: int | None = None
    if music_path and Path(music_path).exists():
        music_input_index = next_input_index
        cmd += ["-stream_loop", "-1", "-i", str(music_path)]
        next_input_index += 1

    if sfx_plan:
        graph = _scene_change_sfx_graph(
            sfx_plan,
            sfx_input_indexes,
            music_input_index,
            music_volume,
        )
        filter_script = _write_filter_complex_script(out_path, graph)
        cmd += ["-filter_complex_script", str(filter_script)]
        map_parts += ["-map", "0:v:0", "-map", "[aout]"]
    elif music_input_index is not None:
        vol = max(0, min(100, int(music_volume))) / 100.0
        filter_parts.append(
            f"[0:a]aresample=48000:first_pts=0,asetpts=N/SR/TB[voice];"
            f"[{music_input_index}:a]volume={vol},aresample=48000:first_pts=0,asetpts=N/SR/TB[bg];"
            f"[voice][bg]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,"
            f"{FINAL_MIX_LIMITER_FILTER}[aout]"
        )
        map_parts += ["-map", "0:v:0", "-map", "[aout]"]
    else:
        map_parts += ["-map", "0:v:0", "-map", "0:a:0?"]

    vf_parts: list[str] = []
    # The Update 17 concat path intentionally stream-copies rendered H.264 scenes.
    # That can preserve a tiny positive first-video PTS. When SFX are mixed at
    # narration-derived scene boundaries, normalize video PTS here so the visible
    # cut and the sample-delayed SFX share the same zero-based timeline.
    if sfx_plan:
        vf_parts.append("setpts=PTS-STARTPTS")
    if srt_path and Path(srt_path).exists() and Path(srt_path).stat().st_size > 0:
        style = ass_style(font_name, font_size, subtitle_position, subtitle_outline_size, subtitle_color).replace("'", "")
        vf_parts.append(f"subtitles='{_escape_subtitle_path(Path(srt_path))}':force_style='{style}'")
    vf = ",".join(vf_parts) or None

    if filter_parts:
        cmd += ["-filter_complex", ";".join(filter_parts)]
    cmd += map_parts
    if not filter_parts and not sfx_plan:
        cmd += ["-af", "aresample=48000:first_pts=0,asetpts=N/SR/TB"]
    if vf:
        cmd += ["-vf", vf]

    # A video filter cannot be used with stream-copy. Encode whenever subtitles
    # are burned even if the advanced force-H264 checkbox is off.
    if force_h264 or vf:
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"]
    else:
        cmd += ["-c:v", "copy"]
    cmd += [
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-ar",
        "48000",
        "-avoid_negative_ts",
        "make_zero",
        "-max_interleave_delta",
        "0",
        "-movflags",
        "+faststart",
        "-t",
        f"{input_duration:.6f}",
        str(temp_path),
    ]
    try:
        _run(cmd, progress)
        if not media_is_valid(temp_path, require_video=True, require_audio=True):
            raise RenderError("The final video failed validation.")
        final_duration = media_duration(temp_path)
        if abs(final_duration - input_duration) > max(0.25, 2.0 / 30.0):
            raise RenderError(
                f"The final video duration changed unexpectedly: expected {input_duration:.3f}s, "
                f"got {final_duration:.3f}s."
            )
        os.replace(temp_path, out_path)
        return out_path
    finally:
        for path in (temp_path, filter_script):
            try:
                if path is not None and path.exists():
                    path.unlink()
            except Exception:
                pass


def _scene_render_record(
    index: int,
    image: Path,
    audio: Path,
    width: int,
    height: int,
    ken_burns: bool,
    heartbeat: bool,
    transitions: bool,
    random_animations: bool,
    random_seed: int,
) -> dict[str, Any]:
    return {
        "index": index,
        "scene_motion_version": SCENE_MOTION_VERSION,
        "image_signature": _file_signature(image),
        "audio_signature": _file_signature(audio),
        "width": int(width),
        "height": int(height),
        "ken_burns": bool(ken_burns),
        "heartbeat": bool(heartbeat),
        "transitions": bool(transitions),
        "random_animations": bool(random_animations),
        "effect": scene_effect_plan(index, random_seed),
    }


def render_project(
    images: list[Path],
    audios: list[Path],
    out_dir: Path,
    width: int = 1920,
    height: int = 1080,
    workers: int = 4,
    ken_burns: bool = True,
    heartbeat: bool = True,
    transitions: bool = True,
    music_path: Path | None = None,
    music_volume: int = 2,
    srt_path: Path | None = None,
    font_name: str = "Arial",
    font_size: int = 54,
    subtitle_position: str = "bottom",
    subtitle_outline_size: float = 2.0,
    subtitle_color: str = "#FFFFFF",
    force_h264: bool = True,
    random_animations: bool = True,
    random_seed: int = 0,
    progress: Callable[[str], None] | None = None,
    output_basename: str = "",
) -> Path:
    images = [Path(path) for path in images]
    audios = [Path(path) for path in audios]
    out_dir = Path(out_dir)
    if not images or len(images) != len(audios):
        raise RenderError(f"Image/audio count mismatch: {len(images)} images and {len(audios)} audio files.")
    audio_durations: list[float] = []
    for index, (image, audio) in enumerate(zip(images, audios), start=1):
        if not image.exists() or image.stat().st_size <= 0:
            raise RenderError(f"Scene {index} image is missing or empty: {image}")
        try:
            audio_durations.append(audio_duration(audio))
        except Exception as exc:
            raise RenderError(f"Scene {index} audio is invalid: {exc}") from exc

    scene_dir = out_dir / "rendered_scenes"
    scene_dir.mkdir(parents=True, exist_ok=True)
    scene_videos = [scene_dir / f"scene_{i:03}.mp4" for i in range(len(images))]
    plan_path = out_dir / "animation_plan.json"
    previous_plan: dict[str, Any] = {}
    if plan_path.exists():
        try:
            previous_plan = json.loads(plan_path.read_text(encoding="utf-8"))
        except Exception:
            previous_plan = {}
    previous_records = {
        int(record.get("index")): record
        for record in previous_plan.get("render_records") or []
        if isinstance(record, dict) and isinstance(record.get("index"), int)
    }
    can_reuse_version = previous_plan.get("audio_render_pipeline_version") == AUDIO_RENDER_PIPELINE_VERSION

    current_records = [
        _scene_render_record(
            i,
            images[i],
            audios[i],
            width,
            height,
            ken_burns,
            heartbeat,
            transitions,
            random_animations,
            random_seed,
        )
        for i in range(len(images))
    ]

    def one(i: int):
        current = current_records[i]
        reusable = (
            can_reuse_version
            and previous_records.get(i) == current
            and rendered_scene_is_valid(scene_videos[i], audio_durations[i])
        )
        if reusable:
            if progress:
                progress(f"Using verified rendered scene {i + 1}/{len(images)}")
            return scene_videos[i]
        plan = current["effect"]
        if progress:
            progress(f"Scene {i + 1} motion={plan['motion']} transition={plan['transition']}")
        return render_scene(
            images[i],
            audios[i],
            scene_videos[i],
            width,
            height,
            ken_burns,
            heartbeat,
            transitions,
            random_animations,
            i,
            random_seed,
            progress,
            known_duration=audio_durations[i],
        )

    with ThreadPoolExecutor(max_workers=max(1, int(workers))) as executor:
        futures = {executor.submit(one, i): i for i in range(len(images))}
        for future in as_completed(futures):
            index = futures[future]
            future.result()
            if progress:
                progress(f"Rendered scene {index + 1}/{len(images)}")

    plan_data = {
        "audio_render_pipeline_version": AUDIO_RENDER_PIPELINE_VERSION,
        "random_seed": int(random_seed),
        "random_animations": bool(random_animations),
        "random_transitions": bool(transitions),
        "scenes": [record["effect"] for record in current_records],
        "render_records": current_records,
    }
    _atomic_json(plan_path, plan_data)

    stitched = out_dir / "stitched.mp4"
    concat_scenes(
        scene_videos,
        stitched,
        progress,
        source_audios=audios,
        source_durations=audio_durations,
        scene_videos_prevalidated=True,
    )
    final = out_dir / safe_video_filename(output_basename, out_dir.name)
    add_music_and_subtitles(
        stitched,
        final,
        music_path,
        music_volume,
        srt_path,
        font_name,
        font_size,
        subtitle_position,
        subtitle_outline_size,
        subtitle_color,
        force_h264,
        scene_durations=audio_durations,
        random_seed=random_seed,
        progress=progress,
    )

    expected_total = sum(audio_durations)
    final_duration = media_duration(final)
    debug_entries = []
    for index, (image, audio, rendered, record) in enumerate(
        zip(images, audios, scene_videos, current_records), start=1
    ):
        debug_entries.append({
            "scene_number": index,
            "image_file": str(image),
            "audio_file": str(audio),
            "rendered_file": str(rendered),
            "image_signature": _file_signature(image),
            "audio_signature": _file_signature(audio),
            "rendered_signature": _file_signature(rendered),
            "narration_duration": round(audio_durations[index - 1], 6),
            "rendered_duration": round(media_duration(rendered), 6),
            "effect": record["effect"],
        })
    _atomic_json(out_dir / "render_debug.json", {
        "pipeline_version": AUDIO_RENDER_PIPELINE_VERSION,
        "scene_count": len(images),
        "expected_total_duration": round(expected_total, 6),
        "stitched_duration": round(media_duration(stitched), 6),
        "final_duration": round(final_duration, 6),
        "one_image_one_audio_per_scene": True,
        "scene_change_sfx": scene_change_sfx_plan(audio_durations, random_seed=random_seed),
        "entries": debug_entries,
    })
    return final
