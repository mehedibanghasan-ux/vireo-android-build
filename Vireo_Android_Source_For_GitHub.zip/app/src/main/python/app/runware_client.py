from __future__ import annotations

from pathlib import Path
import base64
import os
import tempfile
import mimetypes
from decimal import Decimal, InvalidOperation
import re
import random
import time
import uuid
from typing import Callable, Any

import requests
from PIL import Image, ImageStat

from .config import get_api_key


class RunwareError(RuntimeError):
    pass


class RunwareDownloadError(RunwareError):
    """A generated image exists, but its CDN file could not be downloaded.

    This error must never cause a second paid image-generation submission.
    The same project scene can safely retry/resume later.
    """


_SESSION = requests.Session()
_TRANSIENT_STATUS = {408, 409, 425, 429, 500, 502, 503, 504, 520, 522, 524}


RUNWARE_MIN_DIMENSION = 128
RUNWARE_MAX_DIMENSION = 2048
RUNWARE_DIMENSION_MULTIPLE = 16
RUNWARE_ENDPOINT = "https://api.runware.ai/v1"
RUNWARE_CONTENT_ENDPOINT = "https://content.runware.ai"
GPT_IMAGE_2_MODEL = "openai:gpt-image@2"
GPT_IMAGE_2_QUALITY = "low"

RUNWARE_FALLBACK_MODELS = [
    {"name": "GPT Image 2", "air": GPT_IMAGE_2_MODEL, "version": "low quality", "architecture": "OpenAI"},
    {"name": "FLUX.2 [klein] 9B", "air": "runware:400@2", "version": "default", "architecture": "flux"},
    {"name": "FLUX.1 [schnell]", "air": "runware:100@1", "version": "fast", "architecture": "flux"},
    {"name": "FLUX.1 [dev]", "air": "runware:101@1", "version": "dev", "architecture": "flux"},
]


def model_label(model: dict) -> str:
    air = str(model.get("air") or "").strip()
    if air == GPT_IMAGE_2_MODEL:
        return "GPT Image 2 • Low quality • OpenAI"
    name = str(model.get("name") or model.get("air") or "Runware model")
    version = str(model.get("version") or "").strip()
    arch = str(model.get("architecture") or "").strip()
    bits = [name]
    if version and version.lower() not in name.lower():
        bits.append(version)
    if arch:
        bits.append(arch)
    return " • ".join(bits)


def _unique_mapping(models: list[dict]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    used: dict[str, int] = {}
    for m in models:
        air = str(m.get("air") or "").strip()
        if not air:
            continue
        base = model_label(m)
        used[base] = used.get(base, 0) + 1
        label = base if used[base] == 1 else f"{base} ({used[base]})"
        mapping[label] = air
    return mapping


def fallback_model_mapping() -> dict[str, str]:
    return _unique_mapping(RUNWARE_FALLBACK_MODELS)


def _catalog_records(payload: Any) -> list[dict[str, Any]]:
    """Extract model records from current and legacy catalog response shapes."""
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("models", "data", "results", "items"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            nested = _catalog_records(value)
            if nested:
                return nested
    return []


def fetch_image_model_pricing(timeout: int = 20) -> dict[str, dict[str, Any]]:
    """Fetch Runware's public image-model catalog pricing in one request.

    Pricing is display-only. A failure here must never prevent the authenticated
    model search or image generation workflow from continuing.
    """
    response = requests.get(
        f"{RUNWARE_CONTENT_ENDPOINT}/models",
        params={"category": "image", "limit": 1000, "offset": 0},
        timeout=timeout,
    )
    response.raise_for_status()
    records = _catalog_records(response.json())
    pricing: dict[str, dict[str, Any]] = {}
    for item in records:
        air = str(item.get("air") or item.get("model") or item.get("id") or "").strip()
        if air:
            pricing[air] = item
    return pricing


def _price_decimal(value: Any) -> Decimal | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float, Decimal)):
        try:
            return Decimal(str(value))
        except InvalidOperation:
            return None
    if isinstance(value, str):
        match = re.search(r"(?:USD\s*)?\$?\s*(\d+(?:\.\d+)?)", value.replace(",", ""), re.I)
        if match:
            try:
                return Decimal(match.group(1))
            except InvalidOperation:
                return None
    return None


def _format_usd(value: Decimal) -> str:
    text = format(value.normalize(), "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return f"${text or '0'}"


def per_image_cost_label(pricing: dict[str, Any] | None) -> str:
    """Return a concise catalog cost label suitable for a model-picker row."""
    if not isinstance(pricing, dict):
        return "Varies by size/steps"

    values: list[Decimal] = []
    examples = pricing.get("pricingExamples") or pricing.get("pricing_examples") or []
    if isinstance(examples, list):
        for example in examples:
            if isinstance(example, dict):
                value = _price_decimal(
                    example.get("price")
                    if example.get("price") is not None
                    else example.get("cost")
                )
                if value is not None and value >= 0:
                    values.append(value)

    if not values:
        for key in ("price", "cost", "pricePerImage", "price_per_image"):
            value = _price_decimal(pricing.get(key))
            if value is not None and value >= 0:
                values.append(value)

    unique = sorted(set(values))
    if not unique:
        return "Varies by size/steps"
    if len(unique) == 1:
        return f"{_format_usd(unique[0])} / image"
    return f"{_format_usd(unique[0])}–{_format_usd(unique[-1])} / image"


def model_options(
    models: list[dict[str, Any]],
    pricing_by_air: dict[str, dict[str, Any]] | None = None,
) -> list[dict[str, str]]:
    """Build unique selectable model rows while preserving the AIR mapping."""
    pricing_by_air = pricing_by_air or {}
    options: list[dict[str, str]] = []
    used: dict[str, int] = {}
    for model in models:
        air = str(model.get("air") or "").strip()
        if not air:
            continue
        base = model_label(model)
        used[base] = used.get(base, 0) + 1
        label = base if used[base] == 1 else f"{base} ({used[base]})"
        pricing = pricing_by_air.get(air)
        if pricing is None and any(
            key in model for key in ("pricingExamples", "pricing_examples", "price", "cost", "pricePerImage")
        ):
            pricing = model
        cost_label = per_image_cost_label(pricing)
        if air == GPT_IMAGE_2_MODEL:
            cost_label = "$0.006 @ 1024×1024 low; 16:9 varies"
        options.append({
            "label": label,
            "air": air,
            "cost_label": cost_label,
        })
    return options




def is_gpt_image_2_model(model: str) -> bool:
    return (model or "").strip() == GPT_IMAGE_2_MODEL


def recommended_steps_for_model(model: str, label: str = "") -> tuple[int, str]:
    if is_gpt_image_2_model(model):
        return 4, "Image Steps are ignored; GPT Image 2 is locked to Low quality"
    text = f"{model} {label}".lower()
    if model.strip() == "runware:400@2" or any(token in text for token in ("klein", "schnell", "fast", "lightning", "turbo", "distill")):
        return 4, "Recommended for fast/distilled models"
    if model.strip() == "runware:400@3" or any(token in text for token in ("base", "dev", "pro", "quality")):
        return 28, "Recommended for higher-quality base/dev models"
    return 4, "General safe default"

def model_id_from_label(label: str, mapping: dict[str, str] | None = None) -> str:
    if mapping and label in mapping:
        return mapping[label]
    if "—" in label:
        return label.rsplit("—", 1)[-1].strip()
    return label.strip()


def _runware_safe_dimension(value: int | float | str) -> int:
    """Return a Runware-safe image dimension.

    Runware rejects image width/height values that are outside 128-2048 or
    not divisible by 16. 1920x1080 is a common video size, but 1080 is not
    divisible by 16, so it must be sent to Runware as 1088 and then cropped
    back to 1080 by the video renderer.
    """
    try:
        raw = int(float(value))
    except Exception:
        raw = RUNWARE_MIN_DIMENSION

    raw = max(RUNWARE_MIN_DIMENSION, min(RUNWARE_MAX_DIMENSION, raw))
    rounded = int(round(raw / RUNWARE_DIMENSION_MULTIPLE) * RUNWARE_DIMENSION_MULTIPLE)
    return max(RUNWARE_MIN_DIMENSION, min(RUNWARE_MAX_DIMENSION, rounded))


def runware_safe_size(width: int | float | str, height: int | float | str) -> tuple[int, int]:
    return _runware_safe_dimension(width), _runware_safe_dimension(height)


def _validate_downloaded_image(path: Path) -> None:
    try:
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            rgb = image.convert("RGB")
            if rgb.width < 64 or rgb.height < 64:
                raise RunwareError(f"Runware returned an image that is too small: {rgb.size}")
            # Reject truly blank/near-black service-error frames while allowing
            # legitimate dark cinematic images with visible variation.
            sample = rgb.copy()
            sample.thumbnail((256, 256))
            stat = ImageStat.Stat(sample)
            mean = sum(stat.mean) / 3.0
            variation = sum(stat.var) / 3.0
            if mean < 2.0 and variation < 2.0:
                raise RunwareError("Runware returned a blank black image instead of a usable scene.")
    except RunwareError:
        raise
    except Exception as exc:
        raise RunwareError(f"Downloaded Runware image is invalid or incomplete: {exc}") from exc


def _download(url: str, out_path: Path, timeout: int = 180, retries: int = 3) -> Path:
    """Download one already-generated image without resubmitting the paid task."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    last_error: Exception | None = None
    for attempt in range(max(1, int(retries))):
        fd, temp_name = tempfile.mkstemp(
            prefix=f".{out_path.name}.", suffix=f".tmp{out_path.suffix}", dir=str(out_path.parent)
        )
        os.close(fd)
        temp_path = Path(temp_name)
        try:
            with _SESSION.get(url, stream=True, timeout=(20, timeout)) as response:
                response.raise_for_status()
                with temp_path.open("wb") as handle:
                    for chunk in response.iter_content(chunk_size=1024 * 256):
                        if chunk:
                            handle.write(chunk)
                    handle.flush()
                    os.fsync(handle.fileno())
            if temp_path.stat().st_size < 512:
                raise RunwareError("Runware returned an empty or incomplete image file.")
            _validate_downloaded_image(temp_path)
            os.replace(temp_path, out_path)
            return out_path
        except requests.exceptions.RequestException as exc:
            last_error = exc
            if attempt + 1 >= max(1, int(retries)):
                break
            time.sleep(min(8.0, 1.5 * (2 ** attempt)) + random.uniform(0.0, 0.4))
        finally:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass
    raise RunwareDownloadError(f"Runware image URL download failed after retries: {last_error}")

def _clean_api_key(raw: str) -> str:
    """Accept the common key formats users paste and return only the raw key.

    The Runware REST API accepts either an Authorization header containing
    ``Bearer <API_KEY>`` or a payload authentication object containing the raw
    ``apiKey`` value. If a user pastes the whole header/value into Settings,
    the previous code could send ``Bearer Bearer ...`` and trigger an
    authentication error from Runware. Normalising the value here makes the app
    tolerant of all common pasted formats without changing any UI behavior.
    """
    key = (raw or "").strip().strip('"').strip("'").strip()
    if not key:
        return ""

    # Handle values pasted as RUNWARE_API_KEY=xxxxx
    if key.upper().startswith("RUNWARE_API_KEY") and "=" in key:
        key = key.split("=", 1)[1].strip()

    # Handle values pasted as Authorization: Bearer xxxxx
    if key.lower().startswith("authorization:") and ":" in key:
        key = key.split(":", 1)[1].strip()

    # Handle values pasted as Bearer xxxxx
    if key.lower().startswith("bearer "):
        key = key[7:].strip()

    return key.strip().strip('"').strip("'").strip()


def _api_key() -> str:
    key = _clean_api_key(get_api_key("RUNWARE_API_KEY"))
    if not key:
        raise RunwareError("RUNWARE_API_KEY is missing. Add it in Settings or .env.")
    return key


def _headers(use_authorization: bool = True) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if use_authorization:
        headers["Authorization"] = f"Bearer {_api_key()}"
    return headers


def _auth_task() -> dict[str, str]:
    return {"taskType": "authentication", "apiKey": _api_key()}


def _reference_images_payload(reference_image_paths: list[str | Path] | None) -> list[str]:
    payload: list[str] = []
    for raw_path in (reference_image_paths or [])[:4]:
        path = Path(raw_path)
        if not path.exists() or not path.is_file():
            continue
        mime = mimetypes.guess_type(path.name)[0] or "image/png"
        data = base64.b64encode(path.read_bytes()).decode("ascii")
        payload.append(f"data:{mime};base64,{data}")
    return payload


def _build_payload(
    prompt: str,
    model: str,
    width: int,
    height: int,
    steps: int,
    reference_image_paths: list[str | Path] | None = None,
) -> list[dict]:
    task = {
        "taskType": "imageInference",
        "taskUUID": str(uuid.uuid4()),
        "model": model,
        "positivePrompt": prompt,
        "width": int(width),
        "height": int(height),
        "numberResults": 1,
        "outputFormat": "PNG",
        "outputType": "URL",
        "deliveryMethod": "sync",
    }
    if is_gpt_image_2_model(model):
        task["providerSettings"] = {
            "openai": {
                "quality": GPT_IMAGE_2_QUALITY,
            }
        }
    else:
        task["steps"] = int(steps)
    references = _reference_images_payload(reference_image_paths)
    if references:
        task["inputs"] = {"referenceImages": references}
    return [task]


def _request_payload(payload: list[dict], use_payload_auth: bool) -> list[dict]:
    if use_payload_auth:
        return [_auth_task(), *payload]
    return payload


def _post_runware(payload: list[dict], timeout: int, use_payload_auth: bool = False) -> requests.Response:
    return _SESSION.post(
        RUNWARE_ENDPOINT,
        headers=_headers(use_authorization=not use_payload_auth),
        json=_request_payload(payload, use_payload_auth=use_payload_auth),
        timeout=timeout,
    )


def _errors_from_response(data: Any) -> list[dict]:
    if isinstance(data, dict):
        errors = data.get("errors")
        if isinstance(errors, list):
            return [e for e in errors if isinstance(e, dict)]
        if data.get("error"):
            return [{"message": str(data.get("error"))}]
    return []


def _is_auth_api_key_error(data: Any) -> bool:
    for err in _errors_from_response(data):
        if str(err.get("parameter", "")).lower() == "apikey":
            return True
        if str(err.get("taskType", "")).lower() == "authentication":
            return True
    return False


def _format_runware_error(data: Any, status_code: int | None = None) -> str:
    prefix = f"HTTP {status_code}: " if status_code and status_code >= 400 else ""
    errors = _errors_from_response(data)
    if not errors:
        return prefix + str(data)
    parts = []
    for err in errors:
        code = str(err.get("code") or "error")
        message = str(err.get("message") or err)
        parameter = str(err.get("parameter") or "")
        task_type = str(err.get("taskType") or "")
        extra = []
        if parameter:
            extra.append(f"parameter={parameter}")
        if task_type:
            extra.append(f"taskType={task_type}")
        parts.append(f"{code}: {message}" + (f" ({', '.join(extra)})" if extra else ""))
    return prefix + "; ".join(parts)



def _is_transient_runware_failure(
    exc: Exception,
    status_code: int | None = None,
    data: Any = None,
) -> bool:
    if isinstance(exc, requests.exceptions.RequestException):
        return True
    if status_code in _TRANSIENT_STATUS:
        return True
    texts = [str(exc)]
    for error in _errors_from_response(data):
        texts.extend([str(error.get("code") or ""), str(error.get("message") or "")])
    joined = " ".join(texts).lower()
    return any(token in joined for token in (
        "servererror", "server error", "temporar", "timeout", "timed out",
        "rate limit", "too many requests", "unavailable", "overload",
        "connection", "gateway", "internal error", "blank black image",
    ))

def _first_data_item(data: dict, task_type: str) -> dict | None:
    for item in data.get("data") or []:
        if isinstance(item, dict) and item.get("taskType") == task_type:
            return item
    # Backward-compatible fallback for responses that omit taskType.
    for item in data.get("data") or []:
        if isinstance(item, dict):
            return item
    return None


def list_image_models(search: str = "", limit_per_query: int = 80) -> list[dict[str, str]]:
    """Fetch public base checkpoint models from Runware Model Search.

    The Runware catalog is huge, so the app asks for useful image-generation
    model families instead of trying to place hundreds of thousands of models
    into one frozen dropdown.
    """
    queries = [search.strip()] if search.strip() else [
        "flux", "qwen image", "sdxl", "realistic", "cinematic", "anime", "illustration", "photorealistic"
    ]
    seen: dict[str, dict] = {}
    auth_modes = [False, True]  # header auth first, payload auth fallback
    for q in queries:
        payload = [{
            "taskType": "modelSearch",
            "taskUUID": str(uuid.uuid4()),
            "search": q,
            "category": "checkpoint",
            "type": "base",
            "visibility": "public",
            "offset": 0,
            "limit": max(1, min(100, int(limit_per_query))),
        }]
        for use_payload_auth in auth_modes:
            try:
                r = _post_runware(payload, timeout=90, use_payload_auth=use_payload_auth)
                try:
                    data = r.json()
                except Exception:
                    r.raise_for_status()
                    continue
                if r.status_code >= 400 or data.get("errors") or data.get("error"):
                    # If Runware has a transient auth-layer issue, try the other
                    # documented authentication method before giving up.
                    if _is_auth_api_key_error(data) and not use_payload_auth:
                        continue
                    break
                task = _first_data_item(data, "modelSearch")
                if not task:
                    break
                for item in task.get("results") or []:
                    air = str(item.get("air") or "").strip()
                    if not air:
                        continue
                    # Keep primary/base image models first when duplicates appear.
                    if air not in seen or item.get("primary"):
                        seen[air] = item
                break
            except Exception:
                continue
    models = list(seen.values())
    models.sort(key=lambda m: ("flux" not in str(m.get("name", "")).lower(), str(m.get("name", "")).lower()))
    if not models:
        return RUNWARE_FALLBACK_MODELS
    # Always put the known-good default on top.
    merged: dict[str, dict] = {m["air"]: m for m in RUNWARE_FALLBACK_MODELS}
    for m in models:
        merged[str(m.get("air"))] = m
    return list(merged.values())


def generate_image(
    prompt: str,
    out_path: Path,
    model: str = "runware:400@2",
    width: int = 1920,
    height: int = 1080,
    steps: int = 4,
    progress: Callable[[str], None] | None = None,
    retries: int = 3,
    reference_image_paths: list[str | Path] | None = None,
) -> Path:
    request_width, request_height = runware_safe_size(width, height)
    if progress and (request_width != int(width) or request_height != int(height)):
        progress(
            f"Adjusted Runware image size from {int(width)}x{int(height)} "
            f"to {request_width}x{request_height} to satisfy Runware's 16-pixel dimension rule."
        )

    last_error: Exception | None = None
    max_attempts = max(1, int(retries) + 1)
    for attempt in range(max_attempts):
        payload = _build_payload(
            prompt, model, request_width, request_height, steps,
            reference_image_paths=reference_image_paths,
        )
        retry_generation = False
        for use_payload_auth in (False, True):
            response: requests.Response | None = None
            data: Any = None
            try:
                if progress:
                    auth_label = "payload auth" if use_payload_auth else "header auth"
                    ref_note = f", {len(reference_image_paths or [])} reference image(s)" if reference_image_paths else ""
                    quality_note = ", GPT Image 2 quality=low" if is_gpt_image_2_model(model) else ""
                    progress(
                        f"Runware image request: {out_path.name} "
                        f"(attempt {attempt + 1}/{max_attempts}, {auth_label}{ref_note}{quality_note})"
                    )
                response = _post_runware(payload, timeout=420, use_payload_auth=use_payload_auth)
                try:
                    data = response.json()
                except Exception as exc:
                    if response.status_code in _TRANSIENT_STATUS:
                        raise RunwareError(f"Temporary Runware non-JSON response: HTTP {response.status_code}") from exc
                    response.raise_for_status()
                    raise RunwareError(f"Runware returned a non-JSON response: HTTP {response.status_code}") from exc

                if response.status_code >= 400 or (isinstance(data, dict) and (data.get("errors") or data.get("error"))):
                    message = _format_runware_error(data, response.status_code)
                    error = RunwareError(message)
                    # Only authentication-specific errors should switch to the
                    # alternate documented auth format. Permanent model/prompt
                    # errors must not be retried as paid requests.
                    if not use_payload_auth and _is_auth_api_key_error(data):
                        last_error = error
                        continue
                    if _is_transient_runware_failure(error, response.status_code, data):
                        last_error = error
                        retry_generation = True
                        break
                    raise error

                item = _first_data_item(data, "imageInference") if isinstance(data, dict) else None
                if not item:
                    raise RunwareError(f"Runware returned no image data: {data}")
                url = item.get("imageURL") or item.get("imageUrl") or item.get("url")
                if not url:
                    raise RunwareError(f"Runware response did not contain imageURL: {item}")
                # CDN/network retries happen inside _download and do not create a
                # second image-generation task.
                return _download(str(url), out_path)
            except RunwareDownloadError:
                # The image-generation task already succeeded. Never submit a
                # duplicate paid task merely because its CDN download failed.
                raise
            except RunwareError as exc:
                last_error = exc
                if not use_payload_auth and data is not None and _is_auth_api_key_error(data):
                    continue
                if _is_transient_runware_failure(
                    exc,
                    response.status_code if response is not None else None,
                    data,
                ):
                    retry_generation = True
                    break
                raise
            except requests.exceptions.RequestException as exc:
                last_error = exc
                retry_generation = True
                break

        if not retry_generation:
            break
        if attempt + 1 < max_attempts:
            wait = min(20.0, 2.5 * (2 ** attempt)) + random.uniform(0.0, 0.8)
            if progress:
                progress(f"Temporary Runware failure; retrying in {wait:.1f}s.")
            time.sleep(wait)

    hint = (
        " If your RUNWARE_API_KEY was pasted with the word 'Bearer', this version strips it automatically. "
        "Temporary service errors can be resumed from Load Project without corrupting completed images."
    )
    raise RunwareError(f"Runware image generation failed after safe retries: {last_error}.{hint}")

