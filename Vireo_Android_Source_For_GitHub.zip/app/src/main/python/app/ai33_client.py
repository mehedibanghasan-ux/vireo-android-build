from __future__ import annotations

from pathlib import Path
import os
import random
import re
import tempfile
import time
from typing import Any, Callable

import requests

from .config import get_api_key


class AI33Error(RuntimeError):
    pass


_SESSION = requests.Session()
_TRANSIENT_STATUS = {408, 409, 425, 429, 500, 502, 503, 504, 520, 522, 524}


def _headers() -> dict[str, str]:
    key = get_api_key("AI33_API_KEY")
    if not key:
        raise AI33Error("AI33_API_KEY is missing. Add it in Settings or .env.")
    return {"xi-api-key": key}


def _find_audio_url(obj: Any) -> str | None:
    if isinstance(obj, str):
        if re.search(r"https?://.*\.(mp3|wav|m4a|aac|ogg|flac)(\?|$)", obj, re.I):
            return obj
        return None
    if isinstance(obj, dict):
        for key in ("audio_url", "audioUrl", "url", "file_url", "output_url", "download_url"):
            found = _find_audio_url(obj.get(key))
            if found:
                return found
        for val in obj.values():
            found = _find_audio_url(val)
            if found:
                return found
    if isinstance(obj, list):
        for val in obj:
            found = _find_audio_url(val)
            if found:
                return found
    return None


def _retry_after_seconds(response: requests.Response | None) -> float | None:
    if response is None:
        return None
    raw = (response.headers or {}).get("Retry-After")
    if not raw:
        return None
    try:
        return max(0.0, min(120.0, float(raw)))
    except Exception:
        return None


def list_voices(provider: str = "elevenlabs", language: str = "English", page_size: int = 100) -> list[dict[str, Any]]:
    voices: list[dict[str, Any]] = []
    page = 1
    while True:
        response = _SESSION.get(
            "https://api.ai33.pro/v3/voices",
            headers=_headers(),
            params={"provider": provider, "language": language, "page": page, "page_size": page_size},
            timeout=(12, 60),
        )
        response.raise_for_status()
        data = response.json()
        batch = data.get("data") or []
        voices.extend(batch)
        pagination = data.get("pagination") or {}
        total_pages = int(pagination.get("total_pages") or pagination.get("totalPages") or page)
        if page >= total_pages or not batch:
            break
        page += 1
    return voices


def submit_tts(text: str, voice_id: str, speed: float = 1.0, with_transcript: bool = False) -> str:
    if not voice_id:
        raise AI33Error("No AI33 voice selected. Fetch voices in Settings/Voice section, then select one.")
    files = {
        "text": (None, text),
        "voice_id": (None, voice_id),
        "speed": (None, str(speed)),
        "with_transcript": (None, "true" if with_transcript else "false"),
    }
    # A connect timeout happens before an AI33 TTS request is accepted by the
    # server. Retry only connection-establishment failures here. We deliberately
    # do not retry read timeouts or unknown POST outcomes because a paid TTS task
    # may already have been created and Update 19 task persistence must remain
    # duplicate-safe.
    response: requests.Response | None = None
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            response = _SESSION.post(
                "https://api.ai33.pro/v3/text-to-speech",
                headers=_headers(),
                files=files,
                timeout=(20, 90),
            )
            break
        except requests.exceptions.ConnectTimeout as exc:
            last_error = exc
            if attempt == 2:
                raise AI33Error(f"AI33 TTS connection failed after retries: {exc}") from exc
            time.sleep(2 ** attempt)
        except requests.exceptions.ConnectionError as exc:
            last_error = exc
            if attempt == 2:
                raise AI33Error(f"AI33 TTS connection failed after retries: {exc}") from exc
            time.sleep(2 ** attempt)
    if response is None:
        raise AI33Error(f"AI33 TTS connection failed: {last_error}")
    try:
        data = response.json()
    except Exception:
        data = {"raw": response.text}
    if response.status_code >= 400 or not data.get("success", False):
        raise AI33Error(f"AI33 TTS submission failed: {data}")
    task_id = data.get("task_id")
    if not task_id:
        raise AI33Error(f"AI33 did not return task_id: {data}")
    return str(task_id)


def poll_task(
    task_id: str,
    timeout_s: int = 1800,
    progress: Callable[[str], None] | None = None,
    session: requests.Session | None = None,
) -> dict[str, Any]:
    """Poll one existing task; temporary failures never submit a duplicate task."""
    http = session or _SESSION
    deadline = time.monotonic() + timeout_s
    consecutive_errors = 0
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        response: requests.Response | None = None
        try:
            response = http.get(
                f"https://api.ai33.pro/v1/task/{task_id}",
                headers={**_headers(), "Content-Type": "application/json"},
                timeout=(12, 45),
            )
            if response.status_code in _TRANSIENT_STATUS:
                raise AI33Error(f"Temporary AI33 polling response {response.status_code}: {response.text[:300]}")
            response.raise_for_status()
            data = response.json()
            consecutive_errors = 0
            status = str(data.get("status", "")).lower()
            pct = data.get("progress")
            if progress:
                progress(f"AI33 task {task_id}: {status} {pct if pct is not None else ''}")
            if status in {"done", "completed", "success"}:
                return data
            if status in {"failed", "error", "cancelled", "canceled"}:
                raise AI33Error(f"AI33 task failed: {data.get('error_message') or data}")
            time.sleep(4)
        except AI33Error as exc:
            if "AI33 task failed" in str(exc):
                raise
            last_error = exc
            consecutive_errors += 1
            wait = _retry_after_seconds(response)
            if wait is None:
                wait = min(60.0, 3.0 * (2 ** min(consecutive_errors - 1, 5))) + random.uniform(0, 2)
            if progress:
                progress(f"Temporary AI33 polling issue; retrying in {wait:.0f}s ({exc})")
            time.sleep(wait)
        except requests.exceptions.RequestException as exc:
            last_error = exc
            consecutive_errors += 1
            wait = min(60.0, 3.0 * (2 ** min(consecutive_errors - 1, 5))) + random.uniform(0, 2)
            if progress:
                progress(f"Temporary AI33 network issue; retrying in {wait:.0f}s ({type(exc).__name__})")
            time.sleep(wait)
        except ValueError as exc:
            last_error = exc
            consecutive_errors += 1
            wait = min(45.0, 3.0 * (2 ** min(consecutive_errors - 1, 4)))
            if progress:
                progress(f"AI33 returned a non-JSON poll response; retrying in {wait:.0f}s")
            time.sleep(wait)
    raise AI33Error(f"AI33 task timed out after {timeout_s}s: {task_id}. Last temporary error: {last_error}")


def _download_audio_atomic(
    audio_url: str,
    out_path: Path,
    retries: int = 5,
    progress: Callable[[str], None] | None = None,
) -> Path:
    """Download one already-completed AI33 task result safely.

    CDN/network failures are retried against the same URL only. This function
    never submits or re-submits a paid TTS task.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)
    attempts = max(1, int(retries))
    last_error: Exception | None = None

    for attempt in range(attempts):
        fd, temp_name = tempfile.mkstemp(
            prefix=f".{out_path.name}.",
            suffix=f".tmp{out_path.suffix}",
            dir=str(out_path.parent),
        )
        os.close(fd)
        temp_path = Path(temp_name)
        response: requests.Response | None = None
        try:
            with _SESSION.get(audio_url, stream=True, timeout=(20, 300)) as response:
                if response.status_code in _TRANSIENT_STATUS:
                    raise AI33Error(
                        f"Temporary AI33 audio CDN response {response.status_code}: "
                        f"{response.text[:300]}"
                    )
                response.raise_for_status()
                with temp_path.open("wb") as handle:
                    for chunk in response.iter_content(chunk_size=1024 * 256):
                        if chunk:
                            handle.write(chunk)
                    handle.flush()
                    os.fsync(handle.fileno())

            if not temp_path.exists() or temp_path.stat().st_size < 256:
                raise AI33Error("AI33 returned an empty or incomplete audio file.")

            os.replace(temp_path, out_path)
            return out_path
        except requests.exceptions.RequestException as exc:
            last_error = exc
            status = getattr(getattr(exc, "response", None), "status_code", None)
            if status is not None and status not in _TRANSIENT_STATUS:
                raise AI33Error(f"AI33 audio download failed with HTTP {status}.") from exc
        except AI33Error as exc:
            last_error = exc
        finally:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass

        if attempt + 1 >= attempts:
            break

        wait_s = _retry_after_seconds(response)
        if wait_s is None:
            wait_s = min(30.0, 2.0 * (2 ** min(attempt, 4))) + random.uniform(0.0, 1.0)
        if progress:
            progress(
                f"Temporary AI33 audio download issue; retrying the same completed task file "
                f"in {wait_s:.0f}s ({attempt + 2}/{attempts})."
            )
        time.sleep(wait_s)

    raise AI33Error(
        f"AI33 audio download failed after {attempts} attempts without resubmitting the TTS task: {last_error}"
    )


def generate_tts_audio(
    text: str,
    out_path: Path,
    voice_id: str,
    speed: float = 1.0,
    progress: Callable[[str], None] | None = None,
    existing_task_id: str | None = None,
    on_task_submitted: Callable[[str], None] | None = None,
) -> Path:
    task_id = str(existing_task_id or "").strip()
    if task_id:
        if progress:
            progress(f"Resuming saved AI33 task {task_id} without submitting a duplicate request.")
    else:
        task_id = submit_tts(text, voice_id=voice_id, speed=speed, with_transcript=False)
        if on_task_submitted:
            on_task_submitted(task_id)
    task = poll_task(task_id, progress=progress)
    audio_url = _find_audio_url(task)
    if not audio_url:
        raise AI33Error(f"Could not find final audio URL in AI33 task response: {task}")
    return _download_audio_atomic(audio_url, Path(out_path), progress=progress)
