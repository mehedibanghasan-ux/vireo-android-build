from __future__ import annotations

from difflib import SequenceMatcher
from pathlib import Path
import re
import unicodedata
from typing import Any


def srt_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    total_ms = int(round(seconds * 1000.0))
    h, remainder = divmod(total_ms, 3_600_000)
    m, remainder = divmod(remainder, 60_000)
    s, ms = divmod(remainder, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def _caption_text(words: list[dict], all_caps: bool = False) -> str:
    text = " ".join(str(x.get("word", "")).strip() for x in words).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    return text.upper() if all_caps else text


def _display_tokens(text: str) -> list[str]:
    """Split known script text into display tokens without inventing words."""
    return [token for token in re.findall(r"\S+", (text or "").replace("\n", " ")) if token.strip()]


def _normalise_token(token: str) -> str:
    value = unicodedata.normalize("NFKC", str(token or "")).lower()
    value = value.replace("’", "'").replace("`", "'")
    value = re.sub(r"[^\w']+", "", value, flags=re.UNICODE)
    return value.strip("_")


def _safe_word(word: dict[str, Any], duration: float) -> dict[str, Any] | None:
    text = str(word.get("word", "") or "").strip()
    norm = _normalise_token(text)
    if not text or not norm:
        return None
    try:
        start = max(0.0, min(float(duration), float(word.get("start", 0.0))))
        end = max(start, min(float(duration), float(word.get("end", start))))
    except Exception:
        return None
    return {"word": text, "norm": norm, "start": start, "end": end}


def _uniform_centers(count: int, start: float, end: float) -> list[float]:
    if count <= 0:
        return []
    start = max(0.0, float(start))
    end = max(start + 0.001, float(end))
    step = (end - start) / count
    return [start + (index + 0.5) * step for index in range(count)]


def _centers_to_word_times(tokens: list[str], centers: list[float], duration: float) -> list[dict[str, float | str]]:
    """Convert timing anchors to monotonic word intervals bounded by one scene."""
    if not tokens:
        return []
    duration = max(0.05, float(duration))
    count = len(tokens)
    if len(centers) != count:
        centers = _uniform_centers(count, 0.0, duration)

    # Keep a tiny but always feasible separation between anchors. The previous
    # implementation could make the final word end after the scene duration for
    # very short clips with many words.
    minimum_step = min(0.03, duration / max(2.0, count * 2.0))
    lower = minimum_step / 2.0
    upper = max(lower, duration - minimum_step / 2.0)
    cleaned_centers: list[float] = []
    for index, raw_value in enumerate(centers):
        remaining = count - index - 1
        min_value = lower if not cleaned_centers else cleaned_centers[-1] + minimum_step
        max_value = upper - remaining * minimum_step
        if max_value < min_value:
            # Uniform fallback is guaranteed to fit inside the scene.
            cleaned_centers = _uniform_centers(count, 0.0, duration)
            break
        cleaned_centers.append(max(min_value, min(max_value, float(raw_value))))

    boundaries: list[float] = [0.0]
    for left, right in zip(cleaned_centers, cleaned_centers[1:]):
        midpoint = (left + right) / 2.0
        boundaries.append(max(boundaries[-1], min(duration, midpoint)))
    boundaries.append(duration)

    aligned: list[dict[str, float | str]] = []
    for index, token in enumerate(tokens):
        start = max(0.0, min(duration, boundaries[index]))
        end = max(start, min(duration, boundaries[index + 1]))
        # With non-empty audio and feasible uniform boundaries end should be
        # greater than start. Keep the timestamp legal without crossing scenes.
        if end <= start:
            end = min(duration, start + max(0.001, duration / max(1000.0, count * 10.0)))
        aligned.append({"word": token, "start": start, "end": end})
    return aligned

def align_transcription_to_script(
    expected_text: str,
    transcribed_words: list[dict[str, Any]],
    audio_duration: float,
) -> tuple[list[dict[str, float | str]], dict[str, Any]]:
    """Use Whisper only as timing anchors while displaying the exact scene script.

    Matching script words keep Whisper timing. Missing words are interpolated
    between surrounding matched anchors. Unexpected Whisper words are ignored and
    never advance the subtitle clock, so a hallucination cannot create a gap or
    push captions into the next scene.
    """
    duration = max(0.05, float(audio_duration or 0.0))
    expected_tokens_all = _display_tokens(expected_text)
    filtered_expected = [
        (token, norm)
        for token in expected_tokens_all
        if (norm := _normalise_token(token))
    ]
    expected_tokens = [token for token, _ in filtered_expected]
    expected_norm = [norm for _, norm in filtered_expected]

    observed = [
        safe
        for item in (transcribed_words or [])
        if (safe := _safe_word(item, duration)) is not None
    ]
    observed.sort(key=lambda item: (float(item["start"]), float(item["end"])))
    observed_norm = [str(item["norm"]) for item in observed]

    if not expected_tokens:
        return [], {
            "similarity": 1.0,
            "expected_count": 0,
            "observed_count": len(observed),
            "matched_count": 0,
            "missing_script_count": 0,
            "missing_script_words": [],
            "unexpected_words": [str(item["word"]) for item in observed],
            "dropped_unexpected_count": len(observed),
            "suspicious_long_unexpected": [],
            "max_observed_gap": 0.0,
            "used_script_alignment": True,
        }

    if not observed:
        aligned = _centers_to_word_times(
            expected_tokens,
            _uniform_centers(len(expected_tokens), 0.0, duration),
            duration,
        )
        return aligned, {
            "similarity": 0.0,
            "expected_count": len(expected_tokens),
            "observed_count": 0,
            "matched_count": 0,
            "missing_script_count": len(expected_tokens),
            "missing_script_words": expected_tokens,
            "unexpected_words": [],
            "dropped_unexpected_count": 0,
            "suspicious_long_unexpected": [],
            "max_observed_gap": 0.0,
            "used_script_alignment": True,
        }

    matcher = SequenceMatcher(None, expected_norm, observed_norm, autojunk=False)
    expected_to_observed: dict[int, int] = {}
    used_observed: set[int] = set()
    for block in matcher.get_matching_blocks():
        for offset in range(block.size):
            expected_index = block.a + offset
            observed_index = block.b + offset
            expected_to_observed[expected_index] = observed_index
            used_observed.add(observed_index)

    centers: list[float | None] = [None] * len(expected_tokens)
    for expected_index, observed_index in expected_to_observed.items():
        source = observed[observed_index]
        centers[expected_index] = (float(source["start"]) + float(source["end"])) / 2.0

    matched_indexes = sorted(expected_to_observed)
    if not matched_indexes:
        centers = _uniform_centers(len(expected_tokens), 0.0, duration)
    else:
        # Fill each unmatched range between reliable anchors.
        first = matched_indexes[0]
        if first > 0:
            next_center = float(centers[first])
            fill = _uniform_centers(first, 0.0, max(0.001, next_center))
            centers[:first] = fill

        for left_index, right_index in zip(matched_indexes, matched_indexes[1:]):
            missing_count = right_index - left_index - 1
            if missing_count <= 0:
                continue
            left_center = float(centers[left_index])
            right_center = float(centers[right_index])
            fill = _uniform_centers(missing_count, left_center, max(left_center + 0.001, right_center))
            centers[left_index + 1:right_index] = fill

        last = matched_indexes[-1]
        if last < len(expected_tokens) - 1:
            count = len(expected_tokens) - last - 1
            previous_center = float(centers[last])
            fill = _uniform_centers(count, previous_center, duration)
            centers[last + 1:] = fill

    numeric_centers = [float(value) for value in centers]
    aligned = _centers_to_word_times(expected_tokens, numeric_centers, duration)

    unexpected_words = [
        str(item["word"])
        for index, item in enumerate(observed)
        if index not in used_observed
    ]
    missing_indexes = [index for index in range(len(expected_tokens)) if index not in expected_to_observed]
    observed_gaps = [
        max(0.0, float(current["start"]) - float(previous["end"]))
        for previous, current in zip(observed, observed[1:])
    ]
    report = {
        "similarity": round(float(matcher.ratio()), 4),
        "expected_count": len(expected_tokens),
        "observed_count": len(observed),
        "matched_count": len(expected_to_observed),
        "missing_script_count": len(missing_indexes),
        "missing_script_words": [expected_tokens[index] for index in missing_indexes],
        "unexpected_words": unexpected_words,
        "dropped_unexpected_count": len(unexpected_words),
        "suspicious_long_unexpected": [word for word in unexpected_words if len(_normalise_token(word)) >= 10],
        "max_observed_gap": round(max(observed_gaps, default=0.0), 4),
        "used_script_alignment": True,
    }
    return aligned, report


def transcription_needs_audio_retry(report: dict[str, Any]) -> bool:
    """Flag likely TTS corruption while avoiding retries for punctuation-only ASR differences."""
    expected = max(1, int(report.get("expected_count") or 0))
    matched = int(report.get("matched_count") or 0)
    observed = int(report.get("observed_count") or 0)
    similarity = float(report.get("similarity") or 0.0)
    long_unexpected = list(report.get("suspicious_long_unexpected") or [])
    unexpected_count = int(report.get("dropped_unexpected_count") or 0)
    missing_count = int(report.get("missing_script_count") or max(0, expected - matched))
    max_gap = float(report.get("max_observed_gap") or 0.0)
    internal_silence = float(report.get("max_internal_silence") or 0.0)
    match_ratio = matched / expected

    if observed == 0:
        return True
    if similarity < 0.72 or match_ratio < 0.65:
        return True
    # A long inserted word can be a real TTS corruption (the failure reported in
    # Update 14), not merely punctuation drift. Retry once; the exact-script
    # alignment still prevents the unexpected word from ever reaching subtitles.
    if long_unexpected:
        return True
    if unexpected_count >= max(4, round(expected * 0.25)) and missing_count > 0:
        return True
    if missing_count >= max(2, round(expected * 0.20)):
        return True
    if missing_count > 0 and max_gap >= 0.75:
        return True
    if internal_silence >= 0.90:
        return True
    return False


def transcription_quality_score(report: dict[str, Any]) -> float:
    expected = max(1, int(report.get("expected_count") or 0))
    matched = int(report.get("matched_count") or 0)
    similarity = float(report.get("similarity") or 0.0)
    unexpected = int(report.get("dropped_unexpected_count") or 0)
    missing = int(report.get("missing_script_count") or max(0, expected - matched))
    long_unexpected = len(report.get("suspicious_long_unexpected") or [])
    max_gap = float(report.get("max_observed_gap") or 0.0)
    internal_silence = float(report.get("max_internal_silence") or 0.0)
    return (
        similarity
        + (matched / expected)
        - unexpected * 0.025
        - missing * 0.035
        - long_unexpected * 0.08
        - max(0.0, max_gap - 0.60) * 0.18
        - max(0.0, internal_silence - 0.60) * 0.25
    )


def _append_caption_entries(
    entries: list[str],
    words: list[dict],
    words_per_caption: int,
    all_caps: bool,
    starting_index: int,
) -> int:
    chunk_size = max(1, int(words_per_caption))
    index = starting_index
    for start_index in range(0, len(words), chunk_size):
        chunk = [item for item in words[start_index:start_index + chunk_size] if str(item.get("word", "")).strip()]
        if not chunk:
            continue
        start = float(chunk[0].get("start", 0.0))
        end = float(chunk[-1].get("end", start + 0.2))
        text = _caption_text(chunk, all_caps=all_caps)
        entries.append(f"{index}\n{srt_time(start)} --> {srt_time(max(end, start + 0.05))}\n{text}\n")
        index += 1
    return index


def words_to_srt(words: list[dict], out_path: Path, words_per_caption: int = 3, all_caps: bool = False) -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    entries: list[str] = []
    _append_caption_entries(entries, words, words_per_caption, all_caps, 1)
    out_path.write_text("\n".join(entries), encoding="utf-8")
    return out_path


def scene_words_to_srt(
    scene_word_groups: list[list[dict]],
    out_path: Path,
    words_per_caption: int = 3,
    all_caps: bool = False,
) -> Path:
    """Write captions without ever combining words from two different scenes."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    entries: list[str] = []
    index = 1
    for group in scene_word_groups:
        index = _append_caption_entries(entries, group, words_per_caption, all_caps, index)
    out_path.write_text("\n".join(entries), encoding="utf-8")
    return out_path


def timed_script_to_srt(
    scenes: list[str],
    durations: list[float],
    out_path: Path,
    words_per_caption: int = 3,
    all_caps: bool = False,
) -> Path:
    groups: list[list[dict]] = []
    offset = 0.0
    for scene, duration in zip(scenes, durations):
        tokens = _display_tokens(scene)
        local = _centers_to_word_times(tokens, _uniform_centers(len(tokens), 0.0, duration), duration)
        groups.append([
            {"word": item["word"], "start": float(item["start"]) + offset, "end": float(item["end"]) + offset}
            for item in local
        ])
        offset += float(duration)
    return scene_words_to_srt(groups, out_path, words_per_caption, all_caps=all_caps)


def _hex_to_ass_primary(color: str) -> str:
    color = (color or "#FFFFFF").strip()
    named = {
        "white": "#FFFFFF",
        "yellow": "#FFFF00",
        "black": "#000000",
        "red": "#FF0000",
        "green": "#00FF00",
        "blue": "#0000FF",
    }
    color = named.get(color.lower(), color)
    if color.startswith("#"):
        color = color[1:]
    if len(color) != 6:
        color = "FFFFFF"
    try:
        r = int(color[0:2], 16)
        g = int(color[2:4], 16)
        b = int(color[4:6], 16)
    except Exception:
        r, g, b = 255, 255, 255
    return f"&H00{b:02X}{g:02X}{r:02X}"


def ass_style(font_name: str, font_size: int, position: str = "bottom", outline_size: float = 2.0, color: str = "#FFFFFF") -> str:
    alignment = {"bottom": 2, "center": 5, "top": 8}.get(position.lower(), 2)
    margin_v = 16 if alignment == 2 else 40
    outline = max(0.0, min(12.0, float(outline_size)))
    return (
        f"FontName={font_name},FontSize={font_size},PrimaryColour={_hex_to_ass_primary(color)},"
        f"OutlineColour=&H00000000,BorderStyle=1,Outline={outline:.1f},Shadow=0,"
        f"Alignment={alignment},MarginV={margin_v}"
    )
