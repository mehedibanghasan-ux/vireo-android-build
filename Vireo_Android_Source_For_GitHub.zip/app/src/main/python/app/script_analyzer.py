from __future__ import annotations

from dataclasses import dataclass
import math
import re

WORD_RE = re.compile(r"\b[\w’'-]+\b", re.UNICODE)
SENTENCE_RE = re.compile(r"[^.!?…]+(?:[.!?…]+|$)", re.UNICODE)
DIALOGUE_RE = re.compile(r"(^\s*[-–—]\s+|[\"“”].+?[\"“”]|\b[A-Z][A-Za-z0-9_ ]{0,24}:)", re.MULTILINE)


@dataclass(frozen=True)
class ContentStats:
    words: int
    paragraphs: int
    sentences: int
    recommended_scenes: int
    max_allowed_scenes: int
    breakpoints: int
    dialogue: int


def count_words(text: str) -> int:
    return len(WORD_RE.findall(text))


def split_paragraphs(text: str) -> list[str]:
    paras = [p.strip() for p in re.split(r"\n\s*\n|\r\n\s*\r\n", text.strip()) if p.strip()]
    if len(paras) <= 1:
        # The reference app appears to treat line breaks as paragraph boundaries for pasted scripts.
        paras = [p.strip() for p in text.splitlines() if p.strip()]
    return paras


def split_sentences(text: str) -> list[str]:
    cleaned = re.sub(r"\s+", " ", text.strip())
    if not cleaned:
        return []
    pieces = [m.group(0).strip() for m in SENTENCE_RE.finditer(cleaned)]
    return [p for p in pieces if p]


def analyze_script(text: str) -> ContentStats:
    text = text or ""
    words = count_words(text)
    paragraphs = len(split_paragraphs(text))
    sentences = max(0, len(split_sentences(text)))
    breakpoints = len(re.findall(r"[.!?…]", text))
    dialogue = len(DIALOGUE_RE.findall(text))

    # This mirrors the behavior visible in your screenshot: one recommended scene per sentence.
    recommended = max(1, sentences) if words else 0
    # Allow about 15% more than recommended, with a practical minimum buffer.
    max_allowed = 0 if recommended == 0 else max(recommended + 5, recommended + round(recommended * 0.15))

    return ContentStats(
        words=words,
        paragraphs=paragraphs,
        sentences=sentences,
        recommended_scenes=recommended,
        max_allowed_scenes=max_allowed,
        breakpoints=breakpoints,
        dialogue=dialogue,
    )


def stats_text(stats: ContentStats) -> str:
    if stats.words == 0:
        return "Content Stats: 0 words . 0 paragraphs . 0 sentences\nRecommended: 0 scenes . Max allowed: 0 scenes . Breakpoints: 0 periods, 0 dialogue"
    return (
        f"Content Stats: {stats.words} words . {stats.paragraphs} paragraphs . {stats.sentences} sentences\n"
        f"Recommended: {stats.recommended_scenes} scenes . Max allowed: {stats.max_allowed_scenes} scenes . "
        f"Breakpoints: {stats.breakpoints} periods, {stats.dialogue} dialogue"
    )
