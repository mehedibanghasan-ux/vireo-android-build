"""Vireo Video Studio core package."""
