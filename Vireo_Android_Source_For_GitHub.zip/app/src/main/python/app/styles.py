from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from .config import STYLE_PREVIEWS_DIR, REFERENCE_STYLES_DIR

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}

WARM_HAND_DRAWN_FINANCIAL_STORYBOOK_STYLE = (
    "Warm hand-drawn financial storybook illustration with a mature editorial tone. "
    "Use a warm cream or aged parchment paper base with visible paper grain, graphite construction marks, imperfect ink outlines, "
    "light cross-hatching, and restrained watercolor or colored-pencil shading. Use a quiet, cohesive palette of muted navy, cream, "
    "mustard yellow, faded red, grey-blue, dusty green, charcoal, and warm natural brown. When people appear, depict them as dignified "
    "hybrid stick-figure characters with expressive hand-drawn illustrated heads and simple age-appropriate clothing silhouettes, paired "
    "with thin black stick-like limbs and simplified rounded hands. Keep emotions readable but restrained, settings intimate and uncluttered, "
    "and financial or household objects clear at a glance. Mature, warm, trustworthy, slightly nostalgic, handmade rather than digitally perfect. "
    "No photorealism, no glossy 3D rendering, no anime, no neon colors, no childish doodles, no preschool cuteness, no random lettering, "
    "no captions, no text, no logo, no watermark."
)

BASE_STYLE_PROMPTS = {
    "warm hand-drawn financial storybook": WARM_HAND_DRAWN_FINANCIAL_STORYBOOK_STYLE,
    "cinematic": "cinematic film still, naturalistic lighting, strong composition, subtle film grain, shallow depth of field, no text, no watermark",
    "photorealistic": "photorealistic, realistic human-scale camera, natural detail, believable light and shadow, no text, no watermark",
    "hyperrealistic": "hyperrealistic, high micro-detail, crisp textures, precise lighting, no text, no watermark",
    "anime": "anime illustration, clean linework, expressive lighting, cinematic color, no text, no watermark",
    "film noir": "black and white film noir, hard shadows, moody contrast, vintage lensing, no text, no watermark",
    "watercolor": "soft watercolor painting, paper texture, gentle washes, elegant composition, no text, no watermark",
    "storybook cinematic": "warm cinematic storybook illustration, gentle hand-painted texture, expressive but family-friendly characters, golden-hour lighting, rounded forms, no text, no watermark",
    "premium 3d animation": "premium 3D animated feature look, soft global illumination, charming character-friendly shapes, polished materials, colorful but tasteful palette, no text, no watermark",
    "modern youtube documentary": "trendy YouTube documentary visual style, clean cinematic realism, warm contrast, dramatic but natural lighting, tasteful depth of field, editorial framing, no text, no watermark",
    "moody editorial realism": "moody editorial realism, soft shadows, restrained color grade, natural textures, documentary lensing, emotionally grounded composition, no text, no watermark",
    "cozy claymation": "cozy claymation inspired miniature world, tactile handmade surfaces, soft studio lighting, charming imperfections, viewer-friendly mood, no text, no watermark",
    "pastel anime cinematic": "pastel cinematic anime look, dreamy soft light, gentle gradients, clean expressive lines, emotional atmospheric backgrounds, no text, no watermark",
    "graphic novel noir": "graphic novel cinematic noir, bold inked linework, controlled color accents, dramatic lighting, clean readable composition, no text, no watermark",
    "dreamcore soft glow": "dreamcore soft glow aesthetic, ethereal haze, smooth color transitions, surreal but calm environment, gentle cinematic composition, no text, no watermark",
    "minimal flat vector": "minimal modern flat vector illustration, clean geometry, tasteful color blocking, simple shapes, friendly editorial look, no text, no watermark",
    "isometric toy world": "isometric toy-world miniature style, clean 3D-like geometry, bright friendly colors, soft shadows, neatly arranged scenes, no text, no watermark",
    "retro 90s anime": "retro 1990s anime film look, hand-painted backgrounds, warm cel shading, subtle grain, cinematic framing, no text, no watermark",
    "dark academia cinematic": "dark academia cinematic style, warm lamps, antique textures, deep shadows, scholarly atmosphere, elegant composition, no text, no watermark",
    "golden nostalgia": "golden nostalgic cinematic illustration, sepia highlights, soft bloom, emotional warmth, vintage interior detail, no text, no watermark",
    "clean fantasy adventure": "clean fantasy adventure illustration, rich environments, friendly heroic mood, detailed but readable composition, atmospheric light, no text, no watermark",
}


@dataclass(frozen=True)
class StyleOption:
    key: str
    name: str
    prompt: str
    preview_path: str = ""
    source: str = "builtin"


def _friendly_name(stem: str) -> str:
    stem = re.sub(r"(_preview|_prev|preview)$", "", stem, flags=re.I)
    stem = stem.replace("_", " ").replace("-", " ").strip()
    return " ".join(w.capitalize() for w in stem.split()) or stem


def _style_prompt_from_name(name: str) -> str:
    n = name.lower()
    for key, prompt in BASE_STYLE_PROMPTS.items():
        if key in n:
            return prompt
    return f"{name} visual style, coherent art direction, consistent color palette, consistent lighting language, no text, no watermark"


def scan_styles() -> list[StyleOption]:
    styles: dict[str, StyleOption] = {}
    for key, prompt in BASE_STYLE_PROMPTS.items():
        styles[key] = StyleOption(key=key, name=_friendly_name(key), prompt=prompt)

    if STYLE_PREVIEWS_DIR.exists():
        for image in sorted(STYLE_PREVIEWS_DIR.iterdir()):
            if image.suffix.lower() not in IMAGE_EXTS:
                continue
            name = _friendly_name(image.stem)
            key = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
            styles[key] = StyleOption(key=key, name=name, prompt=_style_prompt_from_name(name), preview_path=str(image), source="preview")

    if REFERENCE_STYLES_DIR.exists():
        for folder in sorted(p for p in REFERENCE_STYLES_DIR.iterdir() if p.is_dir()):
            name = _friendly_name(folder.name)
            key = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
            style_txt = folder / "style.txt"
            if style_txt.exists():
                prompt = style_txt.read_text(encoding="utf-8", errors="ignore").strip()
            else:
                image_names = ", ".join(p.stem for p in folder.iterdir() if p.suffix.lower() in IMAGE_EXTS)
                prompt = f"Match the visual style indicated by reference set {name}: {image_names}. Keep style consistent across every scene; do not copy logos or frames."
            preview = next((str(p) for p in folder.iterdir() if p.suffix.lower() in IMAGE_EXTS), "")
            styles[key] = StyleOption(key=key, name=f"Custom: {name}", prompt=prompt, preview_path=preview, source="reference")

    return sorted(styles.values(), key=lambda s: (s.source != "builtin", s.name.lower()))


def get_style_prompt(key: str) -> str:
    for s in scan_styles():
        if s.key == key:
            return s.prompt
    return BASE_STYLE_PROMPTS["cinematic"]
