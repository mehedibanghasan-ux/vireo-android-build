from __future__ import annotations

from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Any
import hashlib
import os
import re

from .styles import WARM_HAND_DRAWN_FINANCIAL_STORYBOOK_STYLE

NO_MAIN_CHARACTER_TAG = "[NO_MAIN_CHARACTER]"

STICK_FIGURE_BUNDLE_STYLE = (
    "Cute vibrant 2D stick-figure cartoon illustration style. White circular heads, black stick limbs, "
    "thick clean black outlines, bright cheerful color palette, polished colorful backgrounds, rounded trees and props, "
    "friendly houses and furniture, vivid sky blues, cheerful greens, warm indoor cream tones, cozy rich night blues, "
    "flat solid colors with very minimal soft shading, clean finished frame, playful storybook mood, simple animals and props, "
    "clear storytelling composition, no realistic human anatomy, no fingers, no dense textures, no cinematic realism, no text, no watermark."
)

STRICT_STICK_FIGURE_ANATOMY_RULES = (
    "Strict anatomy rules for every visible human or stick figure: each character must have exactly two arms and exactly two legs. "
    "Each arm must connect clearly to a shoulder and end in only one simple rounded hand. No extra arms, no extra hands, no duplicated limbs, "
    "no merged limbs, no floating hands, and no overlapping limb ambiguity."
)

CROWD_CONTROL_RULES = (
    "When a scene includes multiple people, keep side characters extremely simple, smaller, and clearly separated. "
    "If a character is holding an object, show clearly which hand holds it and keep the other arm relaxed at the side or hidden behind the body or object. "
    "Avoid crowded overlapping poses. In object-handling scenes, prefer a maximum of three clearly visible human characters."
)

GLOBAL_STICK_FIGURE_CONSTRAINTS = " ".join([
    "Keep the scene visually simple and readable. Avoid extra limbs, anatomy errors, complex body detail, dense clutter, floating objects, heavy perspective distortion, and malformed props or animals.",
    STRICT_STICK_FIGURE_ANATOMY_RULES,
    CROWD_CONTROL_RULES,
])

OLDER_STORYBOOK_STICK_RULES = (
    "Older Storybook people rule: every visible human in this image must use a true stick-figure body with a simple round or oval illustrated head, "
    "one thin black line torso, thin black stick arms and legs, and tiny simple hands. Never draw a realistic, filled, fleshy, or normal human-shaped torso. "
    "Never mix stick figures with normal human figures. Never let one person be a stick figure while another looks like a normal human. "
    "Only the selected main protagonist uses the fixed recurring identity described above. Any spouse, relative, coworker, doctor, neighbor, crowd member, "
    "or other side character may vary naturally for the scene, but must still be a simple non-recurring stick figure."
)

OLDER_STORYBOOK_STICK_STYLE = (
    WARM_HAND_DRAWN_FINANCIAL_STORYBOOK_STYLE
    + " Older Character Bundle override: preserve the same parchment, graphite, ink, watercolor, palette, lighting, and mature editorial atmosphere, "
      "while using a slightly sketchy, loose hand-drawn finish with slightly rough pencil edges so the characters stay story-focused rather than portrait-precise. "
      "but every human body must be a true simple stick figure with one thin black line torso and thin black stick limbs. Clothing is only a tiny flat accent; "
      "never create a filled human chest, shoulders, waist, dress-shaped body, jacket-shaped body, fleshy anatomy, or realistic human proportions. "
      "Use true simple stick figure people only. Keep all faces lightly sketched, not portrait-detailed."
)

STANDARD_CHARACTER_STYLE_CLASSIC = "classic"
STANDARD_CHARACTER_STYLE_STORYBOOK = "older_storybook_look"

STANDARD_CHARACTER_STYLE_LABELS = {
    "Classic Vibrant Stick-Figure": STANDARD_CHARACTER_STYLE_CLASSIC,
    "Warm Hand-Drawn Older Storybook Look": STANDARD_CHARACTER_STYLE_STORYBOOK,
}

# This intentionally mirrors the visual language of the Older Storybook bundle
# without changing the selected standard hero's identity, age, clothing cue, or
# recurrence rules. It is a look-only override for the standard character card.
STANDARD_STORYBOOK_ALL_PEOPLE_RULES = (
    "Standard Storybook stick-figure consistency rule: every visible human must remain a true stick figure, including the recurring hero and every side character. "
    "Use one thin dark ink line for the torso and thin dark stick arms and legs; never use a filled torso, white oval body, colored body blob, jacket-shaped body, dress-shaped body, fleshy anatomy, or normal human proportions. "
    "Never replace a stick figure with a normal human, semi-realistic human, anime/cel character, or filled cartoon person. "
    "Heads stay simple outlined circles or ovals with a warm parchment/off-white paper fill rather than a bright pure white blank cutout; preserve the selected hero's exact hair, glasses, backpack, hat, scarf, bow tie, and other identity cues. "
    "Keep graphite/ink contours crisp and readable with restrained watercolor texture: no blur, smeared edges, foggy soft focus, washed-out character lines, glossy 3D rendering, or modern cel-animation finish."
)

STANDARD_STICK_FIGURE_STORYBOOK_STYLE = (
    WARM_HAND_DRAWN_FINANCIAL_STORYBOOK_STYLE
    + " Stick-Figure Main Character Bundle style override: preserve the same parchment, graphite, ink, watercolor, muted palette, "
      "mature editorial atmosphere, and slightly sketchy loose hand-drawn finish used by the Older Storybook bundle. "
      + STANDARD_STORYBOOK_ALL_PEOPLE_RULES + " "
      "Do not change the selected recurring character's identity, hair, accessories, age, or proportions."
)

OLDER_PRESET_ALIASES = {
    "elderly_male_silver_side_part": "older_male_storybook",
    "elderly_male_round_glasses": "older_male_storybook",
    "elderly_male_flat_cap": "older_male_storybook",
    "elderly_female_grey_bun": "older_female_storybook",
    "elderly_female_silver_bob": "older_female_storybook",
    "elderly_female_soft_white_curls": "older_female_storybook",
}


@dataclass(frozen=True)
class CharacterPreset:
    key: str
    name: str
    prompt: str
    bundle_style_prompt: str = STICK_FIGURE_BUNDLE_STYLE
    source: str = "builtin"
    group: str = "standard"

    def as_prompt_payload(self) -> dict[str, str]:
        return {
            "id": self.key,
            "name": self.name,
            "character_prompt": self.prompt,
            "bundle_style_prompt": self.bundle_style_prompt,
            "global_anatomy_rules": STRICT_STICK_FIGURE_ANATOMY_RULES,
            "crowd_control_rules": CROWD_CONTROL_RULES,
            "all_people_style_rules": (
                OLDER_STORYBOOK_STICK_RULES
                if self.group == "older_storybook"
                else STANDARD_STORYBOOK_ALL_PEOPLE_RULES
                if self.group == "standard" and self.bundle_style_prompt == STANDARD_STICK_FIGURE_STORYBOOK_STYLE
                else ""
            ),
        }


CHARACTER_PRESETS: list[CharacterPreset] = [
    CharacterPreset(
        key="none",
        name="No preset character",
        prompt="",
        bundle_style_prompt="",
        group="none",
    ),
    CharacterPreset(
        key="red_hair_hero",
        name="Red Hair Hero",
        prompt=(
            "Use the selected main character whenever the protagonist appears: a simple stick figure with a white circular head, "
            "black stick limbs, a distinctive bright-red short hair silhouette, tiny dot eyes, a small mouth, and a small blue scarf. "
            "Keep this same identity, face style, proportions, and hair shape every time the main character appears."
        ),
    ),
    CharacterPreset(
        key="curly_hair_hero",
        name="Curly Hair Hero",
        prompt=(
            "Use the selected main character whenever the protagonist appears: a simple stick figure with a white circular head, "
            "black stick limbs, a distinctive curly dark hair silhouette, tiny dot eyes, a small mouth, and a green shoulder bag. "
            "Keep this same identity, face style, proportions, and curly hair shape every time the main character appears."
        ),
    ),
    CharacterPreset(
        key="hat_man",
        name="Hat Man",
        prompt=(
            "Use the selected main character whenever the protagonist appears: a simple stick figure with a white circular head, "
            "black stick limbs, a flat black pork-pie hat, small round glasses, tiny dot eyes, and a calm small mouth. "
            "Keep this same hat shape, glasses, face style, and body proportions every time the main character appears."
        ),
    ),
    CharacterPreset(
        key="ponytail_girl",
        name="Ponytail Girl",
        prompt=(
            "Use the selected main character whenever the protagonist appears: a simple stick figure with a white circular head, "
            "black stick limbs, a clear dark ponytail silhouette, tiny dot eyes, a small mouth, and a purple backpack. "
            "Keep this same identity, ponytail shape, face style, and body proportions every time the main character appears."
        ),
    ),
    CharacterPreset(
        key="glasses_nerd",
        name="Glasses Nerd",
        prompt=(
            "Use the selected main character whenever the protagonist appears: a simple stick figure with a white circular head, "
            "black stick limbs, large square glasses, tiny dot eyes, a small mouth, and a yellow bow tie. "
            "Keep this same identity, glasses, face style, and body proportions every time the main character appears."
        ),
    ),
    CharacterPreset(
        key="older_male_storybook",
        name="Old Male",
        group="older_storybook",
        bundle_style_prompt=OLDER_STORYBOOK_STICK_STYLE,
        prompt=(
            "Use this selected recurring main character only when the scene includes the recurring protagonist: a simple elderly male stick figure. "
            "He has a clean warm-white round head, soft white hair in a small neat side-part shape, two tiny dark eyes, light facial wrinkles and short age lines, "
            "and a calm small mouth. His body must stay a true stick figure in every frame: one thin black line torso, exactly two "
            "thin black stick arms and exactly two thin black stick legs, with tiny simple rounded hands and feet. Any clothing accent must stay tiny and flat "
            "and must never create a filled human chest, shoulders, waist, jacket-shaped body, or realistic anatomy. "
            "No realistic human torso, no normal human body proportions, no fleshy arms or legs. Keep this same identity, soft white hair side-part, light wrinkles, "
            "head design, stick proportions, and elderly age cues every time he returns. Do not insert him into environment-only, object-only, document-only, "
            "or unrelated scenes where the protagonist is not present."
        ),
    ),
    CharacterPreset(
        key="older_female_storybook",
        name="Old Female",
        group="older_storybook",
        bundle_style_prompt=OLDER_STORYBOOK_STICK_STYLE,
        prompt=(
            "Use this selected recurring main character only when the scene includes the recurring protagonist: a simple elderly female stick figure. "
            "She has a clean warm-white oval head, soft white hair gathered into a small tidy bun with tiny wispy strands, two tiny dark eyes, light facial wrinkles and short age lines, "
            "and a gentle small mouth. Her body must stay a true stick figure in every frame: one thin black line torso, exactly two "
            "thin black stick arms and exactly two thin black stick legs, with tiny simple rounded hands and feet. Any clothing accent must stay tiny and flat "
            "and must never create a filled human chest, shoulders, waist, dress-shaped body, or realistic anatomy. "
            "No realistic human torso, no normal human body proportions, no fleshy arms or legs. Keep this same identity, white hair bun, gentle wrinkles, "
            "head design, stick proportions, and elderly age cues every time she returns. Do not insert her into environment-only, object-only, document-only, "
            "or unrelated scenes where the protagonist is not present."
        ),
    ),
]


def character_preset_options() -> list[dict[str, str]]:
    return [{"id": preset.key, "label": preset.name} for preset in CHARACTER_PRESETS]


def standard_character_preset_options() -> list[dict[str, str]]:
    return [
        {"id": preset.key, "label": preset.name}
        for preset in CHARACTER_PRESETS
        if preset.group in {"none", "standard"}
    ]


def older_storybook_character_preset_options() -> list[dict[str, str]]:
    return [
        {"id": "none", "label": "No older preset"},
        *[
            {"id": preset.key, "label": preset.name}
            for preset in CHARACTER_PRESETS
            if preset.group == "older_storybook"
        ],
    ]


def standard_character_style_options() -> list[dict[str, str]]:
    return [
        {"id": style_id, "label": label}
        for label, style_id in STANDARD_CHARACTER_STYLE_LABELS.items()
    ]


def normalize_standard_character_style(style_key: str | None) -> str:
    wanted = (style_key or STANDARD_CHARACTER_STYLE_CLASSIC).strip().lower()
    valid = {STANDARD_CHARACTER_STYLE_CLASSIC, STANDARD_CHARACTER_STYLE_STORYBOOK}
    return wanted if wanted in valid else STANDARD_CHARACTER_STYLE_CLASSIC


def resolve_character_preset_style(
    character_preset: CharacterPreset | None,
    standard_style_key: str | None,
) -> CharacterPreset | None:
    """Apply a look-only style override to standard stick-figure presets.

    Older Storybook presets already own their exact strict style and are returned
    byte-for-byte unchanged. No preset means no style override.
    """
    if character_preset is None or character_preset.group != "standard":
        return character_preset
    style_key = normalize_standard_character_style(standard_style_key)
    if style_key == STANDARD_CHARACTER_STYLE_STORYBOOK:
        return replace(character_preset, bundle_style_prompt=STANDARD_STICK_FIGURE_STORYBOOK_STYLE)
    return character_preset


def normalize_character_preset_key(key: str | None) -> str:
    wanted = (key or "none").strip().lower()
    return OLDER_PRESET_ALIASES.get(wanted, wanted)


def character_preset_group(key: str | None) -> str:
    wanted = normalize_character_preset_key(key)
    for preset in CHARACTER_PRESETS:
        if preset.key.lower() == wanted:
            return preset.group
    return "none"


def get_character_preset(key: str | None) -> CharacterPreset | None:
    wanted = normalize_character_preset_key(key)
    for preset in CHARACTER_PRESETS:
        if preset.key.lower() == wanted:
            return preset if preset.key != "none" else None
    return None


def style_reference_signature(path: str | Path | None) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.exists() or not p.is_file():
        return ""
    stat = p.stat()
    payload = f"{p.resolve()}|{stat.st_size}|{stat.st_mtime_ns}".encode("utf-8", errors="ignore")
    return hashlib.sha1(payload).hexdigest()


def strip_main_character_opt_out(text: str) -> tuple[str, bool]:
    raw = (text or "")
    if NO_MAIN_CHARACTER_TAG.lower() in raw.lower():
        cleaned = re.sub(re.escape(NO_MAIN_CHARACTER_TAG), "", raw, flags=re.I).strip()
        return cleaned, True
    heuristic_patterns = [
        r"\bno main character\b",
        r"\bwithout (?:the )?(?:main )?character\b",
        r"\bbackground only\b",
        r"\benvironment only\b",
        r"\bempty scene\b",
    ]
    for pattern in heuristic_patterns:
        if re.search(pattern, raw, re.I):
            return raw.strip(), True
    return raw.strip(), False


def build_prompt_bundle(
    *,
    scene_prompt: str,
    selected_style_prompt: str = "",
    character_preset: CharacterPreset | None = None,
    style_reference_summary: str = "",
    include_selected_style: bool = True,
    manual_mode: bool = False,
    force_without_character: bool = False,
) -> dict[str, Any]:
    scene_prompt = (scene_prompt or "").strip()
    selected_style_prompt = (selected_style_prompt or "").strip()
    style_reference_summary = (style_reference_summary or "").strip()
    if character_preset is not None:
        primary_style = character_preset.bundle_style_prompt.strip()
        character_prompt = character_preset.prompt.strip()
    else:
        primary_style = selected_style_prompt if include_selected_style else ""
        character_prompt = ""

    # A selected character preset owns the complete stick-figure art direction.
    # Never blend the generic Image Style dropdown into a character bundle, because
    # styles such as cinematic/photorealistic can conflict with flat stick figures.
    selected_style_secondary = ""

    return {
        "mode": "manual" if manual_mode else "automatic",
        "scene_prompt": scene_prompt,
        "style_bundle": {
            "primary_style": primary_style,
            "selected_style_secondary": selected_style_secondary,
            "style_reference_summary": style_reference_summary,
            "global_constraints": (
                f"{GLOBAL_STICK_FIGURE_CONSTRAINTS} {OLDER_STORYBOOK_STICK_RULES}"
                if character_preset and character_preset.group == "older_storybook"
                else f"{GLOBAL_STICK_FIGURE_CONSTRAINTS} {STANDARD_STORYBOOK_ALL_PEOPLE_RULES}"
                if character_preset and character_preset.group == "standard"
                and character_preset.bundle_style_prompt == STANDARD_STICK_FIGURE_STORYBOOK_STYLE
                else GLOBAL_STICK_FIGURE_CONSTRAINTS if character_preset
                else "No text, no logo, no watermark."
            ),
        },
        "character_bundle": {
            "enabled": bool(character_preset) and not force_without_character,
            "preset_id": character_preset.key if character_preset else "",
            "preset_name": character_preset.name if character_preset else "",
            "character_prompt": character_prompt if not force_without_character else "",
            "opted_out": bool(force_without_character),
        },
    }


def render_prompt_bundle(bundle: dict[str, Any]) -> str:
    scene_prompt = str(bundle.get("scene_prompt") or "").strip()
    style = bundle.get("style_bundle") or {}
    character = bundle.get("character_bundle") or {}
    parts: list[str] = [scene_prompt]
    primary_style = str(style.get("primary_style") or "").strip()
    secondary_style = str(style.get("selected_style_secondary") or "").strip()
    reference_summary = str(style.get("style_reference_summary") or "").strip()
    constraints = str(style.get("global_constraints") or "").strip()
    character_prompt = str(character.get("character_prompt") or "").strip()

    if primary_style:
        parts.append(f"Primary image style bundle to follow strictly: {primary_style}")
    if reference_summary:
        parts.append(f"Uploaded style reference summary to match closely: {reference_summary}")
    if secondary_style:
        parts.append(f"Also keep this selected Vireo image style compatible with the bundle: {secondary_style}")
    if character.get("enabled") and character_prompt:
        parts.append(character_prompt)
    if constraints:
        parts.append(constraints)
    parts.append("Final image requirements: clean finished frame, simple readable composition, no text, no logo, no watermark.")
    return "\n\n".join([part for part in parts if part]).strip()


def apply_global_stick_figure_rules(prompt: str, character_preset: CharacterPreset | None = None) -> str:
    prompt = (prompt or "").strip()
    if not prompt:
        return prompt
    additions = [GLOBAL_STICK_FIGURE_CONSTRAINTS]
    if character_preset and character_preset.group == "older_storybook":
        additions.extend([OLDER_STORYBOOK_STICK_RULES, OLDER_STORYBOOK_STICK_STYLE])
    elif (
        character_preset
        and character_preset.group == "standard"
        and character_preset.bundle_style_prompt == STANDARD_STICK_FIGURE_STORYBOOK_STYLE
    ):
        additions.append(STANDARD_STORYBOOK_ALL_PEOPLE_RULES)
    for rule in additions:
        if rule and rule not in prompt:
            prompt += "\n\n" + rule
    return prompt
