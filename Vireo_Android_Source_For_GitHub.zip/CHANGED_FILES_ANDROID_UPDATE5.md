# Changed Files — Android Update 5

1. `app/src/main/java/com/vireo/studio/FFmpegBridge.java` — added dedicated `probeFile` media-information bridge.
2. `app/src/main/python/app/renderer.py` — Android probe call switched from generic FFprobe log output to `probeFile`.
3. `app/build.gradle` — versionCode/versionName only.
4. `port_tests/test_android_port_contracts.py` — Update5 FFprobe regression coverage/version expectations.
5. Update5 release/test/continuity documentation.

Protected provider/pipeline modules were not changed.
