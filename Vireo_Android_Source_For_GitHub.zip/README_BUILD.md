# Vireo Android Update 1

This is a parallel Android port. The supplied desktop source is not modified.

## Toolchain
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- compileSdk/targetSdk 35, minSdk 33 (Android 13+)
- Chaquopy 17.0.0 / Python 3.13
- FFmpegKit Maintained full-gpl 8.1.7 for libx264 and the existing FFmpeg command graph

## Build
Open in Android Studio with SDK 35 installed, or run `./gradlew assembleDebug`.

## License warning
`dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7` includes x264 and is GPL-3.0. Distribution of an app linked to it must satisfy GPL obligations. This package was selected to preserve Vireo's protected libx264 final-output behavior.
