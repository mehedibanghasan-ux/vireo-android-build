# Vireo Video Studio Android — Update 4

This is the current GitHub-build-ready Android source baseline.

## Supported Android
- Minimum: Android 13 / API 33
- Target/compile: Android 16 / API 36
- ABI: arm64-v8a
- 16 KB page-size compatibility declaration retained

## Build contract
Use the companion GitHub workflow `build-vireo.yml`. It installs Java 17, Python 3.13, Android SDK 36 and Gradle 8.13, runs protected-contract tests, then builds a debug-installable APK.

Expected artifact:
`Vireo-Video-Studio-Android13-16-Update4.apk`

## Protected core
Update4 does not rewrite provider/pipeline logic. See `ANDROID_UPDATE4_RELEASE_NOTES.md`, `ANDROID_UPDATE4_TEST_REPORT.md` and `DESKTOP_ANDROID_PARITY_AUDIT_UPDATE4.md`.
