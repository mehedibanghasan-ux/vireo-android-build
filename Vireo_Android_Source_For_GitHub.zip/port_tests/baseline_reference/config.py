from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import os
import tempfile
from typing import Any

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
LONG_VIDEO_DIR = DATA_DIR / "long_videos"
MUSIC_DIR = BASE_DIR / "music"
FONTS_DIR = BASE_DIR / "fonts"
STYLE_PREVIEWS_DIR = BASE_DIR / "style_previews"
REFERENCE_STYLES_DIR = BASE_DIR / "reference_styles"
RESOURCES_DIR = BASE_DIR / "resources"
SETTINGS_FILE = BASE_DIR / "config.json"
ENV_FILE = BASE_DIR / ".env"

DEFAULT_OPENAI_PROMPT_MODEL = "gpt-5.6-luna"
DEFAULT_RUNWARE_IMAGE_MODEL = "openai:gpt-image@2"


def ensure_directories() -> None:
    for p in [DATA_DIR, LONG_VIDEO_DIR, MUSIC_DIR, FONTS_DIR, STYLE_PREVIEWS_DIR, REFERENCE_STYLES_DIR, RESOURCES_DIR]:
        p.mkdir(parents=True, exist_ok=True)
    (RESOURCES_DIR / "ffmpeg" / "bin").mkdir(parents=True, exist_ok=True)


def load_environment() -> None:
    if load_dotenv:
        load_dotenv(ENV_FILE, override=False)


@dataclass
class AppSettings:
    openai_model: str = DEFAULT_OPENAI_PROMPT_MODEL
    default_openai_model: str = DEFAULT_OPENAI_PROMPT_MODEL
    transcription_model: str = "whisper-1"
    runware_model: str = DEFAULT_RUNWARE_IMAGE_MODEL
    image_width: int = 1920
    image_height: int = 1080
    image_steps: int = 4
    ai33_provider: str = "elevenlabs"
    ai33_voice_id: str = "elevenlabs_KbakCphLGyrStJ2sp8mp"
    default_ai33_voice_id: str = "elevenlabs_KbakCphLGyrStJ2sp8mp"
    ai33_custom_voices: dict[str, str] = None
    ai33_speed: float = 1.0
    video_title: str = ""
    scenes: int = 50
    subtitles_enabled: bool = True
    subtitle_font: str = "Impact"
    subtitle_font_size: int = 21
    subtitle_position: str = "bottom"
    subtitle_all_caps: bool = False
    subtitle_outline_size: float = 0.5
    subtitle_color: str = "#ffffff"
    words_per_caption: int = 5
    bg_music: str = "None"
    music_volume: int = 2
    transitions_enabled: bool = True
    ken_burns: bool = True
    heartbeat: bool = True
    random_animations: bool = True
    image_review_enabled: bool = True
    resolution: str = "1080p"
    render_workers: int = 4
    force_h264: bool = True
    last_style: str = "cinematic"
    save_intermediates: bool = True
    manual_image_prompts_enabled: bool = False
    manual_image_prompts_text: str = ""
    apply_style_to_manual_prompts: bool = True
    main_character_preset: str = "none"
    standard_character_style: str = "classic"
    style_reference_image: str = ""
    style_reference_summary: str = ""
    style_reference_signature: str = ""

    def sanitized(self) -> dict[str, Any]:
        data = asdict(self)
        if data.get("ai33_custom_voices") is None:
            data["ai33_custom_voices"] = {}
        return data


def load_settings() -> AppSettings:
    ensure_directories()
    load_environment()
    if not SETTINGS_FILE.exists():
        return AppSettings()
    try:
        raw = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        allowed = {f.name for f in AppSettings.__dataclass_fields__.values()}
        data = {k: v for k, v in raw.items() if k in allowed}
        # Update 18 default migration: an older config can explicitly contain an
        # empty voice ID, which would otherwise override the new dataclass default.
        if not str(data.get("ai33_voice_id") or "").strip():
            data.pop("ai33_voice_id", None)
        if not isinstance(data.get("ai33_custom_voices"), dict):
            data["ai33_custom_voices"] = {}
        # Update 22 introduces an explicit global default prompt model. Existing
        # Update 21 configs do not contain this field, so migrate them once to
        # the requested GPT-5.6 Luna default without rewriting saved projects.
        if not str(data.get("default_openai_model") or "").strip():
            data["default_openai_model"] = DEFAULT_OPENAI_PROMPT_MODEL
        return AppSettings(**data)
    except Exception:
        return AppSettings()


def fresh_project_settings(persisted: AppSettings | None = None) -> AppSettings:
    """Return clean new-project controls while preserving the user's model default.

    Project-specific controls intentionally reset to AppSettings defaults. The
    only global preference carried across new projects is the explicitly chosen
    default OpenAI prompt model. Saved projects still restore their own settings
    through load_project_settings().
    """
    source = persisted or load_settings()
    settings = AppSettings()
    preferred = str(getattr(source, "default_openai_model", "") or "").strip()
    if not preferred:
        preferred = DEFAULT_OPENAI_PROMPT_MODEL
    settings.default_openai_model = preferred
    settings.openai_model = preferred

    # Preserve explicit user-selected AI33 default voice preference globally.
    # Voice defaults are user preferences, not project-specific controls.
    preferred_voice = str(getattr(source, "default_ai33_voice_id", "") or "").strip()
    if preferred_voice:
        settings.default_ai33_voice_id = preferred_voice
        settings.ai33_voice_id = preferred_voice

    return settings



def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass

def save_settings(settings: AppSettings) -> None:
    ensure_directories()
    _atomic_write_text(SETTINGS_FILE, json.dumps(settings.sanitized(), indent=2))


def get_api_key(name: str) -> str:
    load_environment()
    return os.environ.get(name, "").strip()


def save_api_keys(openai_key: str | None = None, runware_key: str | None = None, ai33_key: str | None = None) -> None:
    existing: dict[str, str] = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                existing[k.strip()] = v.strip()
    if openai_key is not None:
        existing["OPENAI_API_KEY"] = openai_key.strip()
    if runware_key is not None:
        existing["RUNWARE_API_KEY"] = runware_key.strip()
    if ai33_key is not None:
        existing["AI33_API_KEY"] = ai33_key.strip()
    lines = ["# Vireo API keys", *(f"{k}={v}" for k, v in existing.items())]
    _atomic_write_text(ENV_FILE, "\n".join(lines) + "\n")
    for k, v in existing.items():
        os.environ[k] = v
