from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYROOT = ROOT / "app" / "src" / "main" / "python"
REF = ROOT / "port_tests" / "baseline_reference"
BASELINE_HASHES = json.loads((REF / "protected_sha256.json").read_text())


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_protected_python_modules_are_byte_identical_except_android_boundaries():
    # config.py differs only by the Android writable base-dir indirection.
    # renderer.py differs only at FFmpeg/FFprobe process-execution boundaries.
    protected = [
        "ai33_client.py", "character_presets.py", "openai_tools.py", "pipeline.py",
        "project.py", "runware_client.py", "scene_splitter.py", "script_analyzer.py",
        "styles.py", "subtitles.py",
    ]
    for name in protected:
        assert sha(PYROOT / "app" / name) == BASELINE_HASHES["modules"][name], name


def test_bundled_scene_cut_sfx_are_exact_copies():
    for name in ("camera_shutter.wav", "whoosh.wav"):
        assert sha(PYROOT / "vireo_static" / "sfx" / name) == BASELINE_HASHES["sfx"][name]


def test_android_config_delta_is_only_base_directory_indirection():
    import difflib
    desktop = (REF / "config.py").read_text().splitlines()
    android = (PYROOT / "app" / "config.py").read_text().splitlines()
    diff = "\n".join(difflib.unified_diff(desktop, android))
    added = [line for line in diff.splitlines() if line.startswith("+") and not line.startswith("+++")]
    removed = [line for line in diff.splitlines() if line.startswith("-") and not line.startswith("---")]
    assert removed == ['-BASE_DIR = Path(__file__).resolve().parents[1]']
    assert added == [
        '+_BUNDLED_BASE_DIR = Path(__file__).resolve().parents[1]',
        '+_ANDROID_BASE_DIR = os.environ.get("VIREO_BASE_DIR", "").strip()',
        '+BASE_DIR = Path(_ANDROID_BASE_DIR).expanduser() if _ANDROID_BASE_DIR else _BUNDLED_BASE_DIR',
    ]


def test_renderer_keeps_all_desktop_content_with_only_bridge_insertions():
    # Stronger than checking selected constants: delete the known bridge-only blocks
    # from Android source and require exact equality with the desktop renderer.
    import difflib
    desktop = (REF / "renderer.py").read_text().splitlines()
    android = (PYROOT / "app" / "renderer.py").read_text().splitlines()
    diff = list(difflib.unified_diff(desktop, android, lineterm=""))
    removed = [x for x in diff if x.startswith("-") and not x.startswith("---")]
    # The only desktop lines moved are the two host fallback lines inside
    # audio_silence_report; they still exist under the Android bridge else branch.
    assert removed == [
        '-    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore")',
        '-    text = proc.stderr or ""',
    ]
    android_text = "\n".join(android)
    assert 'proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore")' in android_text
    assert 'text = proc.stderr or ""' in android_text
    added_text = "\n".join(x[1:] for x in diff if x.startswith("+") and not x.startswith("+++"))
    assert "FFmpegBridge" in added_text
    assert "bridge.executeJson" in added_text
    assert "bridge.probeJson" in added_text
    assert "bridge.executeForLogsJson" in added_text


def test_android_api_and_abi_contract():
    gradle = (ROOT / "app" / "build.gradle").read_text()
    assert "minSdk 33" in gradle
    assert "targetSdk 35" in gradle
    assert "compileSdk 35" in gradle
    assert "abiFilters 'arm64-v8a'" in gradle
    assert "x86_64" not in gradle
    assert "dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7" in gradle
    assert "version = '3.13'" in gradle


def test_manifest_uses_scoped_storage_and_foreground_service():
    manifest = (ROOT / "app" / "src" / "main" / "AndroidManifest.xml").read_text()
    assert "android.permission.INTERNET" in manifest
    assert "android.permission.FOREGROUND_SERVICE_DATA_SYNC" in manifest
    assert "android.permission.POST_NOTIFICATIONS" in manifest
    assert "android.permission.WAKE_LOCK" in manifest
    assert 'android:foregroundServiceType="dataSync"' in manifest
    assert "MANAGE_EXTERNAL_STORAGE" not in manifest
    assert "READ_EXTERNAL_STORAGE" not in manifest
    assert "WRITE_EXTERNAL_STORAGE" not in manifest


def test_ui_contains_desktop_visible_controls_and_review_hides_prompts():
    html = (ROOT / "app" / "src" / "main" / "assets" / "index.html").read_text()
    js = (ROOT / "app" / "src" / "main" / "assets" / "app.js").read_text()
    required_ids = [
        "video_title", "script", "scenes", "openai_model", "manual_image_prompts_enabled",
        "manual_image_prompts_text", "apply_style_to_manual_prompts", "generate", "pause",
        "runware_model", "image_steps", "last_style", "standard_character",
        "standard_character_style", "older_character", "image_review_enabled", "ai33_provider",
        "voice", "new_voice_id", "new_voice_name", "bg_music", "music_volume",
        "subtitles_enabled", "subtitle_font", "subtitle_font_size", "subtitle_position",
        "words_per_caption", "subtitle_all_caps", "subtitle_outline_size", "subtitle_color",
        "transitions_enabled", "ken_burns", "heartbeat", "random_animations", "render_workers",
    ]
    for control in required_ids:
        assert f'id="{control}"' in html, control
    assert "Preview Selected Image Style" in html
    assert "Full Preview" in js
    # Review payload/UI deliberately contain scene text + image only, never prompt text.
    assert '"items":[{"index":i,"scene":scenes[i],"image":str(images[i])}' in (PYROOT / "android_bridge.py").read_text()
    review_fn = js[js.index("function showReview"):js.index("async function regen")]
    assert "prompt" not in review_fn.lower()


def test_subtitle_autosave_and_duplicate_generation_guards_are_present():
    js = (ROOT / "app" / "src" / "main" / "assets" / "app.js").read_text()
    bridge = (PYROOT / "android_bridge.py").read_text()
    java = (ROOT / "app" / "src" / "main" / "java" / "com" / "vireo" / "studio" / "MainActivity.java").read_text()
    for field in ["subtitles_enabled", "subtitle_font", "subtitle_font_size", "subtitle_position", "words_per_caption", "subtitle_all_caps", "subtitle_outline_size", "subtitle_color"]:
        assert f"'{field}'" in js
    assert "_generation_active" in bridge
    assert "Duplicate generation was blocked to protect paid tasks" in bridge
    assert "AtomicBoolean generationRunning" in java
    assert "compareAndSet(false,true)" in java


def test_custom_voice_persists_without_changing_selected_or_default(tmp_path):
    # Run in a fresh interpreter so config.py binds BASE_DIR to this isolated test store.
    script = r'''
import json, os, sys
from pathlib import Path
base=Path(sys.argv[1]); os.environ['VIREO_BASE_DIR']=str(base)
sys.path.insert(0, sys.argv[2])
import android_bridge as b
from app.config import AppSettings, save_settings, load_settings
b._initialized=True
s=AppSettings(ai33_voice_id='voice-selected', default_ai33_voice_id='voice-default', ai33_custom_voices={})
save_settings(s)
r=json.loads(b.add_custom_voice_json(json.dumps({'name':'My Voice','id':'voice-custom','selected':'voice-selected'})))
a=load_settings(); boot=json.loads(b.bootstrap())
print(json.dumps({'result':r,'selected':a.ai33_voice_id,'default':a.default_ai33_voice_id,'custom':a.ai33_custom_voices,'boot_ids':[v['id'] for v in boot['voices']]}))
'''
    p = subprocess.run([sys.executable, "-c", script, str(tmp_path / "store"), str(PYROOT)], text=True, capture_output=True, check=True)
    data = json.loads(p.stdout.strip())
    assert data["selected"] == "voice-selected"
    assert data["default"] == "voice-default"
    assert data["custom"]["My Voice"] == "voice-custom"
    assert "voice-custom" in data["boot_ids"]


def test_openai_429_and_5xx_are_visible_to_existing_retry_logic():
    sys.path.insert(0, str(PYROOT))
    try:
        from openai import _OpenAIHTTPError
        from app.openai_tools import _is_transient_openai_error
        assert _is_transient_openai_error(_OpenAIHTTPError(429, "rate"))
        assert _is_transient_openai_error(_OpenAIHTTPError(500, "server"))
        assert not _is_transient_openai_error(_OpenAIHTTPError(400, "bad request"))
    finally:
        try: sys.path.remove(str(PYROOT))
        except ValueError: pass


def test_openai_transcription_shim_preserves_repeated_timestamp_fields(tmp_path):
    sys.path.insert(0, str(PYROOT))
    try:
        from openai import OpenAI
        client = OpenAI(api_key="test")
        seen = {}
        def fake(method, path, **kwargs):
            seen.update(kwargs)
            return {"text":"ok","words":[]}
        client._request = fake
        fpath = tmp_path / "a.wav"; fpath.write_bytes(b"RIFF")
        with fpath.open("rb") as handle:
            client.audio.transcriptions.create(file=handle, model="whisper-1", timestamp_granularities=["word", "segment"])
        assert seen["data"]["timestamp_granularities[]"] == ["word", "segment"]
        assert "timestamp_granularities" not in seen["data"]
    finally:
        try: sys.path.remove(str(PYROOT))
        except ValueError: pass

def test_python_bridge_blocks_duplicate_paid_generation_and_project_switch(tmp_path):
    script = r'''
import json, os, sys, threading, time
from pathlib import Path
os.environ['VIREO_BASE_DIR']=str(Path(sys.argv[1]))
sys.path.insert(0, sys.argv[2])
import android_bridge as b
import app.pipeline as pipeline
entered=threading.Event(); release=threading.Event(); errors=[]
def fake_run(script, settings, **kwargs):
    entered.set(); release.wait(5); out=Path(sys.argv[1])/'final.mp4'; out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(b'x'); return out
pipeline.run_generation=fake_run
payload=json.dumps({'script':'One sentence.','settings':{}})
def first():
    try: b.generate_json(payload)
    except Exception as e: errors.append(str(e))
t=threading.Thread(target=first); t.start(); assert entered.wait(2)
dup=''; switch=''
try: b.generate_json(payload)
except Exception as e: dup=str(e)
try: b.new_project_json('')
except Exception as e: switch=str(e)
release.set(); t.join(5)
print(json.dumps({'dup':dup,'switch':switch,'errors':errors,'alive':t.is_alive()}))
'''
    p=subprocess.run([sys.executable,'-c',script,str(tmp_path/'store'),str(PYROOT)],text=True,capture_output=True,check=True)
    d=json.loads(p.stdout.strip())
    assert 'Duplicate generation was blocked' in d['dup']
    assert 'before switching projects' in d['switch']
    assert d['errors']==[] and d['alive'] is False
