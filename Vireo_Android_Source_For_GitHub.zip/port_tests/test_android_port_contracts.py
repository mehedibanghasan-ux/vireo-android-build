from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYROOT = ROOT / "app" / "src" / "main" / "python"
REF = ROOT / "port_tests" / "baseline_reference"
BASELINE_HASHES = json.loads((REF / "protected_sha256.json").read_text())


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_protected_python_modules_are_byte_identical_except_android_boundaries():
    # config.py differs only by the Android writable base-dir indirection.
    # renderer.py differs only at FFmpeg/FFprobe process-execution boundaries.
    protected = [
        "ai33_client.py", "character_presets.py", "openai_tools.py", "pipeline.py",
        "project.py", "runware_client.py", "scene_splitter.py", "script_analyzer.py",
        "styles.py", "subtitles.py",
    ]
    for name in protected:
        assert sha(PYROOT / "app" / name) == BASELINE_HASHES["modules"][name], name


def test_bundled_scene_cut_sfx_are_exact_copies():
    for name in ("camera_shutter.wav", "whoosh.wav"):
        assert sha(PYROOT / "vireo_static" / "sfx" / name) == BASELINE_HASHES["sfx"][name]


def test_android_config_delta_is_only_base_directory_indirection():
    import difflib
    desktop = (REF / "config.py").read_text().splitlines()
    android = (PYROOT / "app" / "config.py").read_text().splitlines()
    diff = "\n".join(difflib.unified_diff(desktop, android))
    added = [line for line in diff.splitlines() if line.startswith("+") and not line.startswith("+++")]
    removed = [line for line in diff.splitlines() if line.startswith("-") and not line.startswith("---")]
    assert removed == ['-BASE_DIR = Path(__file__).resolve().parents[1]']
    assert added == [
        '+_BUNDLED_BASE_DIR = Path(__file__).resolve().parents[1]',
        '+_ANDROID_BASE_DIR = os.environ.get("VIREO_BASE_DIR", "").strip()',
        '+BASE_DIR = Path(_ANDROID_BASE_DIR).expanduser() if _ANDROID_BASE_DIR else _BUNDLED_BASE_DIR',
    ]


def test_renderer_keeps_all_desktop_content_with_only_bridge_insertions():
    # Stronger than checking selected constants: delete the known bridge-only blocks
    # from Android source and require exact equality with the desktop renderer.
    import difflib
    desktop = (REF / "renderer.py").read_text().splitlines()
    android = (PYROOT / "app" / "renderer.py").read_text().splitlines()
    diff = list(difflib.unified_diff(desktop, android, lineterm=""))
    removed = [x for x in diff if x.startswith("-") and not x.startswith("---")]
    # The only desktop lines moved are the two host fallback lines inside
    # audio_silence_report; they still exist under the Android bridge else branch.
    assert removed == [
        '-    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore")',
        '-    text = proc.stderr or ""',
    ]
    android_text = "\n".join(android)
    assert 'proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore")' in android_text
    assert 'text = proc.stderr or ""' in android_text
    added_text = "\n".join(x[1:] for x in diff if x.startswith("+") and not x.startswith("+++"))
    assert "FFmpegBridge" in added_text
    assert "bridge.executeJson" in added_text
    assert "bridge.probeFile" in added_text
    assert "bridge.executeForLogsJson" in added_text


def test_android_api_and_abi_contract():
    gradle = (ROOT / "app" / "build.gradle").read_text()
    assert "minSdk 33" in gradle
    assert "targetSdk 36" in gradle
    assert "compileSdk 36" in gradle
    assert "abiFilters 'arm64-v8a'" in gradle
    assert "x86_64" not in gradle
    assert "dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7" in gradle
    assert "version = '3.13'" in gradle


def test_manifest_uses_scoped_storage_and_foreground_service():
    manifest = (ROOT / "app" / "src" / "main" / "AndroidManifest.xml").read_text()
    assert "android.permission.INTERNET" in manifest
    assert "android.permission.FOREGROUND_SERVICE_DATA_SYNC" in manifest
    assert "android.permission.POST_NOTIFICATIONS" in manifest
    assert "android.permission.WAKE_LOCK" in manifest
    assert 'android:foregroundServiceType="dataSync"' in manifest
    assert "MANAGE_EXTERNAL_STORAGE" not in manifest
    assert "READ_EXTERNAL_STORAGE" not in manifest
    assert "WRITE_EXTERNAL_STORAGE" not in manifest


def test_ui_contains_desktop_visible_controls_and_review_hides_prompts():
    html = (ROOT / "app" / "src" / "main" / "assets" / "index.html").read_text()
    js = (ROOT / "app" / "src" / "main" / "assets" / "app.js").read_text()
    required_ids = [
        "video_title", "script", "scenes", "openai_model", "manual_image_prompts_enabled",
        "manual_image_prompts_text", "apply_style_to_manual_prompts", "generate", "pause",
        "runware_model", "image_steps", "last_style", "standard_character",
        "standard_character_style", "older_character", "image_review_enabled", "ai33_provider",
        "voice", "new_voice_id", "new_voice_name", "bg_music", "music_volume",
        "subtitles_enabled", "subtitle_font", "subtitle_font_size", "subtitle_position",
        "words_per_caption", "subtitle_all_caps", "subtitle_outline_size", "subtitle_color",
        "transitions_enabled", "ken_burns", "heartbeat", "random_animations", "render_workers",
    ]
    for control in required_ids:
        assert f'id="{control}"' in html, control
    assert "Preview Selected Image Style" in html
    assert "Full Preview" in js
    # Review payload/UI deliberately contain scene text + image only, never prompt text.
    assert '"items":[{"index":i,"scene":scenes[i],"image":str(images[i])}' in (PYROOT / "android_bridge.py").read_text()
    review_fn = js[js.index("function showReview"):js.index("async function regen")]
    assert "prompt" not in review_fn.lower()


def test_subtitle_autosave_and_duplicate_generation_guards_are_present():
    js = (ROOT / "app" / "src" / "main" / "assets" / "app.js").read_text()
    bridge = (PYROOT / "android_bridge.py").read_text()
    java = (ROOT / "app" / "src" / "main" / "java" / "com" / "vireo" / "studio" / "MainActivity.java").read_text()
    for field in ["subtitles_enabled", "subtitle_font", "subtitle_font_size", "subtitle_position", "words_per_caption", "subtitle_all_caps", "subtitle_outline_size", "subtitle_color"]:
        assert f"'{field}'" in js
    assert "_generation_active" in bridge
    assert "Duplicate generation was blocked to protect paid tasks" in bridge
    assert "AtomicBoolean generationRunning" in java
    assert "compareAndSet(false,true)" in java


def test_custom_voice_persists_without_changing_selected_or_default(tmp_path):
    # Run in a fresh interpreter so config.py binds BASE_DIR to this isolated test store.
    script = r'''
import json, os, sys
from pathlib import Path
base=Path(sys.argv[1]); os.environ['VIREO_BASE_DIR']=str(base)
sys.path.insert(0, sys.argv[2])
import android_bridge as b
from app.config import AppSettings, save_settings, load_settings
b._initialized=True
s=AppSettings(ai33_voice_id='voice-selected', default_ai33_voice_id='voice-default', ai33_custom_voices={})
save_settings(s)
r=json.loads(b.add_custom_voice_json(json.dumps({'name':'My Voice','id':'voice-custom','selected':'voice-selected'})))
a=load_settings(); boot=json.loads(b.bootstrap())
print(json.dumps({'result':r,'selected':a.ai33_voice_id,'default':a.default_ai33_voice_id,'custom':a.ai33_custom_voices,'boot_ids':[v['id'] for v in boot['voices']]}))
'''
    p = subprocess.run([sys.executable, "-c", script, str(tmp_path / "store"), str(PYROOT)], text=True, capture_output=True, check=True)
    data = json.loads(p.stdout.strip())
    assert data["selected"] == "voice-selected"
    assert data["default"] == "voice-default"
    assert data["custom"]["My Voice"] == "voice-custom"
    assert "voice-custom" in data["boot_ids"]


def test_openai_429_and_5xx_are_visible_to_existing_retry_logic():
    sys.path.insert(0, str(PYROOT))
    try:
        from openai import _OpenAIHTTPError
        from app.openai_tools import _is_transient_openai_error
        assert _is_transient_openai_error(_OpenAIHTTPError(429, "rate"))
        assert _is_transient_openai_error(_OpenAIHTTPError(500, "server"))
        assert not _is_transient_openai_error(_OpenAIHTTPError(400, "bad request"))
    finally:
        try: sys.path.remove(str(PYROOT))
        except ValueError: pass


def test_openai_transcription_shim_preserves_repeated_timestamp_fields(tmp_path):
    sys.path.insert(0, str(PYROOT))
    try:
        from openai import OpenAI
        client = OpenAI(api_key="test")
        seen = {}
        def fake(method, path, **kwargs):
            seen.update(kwargs)
            return {"text":"ok","words":[]}
        client._request = fake
        fpath = tmp_path / "a.wav"; fpath.write_bytes(b"RIFF")
        with fpath.open("rb") as handle:
            client.audio.transcriptions.create(file=handle, model="whisper-1", timestamp_granularities=["word", "segment"])
        assert seen["data"]["timestamp_granularities[]"] == ["word", "segment"]
        assert "timestamp_granularities" not in seen["data"]
    finally:
        try: sys.path.remove(str(PYROOT))
        except ValueError: pass

def test_python_bridge_blocks_duplicate_paid_generation_and_project_switch(tmp_path):
    script = r'''
import json, os, sys, threading, time
from pathlib import Path
os.environ['VIREO_BASE_DIR']=str(Path(sys.argv[1]))
sys.path.insert(0, sys.argv[2])
import android_bridge as b
import app.pipeline as pipeline
entered=threading.Event(); release=threading.Event(); errors=[]
def fake_run(script, settings, **kwargs):
    entered.set(); release.wait(5); out=Path(sys.argv[1])/'final.mp4'; out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(b'x'); return out
pipeline.run_generation=fake_run
payload=json.dumps({'script':'One sentence.','settings':{}})
def first():
    try: b.generate_json(payload)
    except Exception as e: errors.append(str(e))
t=threading.Thread(target=first); t.start(); assert entered.wait(2)
dup=''; switch=''
try: b.generate_json(payload)
except Exception as e: dup=str(e)
try: b.new_project_json('')
except Exception as e: switch=str(e)
release.set(); t.join(5)
print(json.dumps({'dup':dup,'switch':switch,'errors':errors,'alive':t.is_alive()}))
'''
    p=subprocess.run([sys.executable,'-c',script,str(tmp_path/'store'),str(PYROOT)],text=True,capture_output=True,check=True)
    d=json.loads(p.stdout.strip())
    assert 'Duplicate generation was blocked' in d['dup']
    assert 'before switching projects' in d['switch']
    assert d['errors']==[] and d['alive'] is False

def _run_bridge_script(tmp_path, body):
    script = f'''\nimport json, os, sys\nfrom pathlib import Path\nos.environ["VIREO_BASE_DIR"]=str(Path(sys.argv[1]))\nsys.path.insert(0, sys.argv[2])\nimport android_bridge as b\nb.initialize(str(Path(sys.argv[1]).parent))\n{body}\n'''
    p=subprocess.run([sys.executable,'-c',script,str(tmp_path/'vireo'),str(PYROOT)],text=True,capture_output=True,check=True)
    return json.loads(p.stdout.strip())


def test_env_import_whitelists_keys_and_never_returns_secret_values(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
from app.config import get_api_key
raw="""# desktop env\nOPENAI_API_KEY=sk-secret-openai\nRUNWARE_API_KEY=rw-secret\nAI33_API_KEY=ai-secret\nOTHER_PRIVATE_SECRET=must-not-import\n"""
out=json.loads(b.import_env_json(raw))
print(json.dumps({"out":out,"openai":bool(get_api_key("OPENAI_API_KEY")),"runware":bool(get_api_key("RUNWARE_API_KEY")),"ai33":bool(get_api_key("AI33_API_KEY")),"other":get_api_key("OTHER_PRIVATE_SECRET")}))
''')
    text=json.dumps(d)
    assert d['openai'] and d['runware'] and d['ai33']
    assert d['other']==''
    assert 'sk-secret-openai' not in text and 'rw-secret' not in text and 'ai-secret' not in text
    assert sorted(d['out']['imported'])==['ai33','openai','runware']


def test_blank_key_update_preserves_existing_hidden_keys(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
from app.config import save_api_keys, get_api_key
save_api_keys("open-old","run-old","ai-old")
b.save_keys_json(json.dumps({"openai":"open-new","runware":"","ai33":""}))
print(json.dumps({"openai":get_api_key("OPENAI_API_KEY"),"runware":get_api_key("RUNWARE_API_KEY"),"ai33":get_api_key("AI33_API_KEY")}))
''')
    assert d=={'openai':'open-new','runware':'run-old','ai33':'ai-old'}


def test_subtitle_autosave_changes_only_subtitle_fields(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
from app.config import load_settings, save_settings
s=load_settings(); s.render_workers=9; s.openai_model="keep-model"; s.subtitle_font_size=21; save_settings(s)
b.save_subtitle_prefs_json(json.dumps({"subtitle_font_size":37,"subtitle_color":"#112233"}))
a=load_settings()
print(json.dumps({"font":a.subtitle_font_size,"color":a.subtitle_color,"workers":a.render_workers,"model":a.openai_model}))
''')
    assert d['font']==37 and d['color']=='#112233'
    assert d['workers']==9 and d['model']=='keep-model'


def test_script_detach_clears_resume_binding(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
from app.config import LONG_VIDEO_DIR
p=LONG_VIDEO_DIR/"lv_001"; p.mkdir(parents=True); (p/"original_script.txt").write_text("same",encoding="utf-8")
b.load_project_json(json.dumps({"path":str(p)})); b.detach_project_json("")
print(json.dumps({"loaded":b._loaded_project_dir is not None}))
''')
    assert d['loaded'] is False


def test_loading_old_project_preserves_global_default_openai_model(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
from app.config import LONG_VIDEO_DIR, load_settings, save_settings
s=load_settings(); s.openai_model="global-current"; s.default_openai_model="global-default"; save_settings(s)
p=LONG_VIDEO_DIR/"lv_001"; p.mkdir(parents=True); (p/"original_script.txt").write_text("story",encoding="utf-8")
meta=s.sanitized(); meta["openai_model"]="project-model"; meta["default_openai_model"]="old-project-default"; (p/"project_metadata.json").write_text(json.dumps(meta),encoding="utf-8")
out=json.loads(b.load_project_json(json.dumps({"path":str(p)})))
print(json.dumps({"project":out["settings"]["openai_model"],"default":out["settings"]["default_openai_model"]}))
''')
    assert d=={'project':'project-model','default':'global-default'}


def test_restore_project_folder_uses_new_protected_lv_folder_without_overwrite(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
from app.config import LONG_VIDEO_DIR
existing=LONG_VIDEO_DIR/"lv_001"; existing.mkdir(parents=True); (existing/"original_script.txt").write_text("existing",encoding="utf-8")
src=Path(sys.argv[1]).parent/"visible_project"; src.mkdir(); (src/"original_script.txt").write_text("restored story",encoding="utf-8"); (src/"vireo_state.json").write_text("{}",encoding="utf-8")
out=json.loads(b.restore_project_json(json.dumps({"path":str(src),"sourceName":"PC lv_001"})))
print(json.dumps({"dest":Path(out["path"]).name,"existing":(existing/"original_script.txt").read_text(),"restored":Path(out["path"],"original_script.txt").read_text()}))
''')
    assert d['dest']=='lv_002' and d['existing']=='existing' and d['restored']=='restored story'


def test_restore_rejects_non_vireo_folder(tmp_path):
    d=_run_bridge_script(tmp_path, r'''
src=Path(sys.argv[1]).parent/"bad"; src.mkdir(); (src/"random.txt").write_text("x")
err=""
try: b.restore_project_json(json.dumps({"path":str(src)}))
except Exception as e: err=str(e)
print(json.dumps({"err":err}))
''')
    assert 'original_script.txt is missing or empty' in d['err']


def test_main_activity_uses_real_window_insets_not_hardcoded_status_bar_margin():
    java=(ROOT/'app/src/main/java/com/vireo/studio/MainActivity.java').read_text(encoding='utf-8')
    assert 'setOnApplyWindowInsetsListener' in java
    assert 'WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()' in java
    assert 'setPadding(left,top,right,bottom)' in java


def test_android_saf_workspace_and_restore_contracts_are_present():
    java=(ROOT/'app/src/main/java/com/vireo/studio/MainActivity.java').read_text(encoding='utf-8')
    for token in ('ACTION_OPEN_DOCUMENT_TREE','takePersistableUriPermission','Projects','Reference_Styles','syncProjectToWorkspace','importProjectTree'):
        assert token in java
    assert 'copyLocalTree' in java and 'copyDocumentTreeToLocal' in java


def test_mobile_ui_exposes_env_workspace_style_and_restore_controls():
    html=(ROOT/'app/src/main/assets/index.html').read_text(encoding='utf-8')
    js=(ROOT/'app/src/main/assets/app.js').read_text(encoding='utf-8')
    for text in ('Import PC .env','Choose Visible Vireo Workspace','Import / Restore Project Folder','Import Style Preview Image','Import Reference Style Folder'):
        assert text in html
    assert "padStart(3,'0')" in js
    assert 'detach_project_json' in js
    assert 'save_subtitle_prefs_json' in js


def test_update7_targets_android_13_through_16_and_keeps_16kb_compat():
    gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
    manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
    html=(ROOT/'app/src/main/assets/index.html').read_text(encoding='utf-8')
    assert 'minSdk 33' in gradle and 'targetSdk 36' in gradle and 'compileSdk 36' in gradle
    assert "versionCode 7" in gradle and "update7-android16-back-saf-lint-fix" in gradle
    assert 'android:pageSizeCompat="enabled"' in manifest
    assert 'Android 13–16' in html


def test_update6_android_media_probe_normalizes_ffmpegkit_object_model_to_desktop_schema():
    java=(ROOT/'app/src/main/java/com/vireo/studio/FFmpegBridge.java').read_text(encoding='utf-8')
    renderer=(PYROOT/'app'/'renderer.py').read_text(encoding='utf-8')
    assert 'probeFile(String path)' in java
    assert 'FFprobeKit.getMediaInformation(path)' in java
    assert 'normalizeMediaInformation' in java
    assert 'normalizedStream' in java
    assert 'stream.put("codec_type",type)' in java
    assert 'format.put("duration",duration)' in java
    assert 'out.put("streams",normalizedStreams)' in java
    assert 'out.put("format",format)' in java
    assert 'bridge.probeFile(str(path))' in renderer


def test_update6_preflight_is_real_and_runs_before_paid_provider_work():
    java=(ROOT/'app/src/main/java/com/vireo/studio/FFmpegBridge.java').read_text(encoding='utf-8')
    renderer=(PYROOT/'app'/'renderer.py').read_text(encoding='utf-8')
    pipeline=(PYROOT/'app'/'pipeline.py').read_text(encoding='utf-8')
    assert 'selfTest(String bundledAudioPath)' in java
    assert 'MP3 decode self-test' in java
    assert 'H.264/AAC encode self-test' in java
    assert '_android_preflight_once' in renderer
    assert 'bridge.selfTest(str(sample))' in renderer
    # Existing pipeline calls find_ffmpeg before style/prompt/image/audio provider work.
    preflight=pipeline.index('find_ffmpeg()')
    image=pipeline.index('generate_image(', preflight)
    tts=pipeline.index('generate_tts_audio(', preflight)
    assert preflight < image and preflight < tts


def test_update6_actual_apk_probe_fix_does_not_change_paid_ai33_or_pipeline_logic():
    # Probe/codec fixes remain on the Android renderer/Java boundary only. A media
    # validation failure must never be solved by re-submitting paid TTS tasks.
    for name in ('ai33_client.py','pipeline.py'):
        assert sha(PYROOT/'app'/name) == BASELINE_HASHES['modules'][name]


def test_update7_uses_androidx_predictive_back_dispatcher_and_preserves_generation_behavior():
    java=(ROOT/'app/src/main/java/com/vireo/studio/MainActivity.java').read_text(encoding='utf-8')
    gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
    assert 'extends ComponentActivity' in java
    assert 'OnBackPressedCallback' in java
    assert 'getOnBackPressedDispatcher().addCallback(this,generationBackCallback)' in java
    assert '@Override public void onBackPressed()' not in java
    assert 'generationBackCallback.setEnabled(true)' in java
    assert 'generationBackCallback.setEnabled(false)' in java
    assert 'moveTaskToBack(true)' in java
    assert "androidx.activity:activity:1.13.0" in gradle


def test_update7_persistable_uri_permission_uses_only_read_write_mode_flags():
    java=(ROOT/'app/src/main/java/com/vireo/studio/MainActivity.java').read_text(encoding='utf-8')
    block=java[java.index('private void persistTreePermission'):java.index('private void pick(', java.index('private void persistTreePermission'))]
    assert 'FLAG_GRANT_PERSISTABLE_URI_PERMISSION' not in block
    assert 'FLAG_GRANT_PREFIX_URI_PERMISSION' not in block
    assert 'if(canRead&&canWrite)' in block
    assert 'else if(canRead)' in block
    assert 'else if(canWrite)' in block
    assert 'takePersistableUriPermission(uri,flags)' in block
