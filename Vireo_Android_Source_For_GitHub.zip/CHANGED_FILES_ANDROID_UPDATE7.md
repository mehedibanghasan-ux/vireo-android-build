# Changed Files - Android Update 7

Runtime/build source changes only:
1. `app/src/main/java/com/vireo/studio/MainActivity.java`
   - Predictive Back migration to AndroidX OnBackPressedDispatcher.
   - Explicit SAF persistable permission mode narrowing.
2. `app/build.gradle`
   - AndroidX Activity dependency.
   - versionCode 7 / Update 7 versionName.
3. `port_tests/test_android_port_contracts.py`
   - Update 7 regression contracts for predictive Back and URI permission modes.

Documentation:
- `ANDROID_UPDATE7_RELEASE_NOTES.md`
- `ANDROID_UPDATE7_TEST_REPORT.md`

No protected Python provider/pipeline module was changed.
