# Vireo Android Update 9 — Real Runtime Root Cause

## Observed on physical device
The Update 8 APK reached the Android FFmpeg/FFprobe self-test, then failed while `FFmpegKitConfig` initialized:

`java.lang.NoClassDefFoundError: Failed resolution of: Lcom/arthenica/smartexception/java/Exceptions;`

The missing class is not part of Vireo core logic. It is a Java runtime dependency used by FFmpegKit itself.

## Root cause
The app declared `dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7`, but the final installed APK did not contain the runtime class `com.arthenica.smartexception.java.Exceptions` required by FFmpegKitConfig. Although Maven metadata/documentation can provide smart-exception transitively, the physical-device evidence proves that relying on that implicit path was not safe for this build.

## Update 9 fix
The Android app now explicitly pins both Smart Exception artifacts:

- `com.arthenica:smart-exception-java:0.2.1`
- `com.arthenica:smart-exception-common:0.2.1`

No FFmpegBridge behavior, renderer behavior, provider logic, project logic, Resume logic, AI33 task semantics, Runware semantics, subtitle logic, scene mapping, or narration logic was changed.

## New guards
Update 9 fails the build before an APK is published unless all of the following are true:

1. The explicit Smart Exception dependencies are present in source.
2. Gradle `debugRuntimeClasspath` resolves both Smart Exception artifacts at 0.2.1.
3. The APK is assembled successfully.
4. Android lint passes.
5. Required FFmpeg/Chaquopy native libraries are present.
6. `apkanalyzer dex packages --defined-only` proves that `com.arthenica.smartexception.java.Exceptions` is actually DEFINED inside the APK DEX, not merely referenced.

This specifically closes the failure class seen on the physical device.
