# Test Report — Vireo Android Update 1

## Baseline integrity

Original supplied memory pack SHA-256:
`4f226b24bcb250097f70461a485592850e624527d4cec27cf26c99aa5cc999e1`

Original supplied source archive SHA-256:
`6ff6b8d7f15729f9e59fdf6be219ab4c984d5796f7dc48cba01599e7b4714c4d`

Both were re-hashed during final verification and remained unchanged.

## Compilation / static checks

- `python -m compileall -q app/src/main/python`: PASS
- `node --check app/src/main/assets/app.js`: PASS
- `python tools/verify_android_port.py`: PASS
  - 66 HTML controls/containers checked
  - 30 Python bridge methods discovered
  - 13 `@JavascriptInterface` methods discovered
  - UI-to-Python and UI-to-Java call references validated

## Android port contract tests

Command:
`PYTHONPATH=app/src/main/python pytest -q port_tests/test_android_port_contracts.py`

Result: **12 passed**.

Coverage includes:

- protected module byte hashes
- exact SFX hashes
- config adapter delta
- renderer adapter boundary
- Android 13+ / target SDK / arm64 / dependency pins
- scoped-storage/foreground-service manifest contract
- visible UI control parity
- image review prompt hiding
- subtitle autosave bindings
- duplicate-generation guards
- custom voice persistence without selected/default voice mutation
- OpenAI transient retry status preservation
- transcription timestamp field encoding

## Protected desktop regression suite

The complete supplied desktop tests were executed with the Android embedded core on `PYTHONPATH`.

Result: **121 passed, 1 failed**.

The single failure is the same known baseline inconsistency identified before Android work:
`test_update22_fresh_project_defaults_match_requested_controls` expects subtitle font size 19, while current supplied `AppSettings` defaults to 21.

No Android change was made to that protected value or old test.

## Real FFmpeg render smoke

`python tools/render_smoke_test.py`

Result: PASS.

Verified:

- 2 scene images mapped to 2 narration files
- Ken Burns enabled
- heartbeat enabled
- transitions enabled
- randomized animation enabled
- SRT subtitle burn-in path exercised
- final video codec: H.264
- final audio codec: AAC
- scene mapping flag: true
- expected narration duration: 2.649977 s
- final duration: 2.709333 s
- within renderer tolerance

## Android APK build test

Not executable in this container because Android SDK, `sdkmanager`, Gradle and dependency caches are absent, while outbound network access is disabled. This is an environment/toolchain limitation rather than a Gradle source error discovered by tests.

A GitHub Actions workflow and local Android Studio/Gradle build instructions are included.
