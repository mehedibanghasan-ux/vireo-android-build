# Vireo Video Studio Android — Update 4 Release Notes

## Goal
Close the confirmed desktop-to-Android parity gaps without rewriting or simplifying Vireo's protected generation pipeline.

## Fixed / added
- Real system-bar and display-cutout `WindowInsets` fix for the header overlap seen on the user's device.
- `Import PC .env` using Android's document picker.
- `.env` import accepts only `OPENAI_API_KEY`, `RUNWARE_API_KEY`, and `AI33_API_KEY`.
- API key values are never returned to WebView/log output.
- Blank key fields preserve existing stored keys.
- Visible user-selected Vireo workspace via Storage Access Framework with persistent permission.
- Workspace folders: `Projects`, `Music`, `Fonts`, `Style_Previews`, `Reference_Styles`, `Exports`.
- Protected private project remains authoritative; workspace is a mirror only.
- Visible `Projects/lv_###` placeholder is prepared as soon as a project becomes known.
- Full project mirror after Pause/Complete and manual Sync Current Project.
- Final MP4 also mirrors to workspace `Exports` when a workspace is configured.
- Import / Restore Project Folder from Android Files.
- Restore validates `original_script.txt`, allocates a new protected `lv_###`, and never overwrites an existing protected project.
- Old project load preserves the current global default OpenAI model for future new projects, matching desktop behavior.
- Import Style Preview Image.
- Import Reference Style Folder.
- Music/font/style library mirror to visible workspace.
- Zero-padded scene labels (`Scene 001`, `Scene 002`, ...), matching desktop.
- Script edit/load/paste/clear detaches the previous Resume binding; protected pipeline still independently rejects script-mismatched Resume.
- Subtitle autosave now writes subtitle preference fields only.
- AI33 voice list automatically fetches once when an AI33 key is available.
- Android label updated to Android 13–16.
- Version bumped to Update4.

## Intentionally unchanged
No Update4 edits were made to:
- `app/pipeline.py`
- `app/runware_client.py`
- `app/ai33_client.py`
- `app/project.py`
- `app/subtitles.py`
- `app/openai_tools.py`
- `app/scene_splitter.py`
- `app/script_analyzer.py`
- `app/character_presets.py`
- `app/styles.py`
- approved FIX3 `app/config.py` Android base-dir boundary
- approved FIX3 `app/renderer.py` FFmpeg execution boundary

Therefore Scene → Prompt → Image → Audio → Subtitle → Timeline mapping, paid-task safety, Resume manifests, exact-script subtitles, narration continuity, FFconcat behavior, and H.264/AAC render decisions remain protected.
