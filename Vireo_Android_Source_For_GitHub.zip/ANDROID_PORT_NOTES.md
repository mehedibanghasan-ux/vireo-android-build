# Vireo Android Port Notes

Protected Python modules are copied from the supplied baseline. `config.py` changes only the writable base-directory selection when `VIREO_BASE_DIR` is present. `renderer.py` changes only the process execution/probe boundary to FFmpegKit on Android; all render graphs, filters, versions, timing, cache signatures and output codecs remain unchanged. `android_bridge.py` contains Android UI orchestration and the image-review adapter.

The desktop baseline remains untouched.
